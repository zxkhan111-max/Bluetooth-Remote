package com.example.ui.screens

import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PermMedia
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.TransferStatus
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.SlateBorder
import com.example.ui.viewmodel.RemoteUiState

@Composable
fun FileTransferScreen(
    state: RemoteUiState,
    onAddFiles: (List<Uri>) -> Unit,
    onRemoveFile: (String) -> Unit,
    onStartTransfer: (String, Int, String) -> Unit,
    onCancelTransfer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current

    var receiverIp by remember(state.discoveredReceivers) {
        mutableStateOf(state.discoveredReceivers.firstOrNull()?.host.orEmpty())
    }
    var receiverPort by remember(state.discoveredReceivers) {
        mutableStateOf((state.discoveredReceivers.firstOrNull()?.port ?: 7373).toString())
    }
    var sessionPin by remember { mutableStateOf("") }

    val mediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(20)
    ) { uris ->
        if (uris.isNotEmpty()) onAddFiles(uris)
    }

    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) onAddFiles(uris)
    }

    LazyColumn(
        modifier = modifier
            .widthIn(max = 600.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(strings.fileTransferTitle, style = MaterialTheme.typography.headlineSmall)
        }

        item {
            CapabilityNoticeBanner(text = strings.receiverSetupNotice, isError = false)
        }

        // File Picker Buttons (Zero Broad Storage Permissions!)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("transfer_pick_media_btn")
                ) {
                    Icon(Icons.Filled.PermMedia, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.pickMediaFiles)
                }
                OutlinedButton(
                    onClick = { documentPicker.launch(arrayOf("*/*")) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("transfer_pick_docs_btn")
                ) {
                    Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.pickDocuments)
                }
            }
        }

        // Receiver Discovery & Auth Session Inputs
        if (state.discoveredReceivers.isNotEmpty()) {
            item {
                Text("Discovered TV Receivers", style = MaterialTheme.typography.titleSmall, color = CyanGlow)
            }
            items(state.discoveredReceivers, key = { it.id }) { ep ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(ep.name, style = MaterialTheme.typography.titleSmall)
                            Text("${ep.host}:${ep.port}", style = MaterialTheme.typography.labelSmall, color = CyanGlow)
                        }
                        Button(onClick = {
                            receiverIp = ep.host
                            receiverPort = ep.port.toString()
                        }) { Text("Use") }
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = receiverIp,
                        onValueChange = { receiverIp = it },
                        label = { Text(strings.receiverIpHint) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = receiverPort,
                            onValueChange = { receiverPort = it.filter { c -> c.isDigit() } },
                            label = { Text("Port (7373)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = sessionPin,
                            onValueChange = { sessionPin = it },
                            label = { Text(strings.receiverPinHint) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (state.isTransferring) {
                        Button(
                            onClick = onCancelTransfer,
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorCoral),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(strings.cancelTransfer)
                        }
                    } else {
                        Button(
                            onClick = {
                                onStartTransfer(
                                    receiverIp,
                                    receiverPort.toIntOrNull() ?: 7373,
                                    sessionPin
                                )
                            },
                            enabled = state.transferQueue.any { it.status == TransferStatus.QUEUED || it.status == TransferStatus.FAILED },
                            colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("transfer_start_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.startTransfer)
                        }
                    }
                }
            }
        }

        // Queue Items
        items(state.transferQueue, key = { it.id }) { item ->
            val progress = if (item.sizeBytes > 0) (item.bytesSent.toFloat() / item.sizeBytes.toFloat()).coerceIn(0f, 1f) else 0f
            val sizeText = Formatter.formatShortFileSize(context, item.sizeBytes)
            val speedText = if (item.speedBytesPerSec > 0) "${Formatter.formatShortFileSize(context, item.speedBytesPerSec)}/s" else ""
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.fileName, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "$sizeText • ${item.status.name} $speedText",
                                style = MaterialTheme.typography.labelSmall,
                                color = when (item.status) {
                                    TransferStatus.COMPLETED -> ConnectedGreen
                                    TransferStatus.FAILED -> ErrorCoral
                                    else -> CyanGlow
                                }
                            )
                        }
                        if (item.status != TransferStatus.TRANSFERRING) {
                            IconButton(onClick = { onRemoveFile(item.id) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove")
                            }
                        }
                    }
                    if (item.status == TransferStatus.TRANSFERRING || item.status == TransferStatus.COMPLETED) {
                        LinearProgressIndicator(
                            progress = { progress },
                            color = CyanGlow,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (!item.errorDetail.isNullOrBlank()) {
                        Text(item.errorDetail, style = MaterialTheme.typography.bodySmall, color = ErrorCoral)
                    }
                }
            }
        }

        // Transfer History
        if (state.preferences.transferHistory.isNotEmpty()) {
            item {
                Text(strings.transferHistoryTitle, style = MaterialTheme.typography.titleSmall, color = CyanGlow)
            }
            items(state.preferences.transferHistory.take(10), key = { "hist_${it.id}" }) { rec ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rec.fileName, style = MaterialTheme.typography.bodyMedium)
                            Text("${rec.targetName} • ${rec.note}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = if (rec.succeeded) "OK" else "FAIL",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (rec.succeeded) ConnectedGreen else ErrorCoral
                        )
                    }
                }
            }
        }
    }
}
