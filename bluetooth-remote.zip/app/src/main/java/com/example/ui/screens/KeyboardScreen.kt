package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.KeyboardReturn
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SpaceBar
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ConnectionState
import com.example.model.RemoteCommand
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.components.Tactile3DButton
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.SlateBorder
import com.example.ui.viewmodel.RemoteUiState

@Composable
fun KeyboardScreen(
    state: RemoteUiState,
    onSendText: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val animEnabled = !state.preferences.batterySaver.disableAnimations
    var quickInput by remember { mutableStateOf("") }
    var isShifted by remember { mutableStateOf(false) }
    var isSymbolsMode by remember { mutableStateOf(false) }

    val numRow = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val row1 = if (isSymbolsMode) {
        listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")")
    } else {
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    }
    val row2 = if (isSymbolsMode) {
        listOf("-", "_", "=", "+", "[", "]", "{", "}", ";", ":")
    } else {
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
    }
    val row3 = if (isSymbolsMode) {
        listOf("'", "\"", ",", ".", "/", "?", "\\", "|", "~", "`")
    } else {
        listOf("z", "x", "c", "v", "b", "n", "m")
    }

    LazyColumn(
        modifier = modifier
            .widthIn(max = 600.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = strings.keyboardTitle,
                style = MaterialTheme.typography.headlineSmall
            )
        }

        if (state.connectionState != ConnectionState.CONNECTED) {
            item {
                CapabilityNoticeBanner(text = strings.notConnectedBanner, isError = false)
            }
        }

        // Quick Text Box for pasting or typing paragraphs/passwords directly to TV
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = quickInput,
                        onValueChange = { quickInput = it },
                        placeholder = { Text(strings.quickSendPlaceholder) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("keyboard_quick_input")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (quickInput.isNotEmpty()) {
                                    onSendText(quickInput)
                                    quickInput = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("keyboard_send_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text(strings.sendText)
                        }
                        Button(
                            onClick = onSearch,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("keyboard_search_btn")
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = strings.search, tint = CyanGlow, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text(strings.search)
                        }
                    }
                }
            }
        }

        // Full Virtual Keyboard
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeyRow(
                        keys = numRow,
                        isShifted = false,
                        animationsEnabled = animEnabled,
                        onKeyPress = onSendText
                    )
                    KeyRow(
                        keys = row1,
                        isShifted = isShifted && !isSymbolsMode,
                        animationsEnabled = animEnabled,
                        onKeyPress = onSendText
                    )
                    KeyRow(
                        keys = row2,
                        isShifted = isShifted && !isSymbolsMode,
                        animationsEnabled = animEnabled,
                        onKeyPress = onSendText
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!isSymbolsMode) {
                            Tactile3DButton(
                                onClick = { isShifted = !isShifted },
                                isAccentActive = isShifted,
                                shape = RoundedCornerShape(10.dp),
                                animationsEnabled = animEnabled,
                                modifier = Modifier
                                    .weight(1.3f)
                                    .height(48.dp)
                            ) {
                                Icon(
                                    Icons.Filled.Upload,
                                    contentDescription = "Shift",
                                    tint = if (isShifted) Color.White else CyanGlow,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        row3.forEach { key ->
                            val label = if (isShifted && !isSymbolsMode) key.uppercase() else key
                            Tactile3DButton(
                                onClick = { onSendText(label) },
                                shape = RoundedCornerShape(10.dp),
                                animationsEnabled = animEnabled,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                            }
                        }
                        Tactile3DButton(
                            onClick = onBackspace,
                            shape = RoundedCornerShape(10.dp),
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1.3f)
                                .height(48.dp)
                                .testTag("keyboard_backspace_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = strings.backspace, tint = CyanGlow, modifier = Modifier.size(18.dp))
                        }
                    }

                    // Bottom Action Row: 123/Sym, Space, Enter
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Tactile3DButton(
                            onClick = { isSymbolsMode = !isSymbolsMode },
                            isAccentActive = isSymbolsMode,
                            shape = RoundedCornerShape(12.dp),
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1.4f)
                                .height(50.dp)
                                .testTag("keyboard_symbols_toggle")
                        ) {
                            Text(
                                text = if (isSymbolsMode) "ABC" else strings.symbolsKey,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isSymbolsMode) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Tactile3DButton(
                            onClick = { onSendText(" ") },
                            shape = RoundedCornerShape(12.dp),
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(2.6f)
                                .height(50.dp)
                                .testTag("keyboard_space_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Filled.SpaceBar, contentDescription = strings.space, modifier = Modifier.size(18.dp))
                                Text(strings.space, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                        Tactile3DButton(
                            onClick = onEnter,
                            isAccentActive = true,
                            shape = RoundedCornerShape(12.dp),
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1.4f)
                                .height(50.dp)
                                .testTag("keyboard_enter_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardReturn, contentDescription = strings.enter, tint = Color.White, modifier = Modifier.size(18.dp))
                                Text(strings.enter, style = MaterialTheme.typography.labelLarge, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyRow(
    keys: List<String>,
    isShifted: Boolean,
    animationsEnabled: Boolean,
    onKeyPress: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        keys.forEach { raw ->
            val label = if (isShifted) raw.uppercase() else raw
            Tactile3DButton(
                onClick = { onKeyPress(label) },
                shape = RoundedCornerShape(10.dp),
                animationsEnabled = animationsEnabled,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            }
        }
    }
}
