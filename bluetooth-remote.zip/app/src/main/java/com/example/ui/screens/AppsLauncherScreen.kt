package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.ConnectionMode
import com.example.model.TvAppShortcut
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.components.Tactile3DButton
import com.example.ui.components.VoiceControlOverlayCard
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.SlateBorder
import com.example.ui.viewmodel.RemoteUiState

@Composable
fun AppsLauncherScreen(
    state: RemoteUiState,
    onLaunchApp: (TvAppShortcut) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onTogglePinQuick: (String) -> Unit,
    onAddCustomApp: (String, String, String) -> Unit,
    onRefreshApps: () -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val animEnabled = !state.preferences.batterySaver.disableAnimations
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var uri by remember { mutableStateOf("https://") }
        var pkg by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add TV App Shortcut") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("App Name") })
                    OutlinedTextField(value = uri, onValueChange = { uri = it }, label = { Text("Deep Link URI") })
                    OutlinedTextField(value = pkg, onValueChange = { pkg = it }, label = { Text("Package Name (optional)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddCustomApp(name, uri, pkg)
                        showAddDialog = false
                    },
                    enabled = name.isNotBlank() && uri.isNotBlank()
                ) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    val filteredApps = state.preferences.pinnedQuickApps.filter {
        searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) ||
            it.packageName.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .widthIn(max = 600.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.appLauncherTitle, style = MaterialTheme.typography.headlineSmall)
                Row {
                    IconButton(onClick = onRefreshApps, modifier = Modifier.testTag("apps_refresh_btn")) {
                        Icon(Icons.Filled.Refresh, contentDescription = strings.refreshApps, tint = CyanGlow)
                    }
                    IconButton(onClick = { showAddDialog = true }, modifier = Modifier.testTag("apps_add_btn")) {
                        Icon(Icons.Filled.Add, contentDescription = "Add Shortcut", tint = CyanGlow)
                    }
                }
            }
        }

        // Honest Protocol Capability Banner
        item {
            val connectedMode = state.connectedDevice?.mode ?: state.selectedMode
            CapabilityNoticeBanner(
                text = if (connectedMode == ConnectionMode.BLUETOOTH_HID) {
                    strings.btAppEnumerationNotice
                } else {
                    strings.stockWifiAppNotice
                },
                isError = false
            )
        }

        // Voice Control Card
        item {
            VoiceControlOverlayCard(
                isListening = state.isVoiceListening,
                recognizedText = state.voiceRecognizedText,
                voiceError = state.voiceErrorMessage,
                onStartVoice = onStartVoice,
                onStopVoice = onStopVoice
            )
        }

        // Dedicated One-Click Hero Shortcuts: YouTube, Netflix, Play Store
        item {
            Text(strings.quickAppsTitle, style = MaterialTheme.typography.titleMedium, color = CyanGlow)
            Spacer(Modifier.height(8.dp))
            val heroes = state.preferences.pinnedQuickApps.take(3)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                heroes.forEach { app ->
                    val accent = when (app.iconKey) {
                        "youtube" -> Color(0xFFFF3D47)
                        "netflix" -> Color(0xFFE50914)
                        "store" -> Color(0xFF00C896)
                        else -> CobaltBlue
                    }
                    Tactile3DButton(
                        onClick = { onLaunchApp(app) },
                        accentColor = accent,
                        animationsEnabled = animEnabled,
                        modifier = Modifier
                            .weight(1f)
                            .height(74.dp)
                            .testTag("launcher_hero_${app.id}")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(iconForQuickApp(app.iconKey), contentDescription = app.name, tint = accent)
                            Text(app.name, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                placeholder = { Text(strings.searchAppsHint) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("apps_search_input")
            )
        }

        val recent = filteredApps.filter { it.lastLaunchedMs > 0L }.sortedByDescending { it.lastLaunchedMs }
        if (recent.isNotEmpty()) {
            item {
                Text(strings.recentApps, style = MaterialTheme.typography.titleSmall, color = CyanGlow)
            }
            items(recent, key = { "rec_${it.id}" }) { app ->
                AppShortcutRow(
                    app = app,
                    onLaunch = { onLaunchApp(app) },
                    onToggleFavorite = { onToggleFavorite(app.id) },
                    onTogglePin = { onTogglePinQuick(app.id) }
                )
            }
        }

        item {
            Text(strings.allShortcuts, style = MaterialTheme.typography.titleSmall, color = CyanGlow)
        }

        items(filteredApps, key = { "all_${it.id}" }) { app ->
            AppShortcutRow(
                app = app,
                onLaunch = { onLaunchApp(app) },
                onToggleFavorite = { onToggleFavorite(app.id) },
                onTogglePin = { onTogglePinQuick(app.id) }
            )
        }
    }
}

@Composable
private fun AppShortcutRow(
    app: TvAppShortcut,
    onLaunch: () -> Unit,
    onToggleFavorite: () -> Unit,
    onTogglePin: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, SlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(iconForQuickApp(app.iconKey), contentDescription = null, tint = CyanGlow)
                Column {
                    Text(app.name, style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = app.packageName.ifBlank { app.deepLinkUri },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onTogglePin) {
                    Icon(
                        imageVector = Icons.Filled.PushPin,
                        contentDescription = "Pin Quick App",
                        tint = if (app.isPinnedQuickApp) CyanGlow else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        imageVector = if (app.isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (app.isFavorite) CyanGlow else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = onLaunch,
                    colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue)
                ) {
                    Text("Open")
                }
            }
        }
    }
}
