package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.ConnectionMode
import com.example.model.RemoteCommand
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.components.Tactile3DButton
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.SlateBevelHighlight
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateElevated
import com.example.ui.viewmodel.RemoteUiState
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MouseAndTouchpadScreen(
    state: RemoteUiState,
    onToggleMouseMode: (Boolean) -> Unit,
    onTouchpadMove: (Float, Float) -> Unit,
    onTouchpadSwipeCommand: (RemoteCommand) -> Unit,
    onMouseClick: (Boolean, Boolean) -> Unit,
    onToggleDragLock: () -> Unit,
    onMouseScroll: (Int) -> Unit,
    onSetAirMouseEnabled: (Boolean) -> Unit,
    onCalibrateAirMouse: () -> Unit,
    onUpdateTuning: (Float, Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val animEnabled = !state.preferences.batterySaver.disableAnimations
    var selectedTab by remember { mutableIntStateOf(0) }
    var lastPointerPos by remember { mutableStateOf<Offset?>(null) }

    var airSens by remember(state.preferences.airMouseSensitivity) {
        mutableFloatStateOf(state.preferences.airMouseSensitivity)
    }
    var airSpeed by remember(state.preferences.airMousePointerSpeed) {
        mutableFloatStateOf(state.preferences.airMousePointerSpeed)
    }
    var touchpadSens by remember(state.preferences.touchpadSensitivity) {
        mutableFloatStateOf(state.preferences.touchpadSensitivity)
    }

    val connectedMode = state.connectedDevice?.mode
    val isWifiConnected = connectedMode == ConnectionMode.WIFI_ANDROID_TV

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SecondaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = CyanGlow
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(strings.touchpadTab) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(strings.airMouseTab) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (isWifiConnected) {
                item {
                    CapabilityNoticeBanner(
                        text = strings.wifiMouseLimitationNotice,
                        isError = false
                    )
                }
            }

            if (selectedTab == 0) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (state.isMousePointerMode && !isWifiConnected) strings.mouseModeToggle else strings.swipeDpadModeLabel,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = strings.singleTapClickHint,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = state.isMousePointerMode && !isWifiConnected,
                                onCheckedChange = onToggleMouseMode,
                                modifier = Modifier.testTag("mouse_mode_switch")
                            )
                        }
                    }
                }

                // Large Interactive Touchpad Surface
                item {
                    val padShape = RoundedCornerShape(26.dp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .clip(padShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(SlateElevated, SlateCard, Color(0xFF0A1120))
                                )
                            )
                            .border(1.5.dp, SlateBevelHighlight.copy(alpha = 0.7f), padShape)
                            .pointerInput(state.isMousePointerMode, isWifiConnected) {
                                detectTapGestures(
                                    onTap = { onMouseClick(false, false) },
                                    onDoubleTap = { onMouseClick(false, true) },
                                    onLongPress = { onToggleDragLock() }
                                )
                            }
                            .pointerInput(state.isMousePointerMode, isWifiConnected) {
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false)
                                    var accumSwipeX = 0f
                                    var accumSwipeY = 0f
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        val pressed = event.changes.filter { it.pressed }
                                        if (pressed.isEmpty()) {
                                            lastPointerPos = null
                                            break
                                        }
                                        if (pressed.size >= 2) {
                                            // Two-finger vertical scroll
                                            val avgDeltaY = pressed.map { it.position.y - it.previousPosition.y }.average().toFloat()
                                            if (abs(avgDeltaY) > 6f) {
                                                onMouseScroll(if (avgDeltaY > 0) -1 else 1)
                                            }
                                        } else {
                                            val change = pressed.first()
                                            val dx = change.position.x - change.previousPosition.x
                                            val dy = change.position.y - change.previousPosition.y
                                            lastPointerPos = change.position
                                            if (state.isMousePointerMode && !isWifiConnected) {
                                                if (abs(dx) > 0.5f || abs(dy) > 0.5f) {
                                                    onTouchpadMove(dx * 0.8f, dy * 0.8f)
                                                }
                                            } else {
                                                accumSwipeX += dx
                                                accumSwipeY += dy
                                                val threshold = 64f
                                                if (abs(accumSwipeX) > threshold) {
                                                    onTouchpadSwipeCommand(
                                                        if (accumSwipeX > 0) RemoteCommand.DPAD_RIGHT else RemoteCommand.DPAD_LEFT
                                                    )
                                                    accumSwipeX = 0f
                                                    accumSwipeY = 0f
                                                } else if (abs(accumSwipeY) > threshold) {
                                                    onTouchpadSwipeCommand(
                                                        if (accumSwipeY > 0) RemoteCommand.DPAD_DOWN else RemoteCommand.DPAD_UP
                                                    )
                                                    accumSwipeX = 0f
                                                    accumSwipeY = 0f
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            .testTag("touchpad_surface"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.TouchApp,
                                contentDescription = strings.touchpadTab,
                                tint = CyanGlow.copy(alpha = 0.7f),
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = strings.twoFingerScrollHint,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        lastPointerPos?.let { pos ->
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(
                                        start = (pos.x / 3f).dp.coerceIn(0.dp, 280.dp),
                                        top = (pos.y / 3f).dp.coerceIn(0.dp, 240.dp)
                                    )
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(CyanGlow.copy(alpha = 0.25f))
                                    .border(1.dp, CyanGlow, CircleShape)
                            )
                        }
                    }
                }

                // Mouse Buttons Row: Left Click, Drag Lock, Right Click
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Tactile3DButton(
                            onClick = { onMouseClick(false, false) },
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp)
                                .testTag("mouse_left_click_btn")
                        ) {
                            Text(strings.leftClick, style = MaterialTheme.typography.labelLarge)
                        }
                        Tactile3DButton(
                            onClick = onToggleDragLock,
                            isAccentActive = state.isDragLocked,
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp)
                                .testTag("mouse_drag_lock_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Filled.PanTool, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text(strings.dragHold, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                        Tactile3DButton(
                            onClick = { onMouseClick(true, false) },
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp)
                                .testTag("mouse_right_click_btn")
                        ) {
                            Text(strings.rightClick, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }

                // Touchpad Sensitivity Slider
                item {
                    SensitivitySliderCard(
                        title = strings.gestureSensitivity,
                        value = touchpadSens,
                        onValueChange = {
                            touchpadSens = it
                            onUpdateTuning(airSens, airSpeed, it)
                        }
                    )
                }
            } else {
                // Air Mouse Tab (Module 5)
                if (!state.hasAirMouseSensor || isWifiConnected) {
                    item {
                        CapabilityNoticeBanner(
                            text = strings.airMouseUnavailableGyro,
                            isError = true
                        )
                    }
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (state.isAirMouseActive) CyanGlow else SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (state.isAirMouseActive) CobaltBlue.copy(alpha = 0.28f) else SlateElevated,
                                border = BorderStroke(2.dp, if (state.isAirMouseActive) CyanGlow else SlateBorder),
                                modifier = Modifier.size(110.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.Mouse,
                                        contentDescription = strings.airMouseTab,
                                        tint = if (state.isAirMouseActive) CyanGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(48.dp)
                                    )
                                }
                            }
                            Text(
                                text = if (state.hasGyroscope) "Gyroscope Ready" else if (state.hasAirMouseSensor) "Accelerometer Tilt Fallback" else "No Motion Sensor",
                                style = MaterialTheme.typography.labelMedium,
                                color = CyanGlow
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(strings.airMouseEnable, style = MaterialTheme.typography.titleSmall)
                                Switch(
                                    checked = state.isAirMouseActive,
                                    onCheckedChange = onSetAirMouseEnabled,
                                    modifier = Modifier.testTag("air_mouse_switch")
                                )
                            }
                            Button(
                                onClick = onCalibrateAirMouse,
                                colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("air_mouse_calibrate_btn")
                            ) {
                                Icon(Icons.Filled.CenterFocusStrong, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.size(8.dp))
                                Text(strings.calibrate)
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Tactile3DButton(
                            onClick = { onMouseClick(false, false) },
                            isAccentActive = true,
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                        ) {
                            Text(strings.leftClick, style = MaterialTheme.typography.titleSmall, color = Color.White)
                        }
                        Tactile3DButton(
                            onClick = { onMouseClick(true, false) },
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                        ) {
                            Text(strings.rightClick, style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }

                item {
                    SensitivitySliderCard(
                        title = strings.sensitivity,
                        value = airSens,
                        onValueChange = {
                            airSens = it
                            onUpdateTuning(it, airSpeed, touchpadSens)
                        }
                    )
                }

                item {
                    SensitivitySliderCard(
                        title = strings.pointerSpeed,
                        value = airSpeed,
                        onValueChange = {
                            airSpeed = it
                            onUpdateTuning(airSens, it, touchpadSens)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SensitivitySliderCard(
    title: String,
    value: Float,
    onValueChange: (Float) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, SlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text("${String.format("%.1f", value)}x", style = MaterialTheme.typography.labelMedium, color = CyanGlow)
            }
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = 0.4f..2.5f,
                colors = SliderDefaults.colors(
                    thumbColor = CyanGlow,
                    activeTrackColor = CobaltBlue
                )
            )
        }
    }
}
