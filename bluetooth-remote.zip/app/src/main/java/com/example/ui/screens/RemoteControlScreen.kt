package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.BrightnessLow
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Screenshot
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ConnectionState
import com.example.model.RemoteButtonSize
import com.example.model.RemoteCommand
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.components.ConnectionStatusPill
import com.example.ui.components.GlowingCircularDpad
import com.example.ui.components.Tactile3DButton
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.PowerCrimson
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateElevated
import com.example.ui.viewmodel.RemoteUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemoteControlScreen(
    state: RemoteUiState,
    onCommand: (RemoteCommand, Boolean) -> Unit,
    onTriggerTvScreenshot: () -> Unit,
    onOpenVoice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val animEnabled = !state.preferences.batterySaver.disableAnimations
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SecondaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = CyanGlow
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(strings.standardRemoteTab) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(strings.customRemoteTab) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ConnectionStatusPill(
                        state = state.connectionState,
                        mode = state.connectedDevice?.mode ?: state.selectedMode,
                        deviceName = state.connectedDevice?.name,
                        animationsEnabled = animEnabled
                    )
                    Tactile3DButton(
                        onClick = onTriggerTvScreenshot,
                        animationsEnabled = animEnabled,
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("remote_screenshot_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Filled.Screenshot, contentDescription = strings.triggerTvScreenshot, tint = CyanGlow, modifier = Modifier.size(18.dp))
                            Text("Shot", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            if (state.connectionState != ConnectionState.CONNECTED) {
                item {
                    CapabilityNoticeBanner(text = strings.notConnectedBanner, isError = false)
                }
            }

            if (selectedTab == 0) {
                // Top Row: Power, Settings, Menu, Search
                item {
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                        border = BorderStroke(1.dp, SlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                Tactile3DButton(
                                    onClick = { onCommand(RemoteCommand.POWER, true) },
                                    shape = CircleShape,
                                    accentColor = PowerCrimson,
                                    isAccentActive = true,
                                    animationsEnabled = animEnabled,
                                    modifier = Modifier
                                        .size(56.dp)
                                        .testTag("remote_power_btn")
                                ) {
                                    Icon(Icons.Filled.PowerSettingsNew, contentDescription = strings.power, tint = Color.White)
                                }
                                RemoteRoundAction(
                                    icon = Icons.Filled.Settings,
                                    label = strings.settings,
                                    onClick = { onCommand(RemoteCommand.SETTINGS, false) },
                                    animationsEnabled = animEnabled,
                                    tag = "remote_settings_btn"
                                )
                                RemoteRoundAction(
                                    icon = Icons.Filled.Menu,
                                    label = strings.menu,
                                    onClick = { onCommand(RemoteCommand.MENU, false) },
                                    animationsEnabled = animEnabled,
                                    tag = "remote_menu_btn"
                                )
                                RemoteRoundAction(
                                    icon = Icons.Filled.Search,
                                    label = strings.search,
                                    onClick = { onCommand(RemoteCommand.SEARCH, false) },
                                    animationsEnabled = animEnabled,
                                    tag = "remote_search_btn"
                                )
                            }

                            // Center Glowing Circular 3D D-Pad
                            GlowingCircularDpad(
                                onCommand = { cmd -> onCommand(cmd, cmd == RemoteCommand.DPAD_OK) },
                                animationsEnabled = animEnabled,
                                diameter = 248.dp
                            )

                            // Home & Back Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Tactile3DButton(
                                    onClick = { onCommand(RemoteCommand.BACK, true) },
                                    animationsEnabled = animEnabled,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("remote_back_btn")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = CyanGlow)
                                        Text(strings.back, style = MaterialTheme.typography.titleSmall)
                                    }
                                }
                                Tactile3DButton(
                                    onClick = { onCommand(RemoteCommand.HOME, true) },
                                    isAccentActive = true,
                                    animationsEnabled = animEnabled,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("remote_home_btn")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Filled.Home, contentDescription = strings.home, tint = Color.White)
                                        Text(strings.home, style = MaterialTheme.typography.titleSmall, color = Color.White)
                                    }
                                }
                            }

                            // Volume & Channel Rockers + Mute
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Volume Rocker
                                RockerPill(
                                    topIcon = Icons.Filled.Add,
                                    topLabel = strings.volumeUp,
                                    bottomIcon = Icons.Filled.Remove,
                                    bottomLabel = strings.volumeDown,
                                    centerLabel = "VOL",
                                    onTop = { onCommand(RemoteCommand.VOLUME_UP, false) },
                                    onBottom = { onCommand(RemoteCommand.VOLUME_DOWN, false) },
                                    animationsEnabled = animEnabled
                                )

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Tactile3DButton(
                                        onClick = { onCommand(RemoteCommand.MUTE, true) },
                                        shape = CircleShape,
                                        animationsEnabled = animEnabled,
                                        modifier = Modifier
                                            .size(62.dp)
                                            .testTag("remote_mute_btn")
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.VolumeOff, contentDescription = strings.mute, tint = CyanGlow)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Tactile3DButton(
                                            onClick = { onCommand(RemoteCommand.BRIGHTNESS_DOWN, false) },
                                            shape = CircleShape,
                                            animationsEnabled = animEnabled,
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(Icons.Filled.BrightnessLow, contentDescription = strings.brightnessDown, modifier = Modifier.size(18.dp))
                                        }
                                        Tactile3DButton(
                                            onClick = { onCommand(RemoteCommand.BRIGHTNESS_UP, false) },
                                            shape = CircleShape,
                                            animationsEnabled = animEnabled,
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(Icons.Filled.BrightnessHigh, contentDescription = strings.brightnessUp, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }

                                // Channel Rocker
                                RockerPill(
                                    topIcon = Icons.Filled.KeyboardArrowUp,
                                    topLabel = strings.channelUp,
                                    bottomIcon = Icons.Filled.KeyboardArrowDown,
                                    bottomLabel = strings.channelDown,
                                    centerLabel = "CH",
                                    onTop = { onCommand(RemoteCommand.CHANNEL_UP, false) },
                                    onBottom = { onCommand(RemoteCommand.CHANNEL_DOWN, false) },
                                    animationsEnabled = animEnabled
                                )
                            }

                            // Media Transport Deck
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                RemoteTransportButton(Icons.Filled.SkipPrevious, strings.previous, animEnabled) {
                                    onCommand(RemoteCommand.PREVIOUS, false)
                                }
                                RemoteTransportButton(Icons.Filled.FastRewind, strings.rewind, animEnabled) {
                                    onCommand(RemoteCommand.REWIND, false)
                                }
                                Tactile3DButton(
                                    onClick = { onCommand(RemoteCommand.PLAY_PAUSE, true) },
                                    shape = CircleShape,
                                    isAccentActive = true,
                                    animationsEnabled = animEnabled,
                                    modifier = Modifier
                                        .size(56.dp)
                                        .testTag("remote_play_pause_btn")
                                ) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = strings.playPause, tint = Color.White)
                                }
                                RemoteTransportButton(Icons.Filled.Stop, strings.stop, animEnabled) {
                                    onCommand(RemoteCommand.STOP, false)
                                }
                                RemoteTransportButton(Icons.Filled.FastForward, strings.fastForward, animEnabled) {
                                    onCommand(RemoteCommand.FAST_FORWARD, false)
                                }
                                RemoteTransportButton(Icons.Filled.SkipNext, strings.nextTrack, animEnabled) {
                                    onCommand(RemoteCommand.NEXT, false)
                                }
                            }
                        }
                    }
                }
            } else {
                // Custom Remote Layout Renderer (Module 11)
                val layout = state.preferences.customLayouts.firstOrNull {
                    it.id == state.preferences.activeLayoutId
                } ?: state.preferences.customLayouts.firstOrNull()

                item {
                    Text(
                        text = layout?.name ?: strings.customRemoteTab,
                        style = MaterialTheme.typography.titleMedium,
                        color = CyanGlow
                    )
                }

                if (layout != null) {
                    val rows = layout.buttons.sortedBy { it.orderIndex }.chunked(2)
                    rows.forEach { pair ->
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                pair.forEach { btn ->
                                    val heightDp = when (btn.size) {
                                        RemoteButtonSize.SMALL -> 54.dp
                                        RemoteButtonSize.MEDIUM -> 68.dp
                                        RemoteButtonSize.LARGE -> 84.dp
                                    }
                                    Tactile3DButton(
                                        onClick = { onCommand(btn.command, true) },
                                        animationsEnabled = animEnabled,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(heightDp)
                                    ) {
                                        Text(
                                            text = btn.label,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                                if (pair.size == 1) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RemoteRoundAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    animationsEnabled: Boolean,
    tag: String
) {
    Tactile3DButton(
        onClick = onClick,
        shape = CircleShape,
        animationsEnabled = animationsEnabled,
        modifier = Modifier
            .size(56.dp)
            .testTag(tag)
    ) {
        Icon(icon, contentDescription = label, tint = CyanGlow)
    }
}

@Composable
private fun RemoteTransportButton(
    icon: ImageVector,
    label: String,
    animationsEnabled: Boolean,
    onClick: () -> Unit
) {
    Tactile3DButton(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        animationsEnabled = animationsEnabled,
        modifier = Modifier.size(48.dp)
    ) {
        Icon(icon, contentDescription = label, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun RockerPill(
    topIcon: ImageVector,
    topLabel: String,
    bottomIcon: ImageVector,
    bottomLabel: String,
    centerLabel: String,
    onTop: () -> Unit,
    onBottom: () -> Unit,
    animationsEnabled: Boolean
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = if (isDark) SlateCard else Color(0xFFE5EDF9),
        border = BorderStroke(1.dp, SlateBorder),
        shadowElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Tactile3DButton(
                onClick = onTop,
                shape = CircleShape,
                animationsEnabled = animationsEnabled,
                modifier = Modifier.size(54.dp)
            ) {
                Icon(topIcon, contentDescription = topLabel, tint = CyanGlow)
            }
            Text(
                text = centerLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Tactile3DButton(
                onClick = onBottom,
                shape = CircleShape,
                animationsEnabled = animationsEnabled,
                modifier = Modifier.size(54.dp)
            ) {
                Icon(bottomIcon, contentDescription = bottomLabel, tint = CyanGlow)
            }
        }
    }
}
