package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ConnectionMode
import com.example.model.ConnectionState
import com.example.model.TvAppShortcut
import com.example.model.TvDeviceIcon
import com.example.model.TvProfile
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.components.ConnectionStatusPill
import com.example.ui.components.PhoneBatteryBadge
import com.example.ui.components.Tactile3DButton
import com.example.ui.components.VoiceControlOverlayCard
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateBorder
import com.example.ui.viewmodel.RemoteUiState

@Composable
fun HomeDashboardScreen(
    state: RemoteUiState,
    onSelectMode: (ConnectionMode) -> Unit,
    onOpenDiscovery: () -> Unit,
    onScanDevices: () -> Unit,
    onDisconnect: () -> Unit,
    onReconnectProfile: (TvProfile) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onLaunchQuickApp: (TvAppShortcut) -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onDismissError: () -> Unit,
    onDismissNotice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val animEnabled = !state.preferences.batterySaver.disableAnimations

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWide = maxWidth >= 700.dp

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner Card with Logo, Title, Status, Battery
            item {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box {
                        Image(
                            painter = painterResource(id = R.drawable.img_tv_connect_banner),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(168.dp)
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(ObsidianBg.copy(alpha = 0.35f), ObsidianBg.copy(alpha = 0.88f))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = CobaltBlue.copy(alpha = 0.25f),
                                        border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.6f)),
                                        modifier = Modifier.size(46.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.SettingsRemote,
                                                contentDescription = strings.appTitle,
                                                tint = CyanGlow,
                                                modifier = Modifier.size(26.dp)
                                            )
                                        }
                                    }
                                    Column {
                                        Text(
                                            text = strings.appTitle,
                                            style = MaterialTheme.typography.titleLarge,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = strings.appTagline,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFFB5C7E8)
                                        )
                                    }
                                }
                                PhoneBatteryBadge(battery = state.batteryStatus)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ConnectionStatusPill(
                                    state = state.connectionState,
                                    mode = state.connectedDevice?.mode ?: state.selectedMode,
                                    deviceName = state.connectedDevice?.name,
                                    animationsEnabled = animEnabled
                                )
                                if (state.connectionState == ConnectionState.CONNECTED) {
                                    OutlinedButton(
                                        onClick = onDisconnect,
                                        border = BorderStroke(1.dp, ErrorCoral.copy(alpha = 0.7f)),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorCoral),
                                        modifier = Modifier.testTag("home_disconnect_btn")
                                    ) {
                                        Icon(Icons.Filled.LinkOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.disconnect)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (!state.activeErrorMessage.isNullOrBlank()) {
                item {
                    CapabilityNoticeBanner(
                        text = state.activeErrorMessage,
                        isError = true,
                        onDismiss = onDismissError
                    )
                }
            }

            if (!state.statusNoticeMessage.isNullOrBlank()) {
                item {
                    CapabilityNoticeBanner(
                        text = state.statusNoticeMessage,
                        isError = false,
                        onDismiss = onDismissNotice
                    )
                }
            }

            // Connection Mode Switcher + Connect & Scan Actions
            item {
                if (isWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ModeSelectorCard(
                            selectedMode = state.selectedMode,
                            onSelectMode = onSelectMode,
                            animationsEnabled = animEnabled,
                            modifier = Modifier.weight(1f)
                        )
                        DashboardActionButtonsCard(
                            onOpenDiscovery = onOpenDiscovery,
                            onScanDevices = onScanDevices,
                            animationsEnabled = animEnabled,
                            modifier = Modifier.weight(1f)
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        ModeSelectorCard(
                            selectedMode = state.selectedMode,
                            onSelectMode = onSelectMode,
                            animationsEnabled = animEnabled
                        )
                        DashboardActionButtonsCard(
                            onOpenDiscovery = onOpenDiscovery,
                            onScanDevices = onScanDevices,
                            animationsEnabled = animEnabled
                        )
                    }
                }
            }

            // Voice Control Bar
            item {
                VoiceControlOverlayCard(
                    isListening = state.isVoiceListening,
                    recognizedText = state.voiceRecognizedText,
                    voiceError = state.voiceErrorMessage,
                    onStartVoice = onStartVoice,
                    onStopVoice = onStopVoice
                )
            }

            // One-Click Quick TV Apps
            item {
                Text(
                    text = strings.quickAppsTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(8.dp))
                val quickApps = state.preferences.pinnedQuickApps.filter { it.isPinnedQuickApp }
                    .ifEmpty { state.preferences.pinnedQuickApps.take(3) }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(quickApps, key = { it.id }) { app ->
                        val brandAccent = when (app.iconKey) {
                            "youtube" -> Color(0xFFFF3D47)
                            "netflix" -> Color(0xFFE50914)
                            "store" -> Color(0xFF00C896)
                            else -> CobaltBlue
                        }
                        Tactile3DButton(
                            onClick = { onLaunchQuickApp(app) },
                            accentColor = brandAccent,
                            isAccentActive = false,
                            animationsEnabled = animEnabled,
                            modifier = Modifier
                                .height(64.dp)
                                .testTag("quick_app_${app.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = iconForQuickApp(app.iconKey),
                                    contentDescription = app.name,
                                    tint = brandAccent,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = app.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Favorite & Previously Paired TV Profiles
            item {
                Text(
                    text = strings.previouslyPairedDevices,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            val sortedProfiles = state.preferences.profiles.sortedByDescending { it.isFavorite }
            if (sortedProfiles.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CastConnected,
                                contentDescription = null,
                                tint = CyanGlow,
                                modifier = Modifier.size(34.dp)
                            )
                            Text(
                                text = strings.noSavedDevicesHint,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(sortedProfiles, key = { it.id }) { profile ->
                    val isLiveConnected = state.connectedDevice?.id == profile.id &&
                        state.connectionState == ConnectionState.CONNECTED
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(
                            1.dp,
                            if (isLiveConnected) CyanGlow else MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = CobaltBlue.copy(alpha = 0.16f),
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = iconForTvProfile(profile.icon),
                                            contentDescription = null,
                                            tint = CyanGlow,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = profile.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${if (profile.mode == ConnectionMode.BLUETOOTH_HID) strings.modeBluetoothHid else strings.modeWifiTv} • ${profile.addressOrHost}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { onToggleFavorite(profile.id) }) {
                                    Icon(
                                        imageVector = if (profile.isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                                        contentDescription = "Favorite",
                                        tint = if (profile.isFavorite) CyanGlow else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(
                                    onClick = {
                                        if (isLiveConnected) onDisconnect() else onReconnectProfile(profile)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isLiveConnected) ErrorCoral else CobaltBlue
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = if (isLiveConnected) strings.disconnect else strings.reconnect,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeSelectorCard(
    selectedMode: ConnectionMode,
    onSelectMode: (ConnectionMode) -> Unit,
    animationsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Tactile3DButton(
            onClick = { onSelectMode(ConnectionMode.BLUETOOTH_HID) },
            isAccentActive = selectedMode == ConnectionMode.BLUETOOTH_HID,
            animationsEnabled = animationsEnabled,
            modifier = Modifier
                .weight(1f)
                .height(62.dp)
                .testTag("mode_bluetooth_btn")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(horizontal = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Bluetooth,
                    contentDescription = null,
                    tint = if (selectedMode == ConnectionMode.BLUETOOTH_HID) Color.White else CyanGlow,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = strings.modeBluetoothHid,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selectedMode == ConnectionMode.BLUETOOTH_HID) Color.White else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Tactile3DButton(
            onClick = { onSelectMode(ConnectionMode.WIFI_ANDROID_TV) },
            isAccentActive = selectedMode == ConnectionMode.WIFI_ANDROID_TV,
            animationsEnabled = animationsEnabled,
            modifier = Modifier
                .weight(1f)
                .height(62.dp)
                .testTag("mode_wifi_btn")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(horizontal = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Wifi,
                    contentDescription = null,
                    tint = if (selectedMode == ConnectionMode.WIFI_ANDROID_TV) Color.White else CyanGlow,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = strings.modeWifiTv,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selectedMode == ConnectionMode.WIFI_ANDROID_TV) Color.White else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun DashboardActionButtonsCard(
    onOpenDiscovery: () -> Unit,
    onScanDevices: () -> Unit,
    animationsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Tactile3DButton(
            onClick = onOpenDiscovery,
            isAccentActive = true,
            animationsEnabled = animationsEnabled,
            modifier = Modifier
                .weight(1f)
                .height(54.dp)
                .testTag("connect_device_btn")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Text(strings.connectDevice, style = MaterialTheme.typography.labelLarge, color = Color.White)
            }
        }
        Tactile3DButton(
            onClick = {
                onScanDevices()
                onOpenDiscovery()
            },
            isAccentActive = false,
            animationsEnabled = animationsEnabled,
            modifier = Modifier
                .weight(1f)
                .height(54.dp)
                .testTag("scan_devices_btn")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null, tint = CyanGlow, modifier = Modifier.size(18.dp))
                Text(strings.scanDevices, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

fun iconForQuickApp(key: String) = when (key) {
    "youtube" -> Icons.Filled.SmartDisplay
    "netflix" -> Icons.Filled.LiveTv
    "store" -> Icons.Filled.Shop
    else -> Icons.Filled.PlayArrow
}

fun iconForTvProfile(icon: TvDeviceIcon) = when (icon) {
    TvDeviceIcon.LIVING_ROOM_TV -> Icons.Filled.Tv
    TvDeviceIcon.ANDROID_BOX -> Icons.Filled.CastConnected
    TvDeviceIcon.PROJECTOR -> Icons.Filled.Videocam
    TvDeviceIcon.BEDROOM_TV -> Icons.Filled.Tv
    TvDeviceIcon.MONITOR -> Icons.Filled.Monitor
}
