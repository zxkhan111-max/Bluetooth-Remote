package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.BatteryStatus
import com.example.model.ConnectionMode
import com.example.model.ConnectionState
import com.example.model.HidProfileAvailability
import com.example.model.HidProfileStatus
import com.example.model.HidProtocolMode
import com.example.model.RemoteCommand
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.ConnectingAmber
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DeepBlue
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.SlateBevelHighlight
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateElevated

@Composable
fun Tactile3DButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    accentColor: Color = CobaltBlue,
    isAccentActive: Boolean = false,
    enabled: Boolean = true,
    animationsEnabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && animationsEnabled) 0.94f else 1f,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 500f),
        label = "3d_press_scale"
    )

    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val topColor = when {
        isAccentActive -> accentColor.copy(alpha = 0.92f)
        isDark -> SlateElevated
        else -> Color(0xFFFFFFFF)
    }
    val bottomColor = when {
        isAccentActive -> DeepBlue
        isDark -> SlateCard
        else -> Color(0xFFDCE5F4)
    }
    val borderColor = when {
        isAccentActive -> CyanGlow.copy(alpha = 0.8f)
        isDark -> SlateBevelHighlight.copy(alpha = 0.65f)
        else -> Color(0xFFB6C5DF)
    }

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (enabled) 1f else 0.55f
            }
            .shadow(
                elevation = if (pressed) 2.dp else if (isAccentActive) 12.dp else 6.dp,
                shape = shape,
                ambientColor = if (isAccentActive) accentColor else Color.Black,
                spotColor = if (isAccentActive) CyanGlow else Color.Black
            )
            .clip(shape)
            .background(Brush.verticalGradient(listOf(topColor, bottomColor)))
            .border(1.dp, borderColor, shape)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(color = CyanGlow),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
fun GlowingCircularDpad(
    onCommand: (RemoteCommand) -> Unit,
    animationsEnabled: Boolean,
    modifier: Modifier = Modifier,
    diameter: Dp = 246.dp
) {
    val strings = LocalAppStrings.current
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val ringBrush = if (isDark) {
        Brush.radialGradient(
            colors = listOf(SlateElevated, SlateCard, Color(0xFF0A1120))
        )
    } else {
        Brush.radialGradient(
            colors = listOf(Color(0xFFFFFFFF), Color(0xFFE3ECFA), Color(0xFFD0DCF0))
        )
    }

    Box(
        modifier = modifier
            .size(diameter)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            CobaltBlue.copy(alpha = 0.28f),
                            CyanGlow.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = size.minDimension * 0.62f
                    )
                )
            }
            .shadow(16.dp, CircleShape, spotColor = CobaltBlue)
            .clip(CircleShape)
            .background(ringBrush)
            .border(1.5.dp, SlateBevelHighlight.copy(alpha = 0.7f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        // Up
        IconButton(
            onClick = { onCommand(RemoteCommand.DPAD_UP) },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 10.dp)
                .size(56.dp)
                .testTag("dpad_up")
        ) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowUp,
                contentDescription = "Up",
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(34.dp)
            )
        }
        // Down
        IconButton(
            onClick = { onCommand(RemoteCommand.DPAD_DOWN) },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .size(56.dp)
                .testTag("dpad_down")
        ) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowDown,
                contentDescription = "Down",
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(34.dp)
            )
        }
        // Left
        IconButton(
            onClick = { onCommand(RemoteCommand.DPAD_LEFT) },
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 10.dp)
                .size(56.dp)
                .testTag("dpad_left")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = "Left",
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(34.dp)
            )
        }
        // Right
        IconButton(
            onClick = { onCommand(RemoteCommand.DPAD_RIGHT) },
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 10.dp)
                .size(56.dp)
                .testTag("dpad_right")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Right",
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(34.dp)
            )
        }

        // Center Blue Glowing OK Button
        Tactile3DButton(
            onClick = { onCommand(RemoteCommand.DPAD_OK) },
            shape = CircleShape,
            accentColor = CobaltBlue,
            isAccentActive = true,
            animationsEnabled = animationsEnabled,
            modifier = Modifier
                .size(94.dp)
                .testTag("dpad_ok")
        ) {
            Text(
                text = strings.ok,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
fun ConnectionStatusPill(
    state: ConnectionState,
    mode: ConnectionMode,
    deviceName: String?,
    animationsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val (label, dotColor) = when (state) {
        ConnectionState.CONNECTED -> (deviceName ?: strings.statusConnected) to ConnectedGreen
        ConnectionState.CONNECTING -> strings.statusConnecting to ConnectingAmber
        ConnectionState.PAIRING_REQUIRED -> strings.statusPairingRequired to CyanGlow
        ConnectionState.SCANNING -> strings.statusScanning to CyanGlow
        ConnectionState.ERROR -> strings.statusError to ErrorCoral
        ConnectionState.DISCONNECTED -> strings.statusDisconnected to MaterialTheme.colorScheme.onSurfaceVariant
    }

    val animatedDotColor by animateColorAsState(targetValue = dotColor, label = "dot_color")
    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse_alpha"
    )
    val effectiveAlpha = if (
        animationsEnabled &&
        (state == ConnectionState.SCANNING || state == ConnectionState.CONNECTING)
    ) pulseAlpha else 1f

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
        border = BorderStroke(1.dp, animatedDotColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(animatedDotColor.copy(alpha = effectiveAlpha))
            )
            Icon(
                imageVector = if (mode == ConnectionMode.BLUETOOTH_HID) Icons.Filled.Bluetooth else Icons.Filled.Wifi,
                contentDescription = null,
                tint = animatedDotColor,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun PhoneBatteryBadge(battery: BatteryStatus, modifier: Modifier = Modifier) {
    if (battery.percentage < 0) return
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (battery.isCharging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryStd,
                contentDescription = "Phone Battery",
                tint = if (battery.percentage <= 20) ErrorCoral else CyanGlow,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "${battery.percentage}%",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun CapabilityNoticeBanner(
    text: String,
    isError: Boolean = false,
    icon: ImageVector = if (isError) Icons.Filled.WarningAmber else Icons.Filled.Info,
    onDismiss: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val accent = if (isError) ErrorCoral else CyanGlow
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = accent.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            if (onDismiss != null) {
                TextButton(onClick = onDismiss) {
                    Text("OK", style = MaterialTheme.typography.labelLarge, color = accent)
                }
            }
        }
    }
}

@Composable
fun VoiceControlOverlayCard(
    isListening: Boolean,
    recognizedText: String,
    voiceError: String?,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, if (isListening) CyanGlow else SlateBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                        contentDescription = strings.voiceControl,
                        tint = if (isListening) ErrorCoral else CyanGlow,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = strings.voiceControl,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isListening) strings.listeningSpeakNow else "English & বাংলা • Local SpeechRecognizer",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Button(
                    onClick = if (isListening) onStopVoice else onStartVoice,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isListening) ErrorCoral else CobaltBlue
                    ),
                    modifier = Modifier.testTag("voice_trigger_button")
                ) {
                    Text(if (isListening) "Stop" else "Speak")
                }
            }
            if (recognizedText.isNotBlank()) {
                Text(
                    text = "${strings.recognizedSpeechLabel}: \"$recognizedText\"",
                    style = MaterialTheme.typography.labelLarge,
                    color = CyanGlow
                )
            }
            if (!voiceError.isNullOrBlank()) {
                Text(
                    text = voiceError,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrorCoral
                )
            }
        }
    }
}

@Composable
fun PairingCodeDialog(
    targetName: String,
    onSubmitCode: (String) -> Unit,
    onCancel: () -> Unit
) {
    val strings = LocalAppStrings.current
    var code by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = {
            Text(text = "${strings.pairingCodeTitle} • $targetName")
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = strings.pairingCodeSubtitle,
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = code,
                    onValueChange = { if (it.length <= 8) code = it.uppercase() },
                    label = { Text(strings.pairingCodeHint) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pairing_code_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmitCode(code) },
                enabled = code.trim().length >= 4,
                modifier = Modifier.testTag("pairing_code_submit")
            ) {
                Text(strings.verifyPair)
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun ManualIpDialog(
    onConnect: (String, Int) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var ip by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("6466") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.manualIpEntry) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = ip,
                    onValueChange = { ip = it },
                    label = { Text(strings.ipAddressHint) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manual_ip_input")
                )
                OutlinedTextField(
                    value = port,
                    onValueChange = { port = it.filter { ch -> ch.isDigit() } },
                    label = { Text(strings.portHint) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = port.toIntOrNull() ?: 6466
                    onConnect(ip.trim(), p)
                },
                enabled = ip.trim().isNotEmpty(),
                modifier = Modifier.testTag("manual_ip_connect_btn")
            ) {
                Text(strings.connectViaIp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
fun HidProfileStatusCard(
    status: HidProfileStatus,
    canRegister: Boolean,
    onInitializeHid: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val protocolLabel = if (status.protocolMode == HidProtocolMode.BOOT_PROTOCOL) {
        strings.hidProtocolBoot
    } else {
        strings.hidProtocolReport
    }
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(
            1.dp,
            if (status.isAppRegistered) CyanGlow.copy(alpha = 0.55f) else SlateBorder
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("hid_profile_status_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.hidProfileStatusTitle,
                    style = MaterialTheme.typography.titleSmall,
                    color = CyanGlow
                )
                Text(
                    text = protocolLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HidProfileBadge(
                    icon = Icons.Filled.Keyboard,
                    label = strings.hidKeyboardProfileLabel,
                    active = status.keyboardProfileActive,
                    modifier = Modifier.weight(1f)
                )
                HidProfileBadge(
                    icon = Icons.Filled.Mouse,
                    label = strings.hidMouseProfileLabel,
                    active = status.mouseProfileActive,
                    modifier = Modifier.weight(1f)
                )
                HidProfileBadge(
                    icon = Icons.Filled.SettingsRemote,
                    label = strings.hidConsumerProfileLabel,
                    active = status.consumerProfileActive,
                    modifier = Modifier.weight(1f)
                )
            }
            if (!status.lastStatusDetail.isNullOrBlank()) {
                Text(
                    text = status.lastStatusDetail,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (canRegister &&
                !status.isAppRegistered &&
                status.availability != HidProfileAvailability.UNSUPPORTED_ANDROID_VERSION
            ) {
                Button(
                    onClick = onInitializeHid,
                    colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("register_hid_profile_btn")
                ) {
                    Text(strings.hidRegisterProfileBtn)
                }
            }
        }
    }
}

@Composable
private fun HidProfileBadge(
    icon: ImageVector,
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val accent = if (active) ConnectedGreen else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = accent.copy(alpha = if (active) 0.14f else 0.08f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accent,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = if (active) strings.hidProfileReady else strings.hidProfileStandby,
                style = MaterialTheme.typography.labelSmall,
                color = accent,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
