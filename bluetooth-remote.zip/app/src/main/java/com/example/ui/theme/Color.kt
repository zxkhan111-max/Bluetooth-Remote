package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Electric Cyan & Cobalt Blue Accents
val CyanGlow = Color(0xFF00E5FF)
val CyanSoft = Color(0xFF67EEFF)
val CobaltBlue = Color(0xFF2979FF)
val DeepBlue = Color(0xFF1445B8)
val ElectricIndigo = Color(0xFF3D5AFE)

// Dark 3D Obsidian & Graphite Surfaces
val ObsidianBg = Color(0xFF060B16)
val MidnightSurface = Color(0xFF0C1426)
val SlateCard = Color(0xFF131F38)
val SlateElevated = Color(0xFF1A2947)
val SlateBevelHighlight = Color(0xFF2A3E66)
val SlateBorder = Color(0xFF243554)

// Text Colors (Dark)
val TextPrimaryDark = Color(0xFFF1F5FB)
val TextSecondaryDark = Color(0xFF94A6C4)
val TextMutedDark = Color(0xFF627599)

// Semantic Status Colors
val ConnectedGreen = Color(0xFF10E096)
val ConnectingAmber = Color(0xFFFFB020)
val ErrorCoral = Color(0xFFFF5263)
val PowerCrimson = Color(0xFFE5394D)

// Light Theme Palette (Clean Tech Daylight)
val LightBg = Color(0xFFF3F6FC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFE8EEF8)
val LightElevated = Color(0xFFDCE5F4)
val LightBorder = Color(0xFFC5D2E8)
val TextPrimaryLight = Color(0xFF0D172A)
val TextSecondaryLight = Color(0xFF475569)
