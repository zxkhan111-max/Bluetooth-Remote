package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ScreenShare
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.BrightnessLow
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Screenshot
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.model.CastPlaybackState
import com.example.model.MirroringStatus
import com.example.model.RemoteCommand
import com.example.model.TvRecordingStatus
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.SlateBorder
import com.example.ui.viewmodel.RemoteUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaAndToolsScreen(
    state: RemoteUiState,
    onSelectMediaForCast: (Uri, Boolean) -> Unit,
    onRefreshCastDevices: () -> Unit,
    onSelectCastDevice: (String) -> Unit,
    onCastSelectedMedia: () -> Unit,
    onToggleCastPlayPause: () -> Unit,
    onSeekCast: (Long) -> Unit,
    onSetCastVolume: (Double) -> Unit,
    onStopCasting: () -> Unit,
    onRequestStartMirroring: () -> Unit,
    onStopMirroring: () -> Unit,
    onOpenSystemCastSettings: () -> Unit,
    onRequestTvRecording: (String, Int, String) -> Unit,
    onStopTvRecording: (String, Int, String) -> Unit,
    onSendCommand: (RemoteCommand) -> Unit,
    onTriggerTvScreenshot: () -> Unit,
    onSaveSnapshot: () -> Unit,
    onShareSnapshot: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var castVolume by remember { mutableFloatStateOf(0.5f) }
    var brightnessStepValue by remember { mutableFloatStateOf(50f) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let { onSelectMediaForCast(it, false) } }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let { onSelectMediaForCast(it, true) } }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SecondaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = CyanGlow
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text(strings.mediaCastTab) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text(strings.screenMirrorTab) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text(strings.tvRecordingTab) })
        }

        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    // Media Cast Center (Module 8)
                    item {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, SlateBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = state.connectedCastName ?: strings.castStatusIdle,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = if (state.connectedCastName != null) ConnectedGreen else CyanGlow
                                    )
                                    IconButton(onClick = onRefreshCastDevices) {
                                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh Cast", tint = CyanGlow)
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("cast_pick_photo_btn")
                                    ) {
                                        Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.pickPhotos)
                                    }
                                    Button(
                                        onClick = {
                                            videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("cast_pick_video_btn")
                                    ) {
                                        Icon(Icons.Filled.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.pickVideos)
                                    }
                                }
                            }
                        }
                    }

                    state.selectedCastMedia?.let { media ->
                        item {
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    if (!media.isVideo) {
                                        AsyncImage(
                                            model = Uri.parse(media.uriString),
                                            contentDescription = media.displayName,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(170.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                        )
                                    }
                                    Text(media.displayName, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = "${media.mimeType} • ${state.castPlaybackState.name}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyanGlow
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Button(
                                            onClick = onCastSelectedMedia,
                                            colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Filled.Cast, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(strings.castToDevice)
                                        }
                                        if (state.connectedCastName != null) {
                                            OutlinedButton(onClick = onStopCasting) {
                                                Text(strings.stopCasting, color = ErrorCoral)
                                            }
                                        }
                                    }
                                    if (media.isVideo && state.connectedCastName != null) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceEvenly
                                        ) {
                                            IconButton(onClick = { onSeekCast(-10_000L) }) {
                                                Icon(Icons.Filled.FastRewind, contentDescription = "-10s")
                                            }
                                            IconButton(onClick = onToggleCastPlayPause) {
                                                Icon(
                                                    if (state.castPlaybackState == CastPlaybackState.PLAYING) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                                    contentDescription = strings.playPause,
                                                    tint = CyanGlow
                                                )
                                            }
                                            IconButton(onClick = { onSeekCast(10_000L) }) {
                                                Icon(Icons.Filled.FastForward, contentDescription = "+10s")
                                            }
                                        }
                                    }
                                    if (state.connectedCastName != null) {
                                        Slider(
                                            value = castVolume,
                                            onValueChange = {
                                                castVolume = it
                                                onSetCastVolume(it.toDouble())
                                            },
                                            colors = SliderDefaults.colors(thumbColor = CyanGlow, activeTrackColor = CobaltBlue)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (!state.castError.isNullOrBlank()) {
                        item { CapabilityNoticeBanner(text = state.castError, isError = true) }
                    }

                    if (state.castDevices.isEmpty()) {
                        item { CapabilityNoticeBanner(text = strings.castNoteNoDevice, isError = false) }
                    } else {
                        items(state.castDevices, key = { it.id }) { dev ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, SlateBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(dev.name, style = MaterialTheme.typography.titleSmall)
                                        Text(dev.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Button(onClick = { onSelectCastDevice(dev.id) }) {
                                        Text("Select")
                                    }
                                }
                            }
                        }
                    }

                    // Brightness & Screenshot Card
                    item {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, SlateBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(strings.brightnessSectionTitle, style = MaterialTheme.typography.titleSmall, color = CyanGlow)
                                Text(
                                    text = strings.brightnessCapabilityNote,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { onSendCommand(RemoteCommand.BRIGHTNESS_DOWN) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Filled.BrightnessLow, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.brightnessDown)
                                    }
                                    OutlinedButton(
                                        onClick = { onSendCommand(RemoteCommand.BRIGHTNESS_UP) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Filled.BrightnessHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.brightnessUp)
                                    }
                                }
                                Slider(
                                    value = brightnessStepValue,
                                    onValueChange = { newVal ->
                                        val delta = newVal - brightnessStepValue
                                        brightnessStepValue = newVal
                                        if (delta > 6f) onSendCommand(RemoteCommand.BRIGHTNESS_UP)
                                        else if (delta < -6f) onSendCommand(RemoteCommand.BRIGHTNESS_DOWN)
                                    },
                                    valueRange = 0f..100f,
                                    colors = SliderDefaults.colors(thumbColor = CyanGlow, activeTrackColor = CobaltBlue)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(strings.screenshotSectionTitle, style = MaterialTheme.typography.titleSmall, color = CyanGlow)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(onClick = onTriggerTvScreenshot, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Filled.Screenshot, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(strings.triggerTvScreenshot, maxLines = 1)
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(onClick = onSaveSnapshot, modifier = Modifier.weight(1f)) {
                                        Text(strings.captureLocalSnapshot, maxLines = 1)
                                    }
                                    OutlinedButton(onClick = onShareSnapshot, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(strings.shareScreenshot, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Screen Mirroring (Module 9)
                    item {
                        CapabilityNoticeBanner(text = strings.mirroringExplanation, isError = false)
                    }
                    item {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(
                                1.dp,
                                if (state.mirroringStatus == MirroringStatus.ACTIVE_VIRTUAL_DISPLAY) ConnectedGreen else SlateBorder
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.ScreenShare, contentDescription = null, tint = CyanGlow)
                                    Text(
                                        text = "Status: ${state.mirroringStatus.name}",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                if (!state.mirrorInfo.isNullOrBlank()) {
                                    Text(
                                        text = state.mirrorInfo,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (state.mirroringStatus == MirroringStatus.ACTIVE_VIRTUAL_DISPLAY) {
                                    Button(
                                        onClick = onStopMirroring,
                                        colors = ButtonDefaults.buttonColors(containerColor = ErrorCoral),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("stop_mirroring_btn")
                                    ) {
                                        Text(strings.stopMirroring)
                                    }
                                } else {
                                    Button(
                                        onClick = onRequestStartMirroring,
                                        colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("start_mirroring_btn")
                                    ) {
                                        Text(strings.startMirroring)
                                    }
                                }
                                OutlinedButton(
                                    onClick = onOpenSystemCastSettings,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(strings.openSystemCastSettings)
                                }
                            }
                        }
                    }
                }

                else -> {
                    // TV Screen Recording (Module 10)
                    item {
                        CapabilityNoticeBanner(
                            text = strings.tvRecordingUnsupportedNote,
                            isError = state.tvRecordingStatus == TvRecordingStatus.UNSUPPORTED_NO_RECEIVER
                        )
                    }
                    item {
                        var recHost by remember(state.discoveredReceivers) {
                            mutableStateOf(state.discoveredReceivers.firstOrNull()?.host.orEmpty())
                        }
                        var recPort by remember(state.discoveredReceivers) {
                            mutableStateOf((state.discoveredReceivers.firstOrNull()?.port ?: 7373).toString())
                        }
                        var recPin by remember { mutableStateOf("") }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, SlateBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "Receiver Status: ${state.tvRecordingStatus.name}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyanGlow
                                )
                                if (state.tvRecordingStatus == TvRecordingStatus.RECORDING) {
                                    Text(
                                        text = "Recording Duration: ${state.tvRecordingSeconds}s",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = ErrorCoral
                                    )
                                }
                                if (!state.tvRecordingMessage.isNullOrBlank()) {
                                    Text(
                                        text = state.tvRecordingMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                OutlinedTextField(
                                    value = recHost,
                                    onValueChange = { recHost = it },
                                    label = { Text(strings.receiverIpHint) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = recPort,
                                        onValueChange = { recPort = it.filter { c -> c.isDigit() } },
                                        label = { Text("Port") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = recPin,
                                        onValueChange = { recPin = it },
                                        label = { Text(strings.receiverPinHint) },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (state.tvRecordingStatus == TvRecordingStatus.RECORDING) {
                                    Button(
                                        onClick = { onStopTvRecording(recHost, recPort.toIntOrNull() ?: 7373, recPin) },
                                        colors = ButtonDefaults.buttonColors(containerColor = ErrorCoral),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(strings.stopRecording)
                                    }
                                } else {
                                    Button(
                                        onClick = { onRequestTvRecording(recHost, recPort.toIntOrNull() ?: 7373, recPin) },
                                        colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Filled.FiberManualRecord, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.startRecording)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
