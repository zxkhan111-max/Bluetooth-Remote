package com.example.ui.screens

import android.bluetooth.BluetoothDevice
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.BluetoothHidSupportStatus
import com.example.model.ConnectionMode
import com.example.model.DeviceCompatibility
import com.example.ui.components.CapabilityNoticeBanner
import com.example.ui.components.HidProfileStatusCard
import com.example.ui.components.ManualIpDialog
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.ConnectingAmber
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.ErrorCoral
import com.example.ui.viewmodel.RemoteUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceDiscoveryScreen(
    state: RemoteUiState,
    onBack: () -> Unit,
    onSelectMode: (ConnectionMode) -> Unit,
    onRequestBluetoothPermissions: () -> Unit,
    onInitializeHidProfile: () -> Unit,
    onScanDevices: () -> Unit,
    onStopScanning: () -> Unit,
    onConnectBluetooth: (String) -> Unit,
    onConnectWifi: (String, Int, String) -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    var showManualIpDialog by remember { mutableStateOf(false) }

    if (showManualIpDialog) {
        ManualIpDialog(
            onConnect = { ip, port ->
                showManualIpDialog = false
                onConnectWifi(ip, port, ip)
            },
            onDismiss = { showManualIpDialog = false }
        )
    }

    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(strings.discoverDevicesTitle) },
            navigationIcon = {
                IconButton(onClick = onBack, modifier = Modifier.testTag("discovery_back_btn")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                }
            },
            actions = {
                val scanning = if (state.selectedMode == ConnectionMode.BLUETOOTH_HID) {
                    state.isBluetoothScanning
                } else {
                    state.isWifiScanning
                }
                if (scanning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = CyanGlow
                    )
                    IconButton(onClick = onStopScanning) {
                        Icon(Icons.Filled.Stop, contentDescription = strings.stop, tint = ErrorCoral)
                    }
                } else {
                    IconButton(onClick = onScanDevices, modifier = Modifier.testTag("discovery_scan_btn")) {
                        Icon(Icons.Filled.Refresh, contentDescription = strings.scanDevices, tint = CyanGlow)
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onSelectMode(ConnectionMode.BLUETOOTH_HID) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.selectedMode == ConnectionMode.BLUETOOTH_HID) CobaltBlue else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Bluetooth, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.modeBluetoothHid)
                    }
                    Button(
                        onClick = { onSelectMode(ConnectionMode.WIFI_ANDROID_TV) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.selectedMode == ConnectionMode.WIFI_ANDROID_TV) CobaltBlue else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Wifi, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.modeWifiTv)
                    }
                }
            }

            if (!state.activeErrorMessage.isNullOrBlank()) {
                item {
                    CapabilityNoticeBanner(
                        text = state.activeErrorMessage,
                        isError = true,
                        onDismiss = onDismissError
                    )
                }
            }

            if (state.selectedMode == ConnectionMode.BLUETOOTH_HID) {
                if (state.hidSupportStatus == BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION) {
                    item {
                        CapabilityNoticeBanner(
                            text = strings.errBtHidAndroid8,
                            isError = true
                        )
                    }
                }

                if (state.missingBluetoothPermissions.isNotEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(strings.permissionRationaleBt, style = MaterialTheme.typography.bodyMedium)
                                Button(
                                    onClick = onRequestBluetoothPermissions,
                                    modifier = Modifier.testTag("grant_bt_perms_btn")
                                ) {
                                    Text(strings.grantBluetoothPermissions)
                                }
                            }
                        }
                    }
                }

                item {
                    HidProfileStatusCard(
                        status = state.hidProfileStatus,
                        canRegister = state.missingBluetoothPermissions.isEmpty(),
                        onInitializeHid = onInitializeHidProfile
                    )
                }

                item {
                    Text(
                        text = strings.bluetoothPairedSection,
                        style = MaterialTheme.typography.titleSmall,
                        color = CyanGlow
                    )
                }

                if (state.bondedBluetoothDevices.isEmpty()) {
                    item {
                        Text(
                            text = strings.noSavedDevicesHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(state.bondedBluetoothDevices, key = { "b_${it.address}" }) { dev ->
                        BluetoothDeviceRow(
                            name = dev.name,
                            address = dev.address,
                            isBonded = dev.bondState == BluetoothDevice.BOND_BONDED,
                            isLikelyTv = dev.isLikelyTvOrMedia,
                            onAction = { onConnectBluetooth(dev.address) }
                        )
                    }
                }

                item {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = strings.bluetoothNearbySection,
                        style = MaterialTheme.typography.titleSmall,
                        color = CyanGlow
                    )
                }

                items(state.discoveredBluetoothDevices, key = { "d_${it.address}" }) { dev ->
                    BluetoothDeviceRow(
                        name = dev.name,
                        address = dev.address,
                        isBonded = dev.bondState == BluetoothDevice.BOND_BONDED,
                        isLikelyTv = dev.isLikelyTvOrMedia,
                        onAction = { onConnectBluetooth(dev.address) }
                    )
                }
            } else {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.wifiDiscoveredSection,
                            style = MaterialTheme.typography.titleSmall,
                            color = CyanGlow
                        )
                        OutlinedButton(
                            onClick = { showManualIpDialog = true },
                            modifier = Modifier.testTag("open_manual_ip_btn")
                        ) {
                            Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.manualIpEntry)
                        }
                    }
                }

                if (state.discoveredWifiDevices.isEmpty()) {
                    item {
                        CapabilityNoticeBanner(
                            text = if (state.isWifiScanning) strings.statusScanning else strings.pairingInstructionsWifi,
                            isError = false
                        )
                    }
                } else {
                    items(state.discoveredWifiDevices, key = { it.id }) { tv ->
                        val (badgeText, badgeColor) = when (tv.compatibility) {
                            DeviceCompatibility.COMPATIBLE,
                            DeviceCompatibility.PAIRING_NEEDED -> strings.compatibleBadge to ConnectedGreen
                            DeviceCompatibility.LIMITED_COMPATIBILITY -> strings.limitedBadge to ConnectingAmber
                            DeviceCompatibility.INCOMPATIBLE -> strings.incompatibleBadge to ErrorCoral
                        }
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = tv.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${tv.host}:${tv.port} • ${tv.serviceType}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = badgeText,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = badgeColor
                                    )
                                }
                                Button(
                                    onClick = { onConnectWifi(tv.host, tv.port, tv.name) },
                                    enabled = tv.compatibility != DeviceCompatibility.INCOMPATIBLE,
                                    colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue)
                                ) {
                                    Text(strings.connectButton)
                                }
                            }
                        }
                    }
                }
            }

            // Pairing Instructions Card
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = strings.pairingInstructionsTitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = CyanGlow
                        )
                        Text(
                            text = if (state.selectedMode == ConnectionMode.BLUETOOTH_HID) {
                                strings.pairingInstructionsBt
                            } else {
                                strings.pairingInstructionsWifi
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BluetoothDeviceRow(
    name: String,
    address: String,
    isBonded: Boolean,
    isLikelyTv: Boolean,
    onAction: () -> Unit
) {
    val strings = LocalAppStrings.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "$address • ${if (isBonded) strings.pairedBadge else if (isLikelyTv) "TV / Media" else "Bluetooth"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isBonded) ConnectedGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue)
            ) {
                Text(if (isBonded) strings.connectButton else strings.pairButton)
            }
        }
    }
}
