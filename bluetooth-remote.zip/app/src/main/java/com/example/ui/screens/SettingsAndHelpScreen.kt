package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.BatterySaverSettings
import com.example.model.ConnectionMode
import com.example.model.ConnectionTimeoutOption
import com.example.model.RemoteButtonSize
import com.example.model.RemoteCommand
import com.example.model.SensorSamplingTier
import com.example.model.TvDeviceIcon
import com.example.model.TvProfile
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.SlateBorder
import com.example.ui.viewmodel.RemoteUiState

@Composable
fun SettingsAndHelpScreen(
    state: RemoteUiState,
    onSetDarkTheme: (Boolean) -> Unit,
    onSetLanguage: (AppLanguage) -> Unit,
    onSetHaptic: (Boolean) -> Unit,
    onSetSound: (Boolean) -> Unit,
    onSetAutoReconnect: (Boolean) -> Unit,
    onUpdateBatterySaver: (BatterySaverSettings) -> Unit,
    onReconnectProfile: (TvProfile) -> Unit,
    onUpdateProfile: (TvProfile) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onSelectLayout: (String) -> Unit,
    onCreateLayout: (String) -> Unit,
    onAddCustomButton: (String, RemoteCommand, String, RemoteButtonSize) -> Unit,
    onRemoveCustomButton: (String) -> Unit,
    onRenameCustomButton: (String, String) -> Unit,
    onCycleCustomButtonSize: (String) -> Unit,
    onMoveCustomButton: (String, Int) -> Unit,
    onRestoreDefaultLayout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val prefs = state.preferences
    var showAddButtonDialog by remember { mutableStateOf(false) }
    var editingProfile by remember { mutableStateOf<TvProfile?>(null) }

    if (showAddButtonDialog) {
        var btnLabel by remember { mutableStateOf("") }
        var chosenCmd by remember { mutableStateOf(RemoteCommand.HOME) }
        var chosenSize by remember { mutableStateOf(RemoteButtonSize.MEDIUM) }
        AlertDialog(
            onDismissRequest = { showAddButtonDialog = false },
            title = { Text("Add Custom Button") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = btnLabel,
                        onValueChange = { btnLabel = it },
                        label = { Text("Button Label") }
                    )
                    Text("Action:", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(RemoteCommand.POWER, RemoteCommand.HOME, RemoteCommand.BACK, RemoteCommand.MUTE).forEach { cmd ->
                            FilterChip(
                                selected = chosenCmd == cmd,
                                onClick = { chosenCmd = cmd },
                                label = { Text(cmd.name.take(5)) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(RemoteCommand.VOLUME_UP, RemoteCommand.VOLUME_DOWN, RemoteCommand.PLAY_PAUSE, RemoteCommand.SETTINGS).forEach { cmd ->
                            FilterChip(
                                selected = chosenCmd == cmd,
                                onClick = { chosenCmd = cmd },
                                label = { Text(cmd.name.take(5)) }
                            )
                        }
                    }
                    Text("Size:", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        RemoteButtonSize.entries.forEach { sz ->
                            FilterChip(
                                selected = chosenSize == sz,
                                onClick = { chosenSize = sz },
                                label = { Text(sz.name) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onAddCustomButton(btnLabel, chosenCmd, "power", chosenSize)
                    showAddButtonDialog = false
                }) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showAddButtonDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    editingProfile?.let { prof ->
        var newName by remember { mutableStateOf(prof.name) }
        var newIcon by remember { mutableStateOf(prof.icon) }
        AlertDialog(
            onDismissRequest = { editingProfile = null },
            title = { Text("Edit TV Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("TV Name") })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TvDeviceIcon.entries.forEach { ic ->
                            FilterChip(
                                selected = newIcon == ic,
                                onClick = { newIcon = ic },
                                label = { Text(ic.key) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateProfile(prof.copy(name = newName.trim().ifEmpty { prof.name }, icon = newIcon))
                    editingProfile = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { editingProfile = null }) { Text(strings.cancel) }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .widthIn(max = 620.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Preferences & Bilingual Language Switch
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(strings.navSettings, style = MaterialTheme.typography.titleMedium, color = CyanGlow)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.languageLabel, style = MaterialTheme.typography.bodyLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = prefs.language == AppLanguage.ENGLISH,
                                onClick = { onSetLanguage(AppLanguage.ENGLISH) },
                                label = { Text("English") },
                                modifier = Modifier.testTag("lang_en_chip")
                            )
                            FilterChip(
                                selected = prefs.language == AppLanguage.BENGALI,
                                onClick = { onSetLanguage(AppLanguage.BENGALI) },
                                label = { Text("বাংলা") },
                                modifier = Modifier.testTag("lang_bn_chip")
                            )
                        }
                    }
                    SettingSwitchRow(strings.darkThemeLabel, prefs.darkTheme, onSetDarkTheme, "theme_switch")
                    SettingSwitchRow(strings.hapticFeedback, prefs.hapticEnabled, onSetHaptic, "haptic_switch")
                    SettingSwitchRow(strings.soundFeedback, prefs.soundEnabled, onSetSound, "sound_switch")
                    SettingSwitchRow(strings.autoReconnectLabel, prefs.autoReconnect, onSetAutoReconnect, "reconnect_switch")
                }
            }
        }

        // Module 13: Battery Saver
        item {
            val bs = prefs.batterySaver
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.batterySaverTitle, style = MaterialTheme.typography.titleMedium, color = CyanGlow)
                        if (state.batteryStatus.percentage >= 0) {
                            Text(
                                text = "${strings.phoneBattery}: ${state.batteryStatus.percentage}%",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                    SettingSwitchRow(
                        label = strings.lowPowerMode,
                        checked = bs.lowPowerMode,
                        onCheckedChange = { onUpdateBatterySaver(bs.copy(lowPowerMode = it)) },
                        tag = "battery_low_power_switch"
                    )
                    SettingSwitchRow(
                        label = strings.reduceScanning,
                        checked = bs.reduceScanning,
                        onCheckedChange = { onUpdateBatterySaver(bs.copy(reduceScanning = it)) },
                        tag = "battery_scan_switch"
                    )
                    SettingSwitchRow(
                        label = strings.disableAnimations,
                        checked = bs.disableAnimations,
                        onCheckedChange = { onUpdateBatterySaver(bs.copy(disableAnimations = it)) },
                        tag = "battery_anim_switch"
                    )
                    Text(strings.sensorSamplingRate, style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SensorSamplingTier.entries.forEach { tier ->
                            FilterChip(
                                selected = bs.sensorSamplingTier == tier,
                                onClick = { onUpdateBatterySaver(bs.copy(sensorSamplingTier = tier)) },
                                label = { Text(tier.delayUsLabelKey) }
                            )
                        }
                    }
                    Text(strings.connectionTimeout, style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ConnectionTimeoutOption.entries.forEach { opt ->
                            FilterChip(
                                selected = bs.connectionTimeout == opt,
                                onClick = { onUpdateBatterySaver(bs.copy(connectionTimeout = opt)) },
                                label = { Text(if (opt.minutes == 0) "Never" else "${opt.minutes}m") }
                            )
                        }
                    }
                }
            }
        }

        // Module 11: Custom Remote Builder
        item {
            val activeLayout = prefs.customLayouts.firstOrNull { it.id == prefs.activeLayoutId }
                ?: prefs.customLayouts.firstOrNull()
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.customRemoteBuilderTitle, style = MaterialTheme.typography.titleMedium, color = CyanGlow)
                        Row {
                            IconButton(onClick = { showAddButtonDialog = true }, modifier = Modifier.testTag("custom_add_btn")) {
                                Icon(Icons.Filled.Add, contentDescription = "Add Button", tint = CyanGlow)
                            }
                            IconButton(onClick = onRestoreDefaultLayout) {
                                Icon(Icons.Filled.Restore, contentDescription = strings.restoreDefaultLayout, tint = CyanGlow)
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        prefs.customLayouts.forEach { layout ->
                            FilterChip(
                                selected = layout.id == prefs.activeLayoutId,
                                onClick = { onSelectLayout(layout.id) },
                                label = { Text(layout.name) }
                            )
                        }
                        OutlinedButton(onClick = { onCreateLayout("Layout ${prefs.customLayouts.size + 1}") }) {
                            Text("+ New")
                        }
                    }
                    activeLayout?.buttons?.sortedBy { it.orderIndex }?.forEach { btn ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(btn.label, style = MaterialTheme.typography.titleSmall)
                                Text("${btn.command.name} • ${btn.size.name}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Row {
                                IconButton(onClick = { onMoveCustomButton(btn.id, -1) }) {
                                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onMoveCustomButton(btn.id, 1) }) {
                                    Icon(Icons.Filled.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(18.dp))
                                }
                                TextButton(onClick = { onCycleCustomButtonSize(btn.id) }) {
                                    Text(btn.size.name.take(1))
                                }
                                IconButton(onClick = { onRemoveCustomButton(btn.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = ErrorCoral, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Module 12: Multiple TV Profiles
        item {
            Text(strings.tvProfilesTitle, style = MaterialTheme.typography.titleMedium, color = CyanGlow)
        }
        items(prefs.profiles, key = { "prof_${it.id}" }) { prof ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(prof.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "${if (prof.mode == ConnectionMode.BLUETOOTH_HID) "Bluetooth" else "Wi-Fi"} • ${prof.addressOrHost}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row {
                        IconButton(onClick = { editingProfile = prof }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit")
                        }
                        IconButton(onClick = { onDeleteProfile(prof.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = ErrorCoral)
                        }
                        Button(
                            onClick = { onReconnectProfile(prof) },
                            colors = ButtonDefaults.buttonColors(containerColor = CobaltBlue)
                        ) {
                            Text(strings.reconnect)
                        }
                    }
                }
            }
        }

        // Connection Help & Capability Transparency Report
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.AutoMirrored.Filled.HelpOutline, contentDescription = null, tint = CyanGlow)
                        Text(strings.connectionHelpTitle, style = MaterialTheme.typography.titleMedium, color = CyanGlow)
                    }
                    Text(
                        text = "• Fully Implemented: Bluetooth HID Keyboard/Mouse/Consumer (Android 9+), Wi-Fi Android TV Remote v2 TLS Pairing & Key/IME/Deep-Link, NSD Discovery, Gyro Air Mouse, Touchpad Gestures, SpeechRecognizer Voice (EN/BN), Custom Remote Builder, TV Profiles, Battery Saver, Local Snapshot Share.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ConnectedGreen
                    )
                    Text(
                        text = "• Requires Companion TV Receiver App: Full installed TV app list enumeration, LAN File Transfer with ACK verification, and Receiver-side TV Screen Recording.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "• Requires Special TV Compatibility: Google Cast SDK receiver for Media Cast, Miracast/Cast wireless display for MediaProjection Screen Mirroring, TV OS support for discrete Brightness & Screenshot keys.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "• Protocol Limitations: Bluetooth HID is unavailable on Android 8.0/8.1 (API < 28); Wi-Fi Android TV Remote v2 does not support free-floating mouse cursors or pulling TV pixels back to the phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag)
        )
    }
}
