package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.connectivity.AirMouseSensorController
import com.example.connectivity.AndroidTvRemoteClient
import com.example.connectivity.BluetoothHidService
import com.example.connectivity.BluetoothRemoteManager
import com.example.connectivity.FeedbackManager
import com.example.connectivity.HidReportDescriptor
import com.example.connectivity.LocalFileTransferClient
import com.example.connectivity.MediaCastManager
import com.example.connectivity.NsdTvDiscoveryManager
import com.example.connectivity.ParsedVoiceIntent
import com.example.connectivity.ScreenMirrorController
import com.example.connectivity.ScreenshotHelper
import com.example.connectivity.VoiceCommandController
import com.example.data.DeviceStatusMonitor
import com.example.data.PreferencesRepository
import com.example.model.AppLanguage
import com.example.model.AppPreferences
import com.example.model.BatterySaverSettings
import com.example.model.BatteryStatus
import com.example.model.BluetoothHidSupportStatus
import com.example.model.CastDeviceSummary
import com.example.model.CastMediaSelection
import com.example.model.CastPlaybackState
import com.example.model.ConnectedDeviceInfo
import com.example.model.ConnectionHistoryEntry
import com.example.model.ConnectionMode
import com.example.model.ConnectionState
import com.example.model.CustomRemoteButton
import com.example.model.CustomRemoteLayout
import com.example.model.DiscoveredBluetoothDevice
import com.example.model.DiscoveredWifiDevice
import com.example.model.HidProfileStatus
import com.example.model.MirroringStatus
import com.example.model.ReceiverEndpoint
import com.example.model.RemoteButtonSize
import com.example.model.RemoteCommand
import com.example.model.RemoteError
import com.example.model.TransferHistoryRecord
import com.example.model.TransferItem
import com.example.model.TransferStatus
import com.example.model.TvAppShortcut
import com.example.model.TvDeviceIcon
import com.example.model.TvProfile
import com.example.model.TvRecordingStatus
import com.example.ui.i18n.stringsFor
import com.example.ui.i18n.toLocalizedMessage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class RemoteUiState(
    val preferences: AppPreferences = AppPreferences(),
    val selectedMode: ConnectionMode = ConnectionMode.BLUETOOTH_HID,
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val connectedDevice: ConnectedDeviceInfo? = null,
    val batteryStatus: BatteryStatus = BatteryStatus(),
    val hidSupportStatus: BluetoothHidSupportStatus = BluetoothHidSupportStatus.SUPPORTED,
    val hidProfileStatus: HidProfileStatus = HidProfileStatus(),
    val missingBluetoothPermissions: List<String> = emptyList(),
    val bondedBluetoothDevices: List<DiscoveredBluetoothDevice> = emptyList(),
    val discoveredBluetoothDevices: List<DiscoveredBluetoothDevice> = emptyList(),
    val isBluetoothScanning: Boolean = false,
    val discoveredWifiDevices: List<DiscoveredWifiDevice> = emptyList(),
    val discoveredReceivers: List<ReceiverEndpoint> = emptyList(),
    val isWifiScanning: Boolean = false,
    val pairingTargetName: String? = null,
    val activeErrorMessage: String? = null,
    val statusNoticeMessage: String? = null,
    val isMousePointerMode: Boolean = true,
    val isDragLocked: Boolean = false,
    val isAirMouseActive: Boolean = false,
    val hasGyroscope: Boolean = false,
    val hasAirMouseSensor: Boolean = false,
    val isVoiceListening: Boolean = false,
    val voiceRecognizedText: String = "",
    val voiceErrorMessage: String? = null,
    val lastSnapshotUri: Uri? = null,
    val transferQueue: List<TransferItem> = emptyList(),
    val isTransferring: Boolean = false,
    val castDevices: List<CastDeviceSummary> = emptyList(),
    val connectedCastName: String? = null,
    val castPlaybackState: CastPlaybackState = CastPlaybackState.IDLE,
    val castError: String? = null,
    val selectedCastMedia: CastMediaSelection? = null,
    val mirroringStatus: MirroringStatus = MirroringStatus.IDLE,
    val mirrorInfo: String? = null,
    val tvRecordingStatus: TvRecordingStatus = TvRecordingStatus.UNSUPPORTED_NO_RECEIVER,
    val tvRecordingSeconds: Long = 0L,
    val tvRecordingMessage: String? = null
)

class RemoteViewModel(
    application: Application,
    private val bluetoothService: BluetoothHidService
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application,
        BluetoothRemoteManager(application)
    )

    private val prefsRepo = PreferencesRepository(application)
    private val statusMonitor = DeviceStatusMonitor(application)
    private val feedbackManager = FeedbackManager(application)
    private val nsdManager = NsdTvDiscoveryManager(application)
    private val wifiClient = AndroidTvRemoteClient(application)
    private val airMouseController = AirMouseSensorController(application)
    private val voiceController = VoiceCommandController(application)
    private val fileTransferClient = LocalFileTransferClient(application)
    private val mediaCastManager = MediaCastManager(application)
    private val screenMirrorController = ScreenMirrorController(application)
    private val screenshotHelper = ScreenshotHelper(application)

    private val _selectedMode = MutableStateFlow(ConnectionMode.BLUETOOTH_HID)
    private val _statusNotice = MutableStateFlow<String?>(null)
    private val _explicitError = MutableStateFlow<RemoteError?>(null)
    private val _isMousePointerMode = MutableStateFlow(true)
    private val _isDragLocked = MutableStateFlow(false)
    private val _lastSnapshotUri = MutableStateFlow<Uri?>(null)
    private val _selectedCastMedia = MutableStateFlow<CastMediaSelection?>(null)
    private val _missingPerms = MutableStateFlow(bluetoothService.missingPermissions())

    private var idleTimeoutJob: Job? = null
    private var lastActivityMs: Long = System.currentTimeMillis()
    private var lastSavedConnectionId: String? = null

    val uiState: StateFlow<RemoteUiState> = combine(
        prefsRepo.preferencesFlow,
        _selectedMode,
        bluetoothService.connectionState,
        wifiClient.connectionState,
        bluetoothService.connectedDevice,
        wifiClient.connectedDevice,
        statusMonitor.observeBatteryStatus(),
        bluetoothService.hidSupportStatus,
        _missingPerms,
        bluetoothService.bondedDevices,
        bluetoothService.discoveredDevices,
        bluetoothService.isScanning,
        nsdManager.discoveredTvs,
        nsdManager.discoveredReceivers,
        nsdManager.isScanning,
        wifiClient.pairingTargetName,
        bluetoothService.lastError,
        wifiClient.lastError,
        _explicitError,
        _statusNotice,
        _isMousePointerMode,
        _isDragLocked,
        airMouseController.isEnabled,
        voiceController.isListening,
        voiceController.recognizedText,
        voiceController.errorMessage,
        _lastSnapshotUri,
        fileTransferClient.queue,
        fileTransferClient.isTransferring,
        mediaCastManager.castDevices,
        mediaCastManager.connectedCastName,
        mediaCastManager.playbackState,
        mediaCastManager.castError,
        _selectedCastMedia,
        screenMirrorController.mirrorStatus,
        screenMirrorController.mirrorInfo,
        screenMirrorController.recordingStatus,
        screenMirrorController.recordingSeconds,
        screenMirrorController.recordingMessage,
        bluetoothService.hidProfileStatus
    ) { arr ->
        val prefs = arr[0] as AppPreferences
        val mode = arr[1] as ConnectionMode
        val btState = arr[2] as ConnectionState
        val wifiState = arr[3] as ConnectionState
        val btDev = arr[4] as ConnectedDeviceInfo?
        val wifiDev = arr[5] as ConnectedDeviceInfo?
        val battery = arr[6] as BatteryStatus
        val hidSupport = arr[7] as BluetoothHidSupportStatus
        @Suppress("UNCHECKED_CAST")
        val missingPerms = arr[8] as List<String>
        @Suppress("UNCHECKED_CAST")
        val bondedBt = arr[9] as List<DiscoveredBluetoothDevice>
        @Suppress("UNCHECKED_CAST")
        val discoveredBt = arr[10] as List<DiscoveredBluetoothDevice>
        val btScanning = arr[11] as Boolean
        @Suppress("UNCHECKED_CAST")
        val wifiTvs = arr[12] as List<DiscoveredWifiDevice>
        @Suppress("UNCHECKED_CAST")
        val receivers = arr[13] as List<ReceiverEndpoint>
        val wifiScanning = arr[14] as Boolean
        val pairingTarget = arr[15] as String?
        val btErr = arr[16] as RemoteError?
        val wifiErr = arr[17] as RemoteError?
        val explicitErr = arr[18] as RemoteError?
        val notice = arr[19] as String?
        val mousePointer = arr[20] as Boolean
        val dragLock = arr[21] as Boolean
        val airMouseOn = arr[22] as Boolean
        val voiceListening = arr[23] as Boolean
        val voiceText = arr[24] as String
        val voiceErr = arr[25] as String?
        val snapshotUri = arr[26] as Uri?
        @Suppress("UNCHECKED_CAST")
        val queue = arr[27] as List<TransferItem>
        val transferring = arr[28] as Boolean
        @Suppress("UNCHECKED_CAST")
        val castDevices = arr[29] as List<CastDeviceSummary>
        val castName = arr[30] as String?
        val castPlayback = arr[31] as CastPlaybackState
        val castErr = arr[32] as String?
        val castMedia = arr[33] as CastMediaSelection?
        val mirrorStatus = arr[34] as MirroringStatus
        val mirrorInfo = arr[35] as String?
        val recStatus = arr[36] as TvRecordingStatus
        val recSecs = arr[37] as Long
        val recMsg = arr[38] as String?
        val hidProfile = arr[39] as HidProfileStatus

        val strings = stringsFor(prefs.language)
        val activeDevice = when {
            mode == ConnectionMode.BLUETOOTH_HID && btDev != null -> btDev
            mode == ConnectionMode.WIFI_ANDROID_TV && wifiDev != null -> wifiDev
            btDev != null -> btDev
            wifiDev != null -> wifiDev
            else -> null
        }

        val activeState = when {
            activeDevice != null -> ConnectionState.CONNECTED
            mode == ConnectionMode.BLUETOOTH_HID -> if (btScanning && btState == ConnectionState.DISCONNECTED) ConnectionState.SCANNING else btState
            else -> if (wifiScanning && wifiState == ConnectionState.DISCONNECTED) ConnectionState.SCANNING else wifiState
        }

        val relevantError = explicitErr ?: if (mode == ConnectionMode.BLUETOOTH_HID) btErr else wifiErr

        RemoteUiState(
            preferences = prefs,
            selectedMode = mode,
            connectionState = activeState,
            connectedDevice = activeDevice,
            batteryStatus = battery,
            hidSupportStatus = hidSupport,
            hidProfileStatus = hidProfile,
            missingBluetoothPermissions = missingPerms,
            bondedBluetoothDevices = bondedBt,
            discoveredBluetoothDevices = discoveredBt,
            isBluetoothScanning = btScanning,
            discoveredWifiDevices = wifiTvs,
            discoveredReceivers = receivers,
            isWifiScanning = wifiScanning,
            pairingTargetName = pairingTarget,
            activeErrorMessage = relevantError?.toLocalizedMessage(strings),
            statusNoticeMessage = notice,
            isMousePointerMode = mousePointer,
            isDragLocked = dragLock,
            isAirMouseActive = airMouseOn,
            hasGyroscope = airMouseController.hasGyroscope,
            hasAirMouseSensor = airMouseController.hasHardwareSensor,
            isVoiceListening = voiceListening,
            voiceRecognizedText = voiceText,
            voiceErrorMessage = voiceErr,
            lastSnapshotUri = snapshotUri,
            transferQueue = queue,
            isTransferring = transferring,
            castDevices = castDevices,
            connectedCastName = castName,
            castPlaybackState = castPlayback,
            castError = castErr,
            selectedCastMedia = castMedia,
            mirroringStatus = mirrorStatus,
            mirrorInfo = mirrorInfo,
            tvRecordingStatus = recStatus,
            tvRecordingSeconds = recSecs,
            tvRecordingMessage = recMsg
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), RemoteUiState())

    init {
        mediaCastManager.initialize()
        viewModelScope.launch {
            val prefs = prefsRepo.preferencesFlow.first()
            _selectedMode.value = prefs.preferredMode
            if (bluetoothService.missingPermissions().isEmpty()) {
                bluetoothService.refreshBondedDevices()
                bluetoothService.initializeHidProfile()
            }
            if (prefs.autoReconnect && !prefs.batterySaver.lowPowerMode) {
                val favoriteOrRecent = prefs.profiles.firstOrNull { it.isFavorite }
                    ?: prefs.profiles.maxByOrNull { it.lastConnectedEpochMs }
                if (favoriteOrRecent != null) {
                    reconnectProfile(favoriteOrRecent)
                }
            }
        }

        // Persist successful connections as TV profiles & history (never before actual ConnectionState.CONNECTED)
        viewModelScope.launch {
            uiState.collect { state ->
                val connected = state.connectedDevice
                if (connected != null && lastSavedConnectionId != connected.id) {
                    lastSavedConnectionId = connected.id
                    recordSuccessfulConnection(connected)
                } else if (connected == null && lastSavedConnectionId != null) {
                    lastSavedConnectionId = null
                    _isDragLocked.value = false
                    airMouseController.stop()
                }
                screenMirrorController.updateReceiverAvailability(state.discoveredReceivers.isNotEmpty())
            }
        }

        startIdleTimeoutMonitor()
    }

    private fun startIdleTimeoutMonitor() {
        idleTimeoutJob?.cancel()
        idleTimeoutJob = viewModelScope.launch {
            while (true) {
                delay(30_000L)
                val state = uiState.value
                val timeoutMinutes = state.preferences.batterySaver.connectionTimeout.minutes
                if (timeoutMinutes > 0 && state.connectedDevice != null) {
                    val elapsedMs = System.currentTimeMillis() - lastActivityMs
                    if (elapsedMs >= timeoutMinutes * 60_000L) {
                        disconnectActiveDevice()
                        showNotice("Disconnected after ${timeoutMinutes}m idle (Battery Saver timeout).")
                    }
                }
            }
        }
    }

    private fun markActivity() {
        lastActivityMs = System.currentTimeMillis()
    }

    private fun triggerHapticAndSound(strong: Boolean = false) {
        val prefs = uiState.value.preferences
        val haptic = prefs.hapticEnabled && !prefs.batterySaver.lowPowerMode
        val sound = prefs.soundEnabled && !prefs.batterySaver.lowPowerMode
        feedbackManager.triggerClickFeedback(haptic, sound, strong)
    }

    fun selectConnectionMode(mode: ConnectionMode) {
        _selectedMode.value = mode
        _explicitError.value = null
        viewModelScope.launch { prefsRepo.setPreferredMode(mode) }
    }

    fun missingBluetoothPermissions(): List<String> = bluetoothService.missingPermissions()

    fun initializeBluetoothHidProfile(userInitiated: Boolean = true) {
        markActivity()
        if (userInitiated) _explicitError.value = null
        val err = bluetoothService.initializeHidProfile()
        if (err != null && userInitiated) {
            _explicitError.value = err
        }
    }

    fun unregisterBluetoothHidProfile() {
        airMouseController.stop()
        _isDragLocked.value = false
        bluetoothService.unregisterHidProfile()
    }

    fun onPermissionsResult() {
        _missingPerms.value = bluetoothService.missingPermissions()
        if (_missingPerms.value.isEmpty()) {
            bluetoothService.refreshBondedDevices()
            bluetoothService.initializeHidProfile()
        }
    }

    fun scanDevices() {
        markActivity()
        _explicitError.value = null
        if (_selectedMode.value == ConnectionMode.BLUETOOTH_HID) {
            bluetoothService.initializeHidProfile()
            val err = bluetoothService.startDiscovery()
            if (err != null) _explicitError.value = err
        } else {
            if (!statusMonitor.isWifiConnected()) {
                _explicitError.value = RemoteError.WifiUnavailable
                return
            }
            nsdManager.startDiscovery()
        }
    }

    fun stopScanning() {
        bluetoothService.stopDiscovery()
        nsdManager.stopDiscovery()
    }

    fun connectBluetoothDevice(address: String) {
        markActivity()
        _explicitError.value = null
        _selectedMode.value = ConnectionMode.BLUETOOTH_HID
        bluetoothService.connectOrPair(address)
    }

    fun connectWifiDevice(host: String, port: Int = 6466, name: String = host) {
        markActivity()
        _explicitError.value = null
        if (!statusMonitor.isWifiConnected()) {
            _explicitError.value = RemoteError.WifiUnavailable
            return
        }
        _selectedMode.value = ConnectionMode.WIFI_ANDROID_TV
        wifiClient.connectOrPair(host.trim(), port, name.ifBlank { host.trim() })
    }

    fun submitWifiPairingCode(code: String) {
        markActivity()
        wifiClient.submitPairingCode(code)
    }

    fun cancelWifiPairing() {
        wifiClient.cancelPairing()
    }

    fun disconnectActiveDevice() {
        airMouseController.stop()
        bluetoothService.disconnect()
        wifiClient.disconnect()
        _isDragLocked.value = false
    }

    fun reconnectProfile(profile: TvProfile) {
        markActivity()
        selectConnectionMode(profile.mode)
        when (profile.mode) {
            ConnectionMode.BLUETOOTH_HID -> {
                if (bluetoothService.missingPermissions().isEmpty()) {
                    bluetoothService.connectOrPair(profile.addressOrHost)
                }
            }
            ConnectionMode.WIFI_ANDROID_TV -> {
                if (statusMonitor.isWifiConnected()) {
                    wifiClient.connectOrPair(profile.addressOrHost, profile.port, profile.name)
                } else {
                    _explicitError.value = RemoteError.WifiUnavailable
                }
            }
        }
    }

    fun sendRemoteCommand(command: RemoteCommand, strongFeedback: Boolean = false) {
        markActivity()
        triggerHapticAndSound(strongFeedback)
        val connected = uiState.value.connectedDevice
        if (connected == null) {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        when (connected.mode) {
            ConnectionMode.BLUETOOTH_HID -> {
                val err = bluetoothService.sendCommand(command)
                if (err != null) _explicitError.value = err
            }
            ConnectionMode.WIFI_ANDROID_TV -> {
                wifiClient.sendCommand(command) { err ->
                    if (err != null) _explicitError.value = err
                }
            }
        }
    }

    // --- Touchpad & Mouse (Modules 5 & 6) ---

    fun setMousePointerMode(enabled: Boolean) {
        val connected = uiState.value.connectedDevice
        if (enabled && connected?.mode == ConnectionMode.WIFI_ANDROID_TV) {
            _explicitError.value = RemoteError.UnsupportedFeature(
                "HID Mouse Pointer",
                "wifi_no_cursor"
            )
            _isMousePointerMode.value = false
            return
        }
        _isMousePointerMode.value = enabled
    }

    fun onTouchpadMove(dx: Float, dy: Float) {
        markActivity()
        val connected = uiState.value.connectedDevice ?: return
        val sens = uiState.value.preferences.touchpadSensitivity
        if (connected.mode == ConnectionMode.BLUETOOTH_HID && _isMousePointerMode.value) {
            val mask = if (_isDragLocked.value) 0x01 else 0x00
            val err = bluetoothService.sendMouseMove(
                deltaX = (dx * sens).toInt().coerceIn(-127, 127),
                deltaY = (dy * sens).toInt().coerceIn(-127, 127),
                buttonsBitmask = mask
            )
            if (err != null) _explicitError.value = err
        }
    }

    fun onTouchpadSwipeDirection(command: RemoteCommand) {
        sendRemoteCommand(command)
    }

    fun sendMouseClick(rightButton: Boolean = false, doubleClick: Boolean = false) {
        markActivity()
        triggerHapticAndSound(true)
        val connected = uiState.value.connectedDevice
        if (connected == null) {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        if (connected.mode != ConnectionMode.BLUETOOTH_HID) {
            if (!rightButton) {
                sendRemoteCommand(RemoteCommand.DPAD_OK, strongFeedback = true)
            } else {
                sendRemoteCommand(RemoteCommand.BACK)
            }
            return
        }
        val mask = if (rightButton) 0x02 else 0x01
        val err = bluetoothService.sendMouseClick(buttonsBitmask = mask, releaseAfter = true)
        if (err != null) {
            _explicitError.value = err
            return
        }
        if (doubleClick) {
            viewModelScope.launch {
                delay(70L)
                val secondErr = bluetoothService.sendMouseClick(buttonsBitmask = mask, releaseAfter = true)
                if (secondErr != null) _explicitError.value = secondErr
            }
        }
    }

    fun toggleDragLock() {
        val connected = uiState.value.connectedDevice
        if (connected?.mode != ConnectionMode.BLUETOOTH_HID) {
            _explicitError.value = RemoteError.UnsupportedFeature("Drag & Drop", "bt_hid_only")
            return
        }
        val next = !_isDragLocked.value
        val err = bluetoothService.sendMouseClick(
            buttonsBitmask = if (next) 0x01 else 0x00,
            releaseAfter = false
        )
        if (err != null) {
            _explicitError.value = err
        } else {
            _isDragLocked.value = next
        }
    }

    fun sendMouseScroll(wheelDelta: Int) {
        markActivity()
        val connected = uiState.value.connectedDevice ?: return
        if (connected.mode == ConnectionMode.BLUETOOTH_HID) {
            val err = bluetoothService.sendMouseScroll(wheelDelta.coerceIn(-12, 12))
            if (err != null) _explicitError.value = err
        } else {
            sendRemoteCommand(if (wheelDelta > 0) RemoteCommand.DPAD_UP else RemoteCommand.DPAD_DOWN)
        }
    }

    fun setAirMouseEnabled(enabled: Boolean) {
        markActivity()
        if (!enabled) {
            airMouseController.stop()
            return
        }
        val connected = uiState.value.connectedDevice
        if (connected == null) {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        if (connected.mode != ConnectionMode.BLUETOOTH_HID) {
            _explicitError.value = RemoteError.UnsupportedFeature("Air Mouse HID", "bt_hid_only")
            return
        }
        if (!airMouseController.hasHardwareSensor) {
            _explicitError.value = RemoteError.UnsupportedFeature("Gyroscope / Accelerometer", "no_sensor")
            return
        }
        val prefs = uiState.value.preferences
        airMouseController.start(
            sensitivity = prefs.airMouseSensitivity,
            pointerSpeed = prefs.airMousePointerSpeed,
            samplingTier = prefs.batterySaver.sensorSamplingTier
        ) { dx, dy ->
            val mask = if (_isDragLocked.value) 0x01 else 0x00
            val err = bluetoothService.sendMouseMove(dx, dy, mask)
            if (err != null) {
                airMouseController.stop()
                _explicitError.value = err
            }
        }
    }

    fun calibrateAirMouse() {
        airMouseController.calibrateZero()
        showNotice("Air Mouse zero point calibrated.")
    }

    fun updateMouseTuning(airSens: Float, airSpeed: Float, touchpadSens: Float) {
        viewModelScope.launch {
            prefsRepo.updateMouseSettings(airSens, airSpeed, touchpadSens)
            airMouseController.updateTuning(
                airSens,
                airSpeed,
                uiState.value.preferences.batterySaver.sensorSamplingTier
            )
        }
    }

    // --- Keyboard (Module 1 & 4) ---

    fun sendKeyboardText(text: String) {
        if (text.isEmpty()) return
        markActivity()
        triggerHapticAndSound()
        val connected = uiState.value.connectedDevice ?: run {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        when (connected.mode) {
            ConnectionMode.BLUETOOTH_HID -> {
                val err = bluetoothService.sendText(text)
                if (err != null) _explicitError.value = err
            }
            ConnectionMode.WIFI_ANDROID_TV -> {
                wifiClient.sendText(text) { err ->
                    if (err != null) _explicitError.value = err
                }
            }
        }
    }

    fun sendModifierKeyboardStroke(modifier: Byte, keyCode: Byte) {
        markActivity()
        triggerHapticAndSound()
        val connected = uiState.value.connectedDevice ?: run {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        if (connected.mode != ConnectionMode.BLUETOOTH_HID) {
            _explicitError.value = RemoteError.UnsupportedFeature("HID Modifier Keys", "bt_hid_only")
            return
        }
        val err = bluetoothService.sendKeyboardStroke(modifier, keyCode)
        if (err != null) _explicitError.value = err
    }

    fun sendBackspaceKey() {
        markActivity()
        triggerHapticAndSound()
        val connected = uiState.value.connectedDevice ?: run {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        when (connected.mode) {
            ConnectionMode.BLUETOOTH_HID -> {
                val err = bluetoothService.sendKeyboardStroke(0, 0x2A)
                if (err != null) _explicitError.value = err
            }
            ConnectionMode.WIFI_ANDROID_TV -> wifiClient.sendCommand(RemoteCommand.BACK)
        }
    }

    fun sendEnterKey() {
        markActivity()
        triggerHapticAndSound(true)
        val connected = uiState.value.connectedDevice ?: run {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        when (connected.mode) {
            ConnectionMode.BLUETOOTH_HID -> {
                val err = bluetoothService.sendKeyboardStroke(0, 0x28)
                if (err != null) _explicitError.value = err
            }
            ConnectionMode.WIFI_ANDROID_TV -> wifiClient.sendCommand(RemoteCommand.DPAD_OK)
        }
    }

    // --- Quick Apps & Smart App Launcher (Modules 2 & 3) ---

    fun launchTvApp(app: TvAppShortcut) {
        markActivity()
        triggerHapticAndSound(true)
        val connected = uiState.value.connectedDevice
        if (connected == null) {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        if (connected.mode == ConnectionMode.BLUETOOTH_HID) {
            _explicitError.value = RemoteError.UnsupportedFeature(
                app.name,
                "bt_hid_no_app_launch"
            )
            return
        }
        if (app.deepLinkUri.isBlank()) {
            if (app.id == "tv_settings") {
                sendRemoteCommand(RemoteCommand.SETTINGS)
            } else {
                _explicitError.value = RemoteError.UnsupportedFeature(app.name, "missing_deeplink")
            }
            return
        }
        wifiClient.launchAppLink(app.deepLinkUri) { err ->
            if (err != null) {
                _explicitError.value = err
            } else {
                viewModelScope.launch {
                    val updated = uiState.value.preferences.pinnedQuickApps.map {
                        if (it.id == app.id) it.copy(lastLaunchedMs = System.currentTimeMillis()) else it
                    }
                    prefsRepo.saveQuickApps(updated)
                }
                showNotice("Sent launch request for ${app.name} to TV.")
            }
        }
    }

    fun toggleAppFavorite(appId: String) {
        viewModelScope.launch {
            val updated = uiState.value.preferences.pinnedQuickApps.map {
                if (it.id == appId) it.copy(isFavorite = !it.isFavorite) else it
            }
            prefsRepo.saveQuickApps(updated)
        }
    }

    fun toggleAppPinnedQuick(appId: String) {
        viewModelScope.launch {
            val updated = uiState.value.preferences.pinnedQuickApps.map {
                if (it.id == appId) it.copy(isPinnedQuickApp = !it.isPinnedQuickApp) else it
            }
            prefsRepo.saveQuickApps(updated)
        }
    }

    fun addCustomQuickApp(name: String, deepLinkUri: String, packageName: String) {
        if (name.isBlank() || deepLinkUri.isBlank()) return
        viewModelScope.launch {
            val newApp = TvAppShortcut(
                id = UUID.randomUUID().toString(),
                name = name.trim(),
                packageName = packageName.trim(),
                deepLinkUri = deepLinkUri.trim(),
                iconKey = "apps",
                isFavorite = true,
                isPinnedQuickApp = true
            )
            prefsRepo.saveQuickApps(uiState.value.preferences.pinnedQuickApps + newApp)
        }
    }

    fun refreshTvAppsCapability() {
        val connected = uiState.value.connectedDevice
        if (connected == null) {
            _explicitError.value = RemoteError.NotConnected
        } else if (connected.mode == ConnectionMode.BLUETOOTH_HID) {
            showNotice(stringsFor(uiState.value.preferences.language).btAppEnumerationNotice)
        } else {
            showNotice(stringsFor(uiState.value.preferences.language).stockWifiAppNotice)
        }
    }

    // --- Voice Control (Module 4) ---

    fun hasMicrophonePermission(): Boolean = voiceController.hasAudioPermission()

    fun startVoiceControl() {
        markActivity()
        val lang = uiState.value.preferences.language
        voiceController.startListening(lang) { spoken, parsed ->
            when (parsed) {
                is ParsedVoiceIntent.Command -> sendRemoteCommand(parsed.command, strongFeedback = true)
                is ParsedVoiceIntent.LaunchApp -> {
                    val app = uiState.value.preferences.pinnedQuickApps.firstOrNull { it.id == parsed.appId }
                    if (app != null) launchTvApp(app)
                }
                is ParsedVoiceIntent.SearchQuery -> {
                    sendRemoteCommand(RemoteCommand.SEARCH)
                    viewModelScope.launch {
                        delay(350L)
                        sendKeyboardText(parsed.query)
                    }
                }
                is ParsedVoiceIntent.Unrecognized -> {
                    showNotice("Recognized \"$spoken\" (no remote command matched).")
                }
            }
        }
    }

    fun stopVoiceControl() {
        voiceController.stopListening()
    }

    // --- Screenshot & Brightness ---

    fun triggerTvScreenshotKey() {
        val connected = uiState.value.connectedDevice
        if (connected == null) {
            _explicitError.value = RemoteError.NotConnected
            return
        }
        sendRemoteCommand(RemoteCommand.SCREENSHOT, strongFeedback = true)
        showNotice("Sent Screenshot key to TV. Note: TV OS controls screenshot saving.")
    }

    fun saveRemoteSnapshot() {
        val uri = screenshotHelper.saveRemoteSessionSnapshot(uiState.value.connectedDevice)
        _lastSnapshotUri.value = uri
        if (uri != null) {
            showNotice("Saved snapshot to Pictures/BluetoothRemote.")
        }
    }

    fun shareLastSnapshot() {
        val uri = _lastSnapshotUri.value ?: screenshotHelper.saveRemoteSessionSnapshot(uiState.value.connectedDevice)
        _lastSnapshotUri.value = uri
        if (uri != null) {
            screenshotHelper.shareImageUri(uri)
        }
    }

    // --- File Transfer (Module 7) ---

    fun addTransferFiles(uris: List<Uri>) {
        fileTransferClient.addFilesFromUris(uris)
    }

    fun removeTransferItem(id: String) {
        fileTransferClient.removeItem(id)
    }

    fun startLocalFileTransfer(host: String, port: Int, pin: String) {
        markActivity()
        fileTransferClient.startTransfer(host, port, pin) { finished ->
            viewModelScope.launch {
                prefsRepo.appendTransferHistory(
                    TransferHistoryRecord(
                        id = finished.id,
                        fileName = finished.fileName,
                        sizeBytes = finished.sizeBytes,
                        targetName = host,
                        timestampMs = System.currentTimeMillis(),
                        succeeded = finished.status == TransferStatus.COMPLETED,
                        note = finished.errorDetail ?: "ACK confirmed"
                    )
                )
            }
        }
    }

    fun cancelFileTransfer() {
        fileTransferClient.cancelTransfer()
    }

    // --- Media Cast, Mirroring & TV Recording (Modules 8, 9, 10) ---

    fun selectMediaForCast(uri: Uri, isVideo: Boolean) {
        val resolver = getApplication<Application>().contentResolver
        val mime = resolver.getType(uri) ?: if (isVideo) "video/mp4" else "image/jpeg"
        var name = if (isVideo) "Video" else "Photo"
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = c.getString(idx) ?: name
                }
            }
        }
        _selectedCastMedia.value = CastMediaSelection(uri.toString(), name, mime, isVideo)
    }

    fun refreshCastDevices() = mediaCastManager.refreshRoutes()
    fun selectCastDevice(routeId: String) = mediaCastManager.selectRoute(routeId)
    fun castSelectedMedia() {
        val media = _selectedCastMedia.value ?: return
        mediaCastManager.castMedia(media)
    }
    fun toggleCastPlayPause() = mediaCastManager.togglePlayPause()
    fun seekCast(deltaMs: Long) = mediaCastManager.seekBy(deltaMs)
    fun setCastVolume(volume: Double) = mediaCastManager.setCastVolume(volume)
    fun stopCasting() = mediaCastManager.stopCasting()

    fun createMirroringPermissionIntent(): Intent? = screenMirrorController.createCapturePermissionIntent()
    fun onMirroringPermissionResult(resultCode: Int, data: Intent?) {
        screenMirrorController.onMediaProjectionResult(resultCode, data)
    }
    fun stopMirroring() = screenMirrorController.stopMirroring()
    fun openSystemCastSettings() = screenMirrorController.openSystemCastSettings()

    fun requestTvRecording(host: String, port: Int, pin: String) {
        screenMirrorController.requestTvScreenRecording(host, port, pin)
    }
    fun stopTvRecording(host: String, port: Int, pin: String) {
        screenMirrorController.stopTvScreenRecording(host, port, pin)
    }

    // --- Custom Remote Builder (Module 11) ---

    fun addCustomButton(label: String, command: RemoteCommand, iconKey: String, size: RemoteButtonSize) {
        val prefs = uiState.value.preferences
        val layouts = prefs.customLayouts.toMutableList()
        val idx = layouts.indexOfFirst { it.id == prefs.activeLayoutId }.takeIf { it >= 0 } ?: 0
        val current = layouts[idx]
        val nextBtn = CustomRemoteButton(
            id = UUID.randomUUID().toString(),
            label = label.ifBlank { command.name },
            command = command,
            iconKey = iconKey,
            size = size,
            orderIndex = current.buttons.size
        )
        layouts[idx] = current.copy(buttons = current.buttons + nextBtn)
        viewModelScope.launch { prefsRepo.saveCustomLayouts(layouts, layouts[idx].id) }
    }

    fun removeCustomButton(buttonId: String) {
        val prefs = uiState.value.preferences
        val layouts = prefs.customLayouts.map { layout ->
            if (layout.id == prefs.activeLayoutId) {
                layout.copy(buttons = layout.buttons.filterNot { it.id == buttonId })
            } else layout
        }
        viewModelScope.launch { prefsRepo.saveCustomLayouts(layouts, prefs.activeLayoutId) }
    }

    fun renameCustomButton(buttonId: String, newLabel: String) {
        if (newLabel.isBlank()) return
        val prefs = uiState.value.preferences
        val layouts = prefs.customLayouts.map { layout ->
            if (layout.id == prefs.activeLayoutId) {
                layout.copy(buttons = layout.buttons.map {
                    if (it.id == buttonId) it.copy(label = newLabel.trim()) else it
                })
            } else layout
        }
        viewModelScope.launch { prefsRepo.saveCustomLayouts(layouts, prefs.activeLayoutId) }
    }

    fun cycleCustomButtonSize(buttonId: String) {
        val prefs = uiState.value.preferences
        val layouts = prefs.customLayouts.map { layout ->
            if (layout.id == prefs.activeLayoutId) {
                layout.copy(buttons = layout.buttons.map {
                    if (it.id == buttonId) {
                        val nextSize = when (it.size) {
                            RemoteButtonSize.SMALL -> RemoteButtonSize.MEDIUM
                            RemoteButtonSize.MEDIUM -> RemoteButtonSize.LARGE
                            RemoteButtonSize.LARGE -> RemoteButtonSize.SMALL
                        }
                        it.copy(size = nextSize)
                    } else it
                })
            } else layout
        }
        viewModelScope.launch { prefsRepo.saveCustomLayouts(layouts, prefs.activeLayoutId) }
    }

    fun moveCustomButton(buttonId: String, delta: Int) {
        val prefs = uiState.value.preferences
        val layouts = prefs.customLayouts.map { layout ->
            if (layout.id == prefs.activeLayoutId) {
                val list = layout.buttons.toMutableList()
                val idx = list.indexOfFirst { it.id == buttonId }
                val target = (idx + delta).coerceIn(0, (list.size - 1).coerceAtLeast(0))
                if (idx >= 0 && idx != target) {
                    val item = list.removeAt(idx)
                    list.add(target, item)
                }
                layout.copy(buttons = list.mapIndexed { i, b -> b.copy(orderIndex = i) })
            } else layout
        }
        viewModelScope.launch { prefsRepo.saveCustomLayouts(layouts, prefs.activeLayoutId) }
    }

    fun createNewCustomLayout(name: String) {
        if (name.isBlank()) return
        val newLayout = CustomRemoteLayout(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            buttons = PreferencesRepository.defaultRemoteLayout().buttons
        )
        val layouts = uiState.value.preferences.customLayouts + newLayout
        viewModelScope.launch { prefsRepo.saveCustomLayouts(layouts, newLayout.id) }
    }

    fun selectActiveLayout(layoutId: String) {
        viewModelScope.launch { prefsRepo.setActiveLayoutId(layoutId) }
    }

    fun restoreDefaultCustomLayout() {
        val def = PreferencesRepository.defaultRemoteLayout()
        val others = uiState.value.preferences.customLayouts.filterNot { it.id == "default" }
        viewModelScope.launch { prefsRepo.saveCustomLayouts(listOf(def) + others, "default") }
    }

    // --- TV Profiles & Preferences (Modules 12, 13, 15) ---

    private fun recordSuccessfulConnection(device: ConnectedDeviceInfo) {
        viewModelScope.launch {
            val existing = uiState.value.preferences.profiles.firstOrNull { it.id == device.id }
            val profile = existing?.copy(
                lastConnectedEpochMs = System.currentTimeMillis(),
                isPaired = true
            ) ?: TvProfile(
                id = device.id,
                name = device.name,
                icon = TvDeviceIcon.LIVING_ROOM_TV,
                mode = device.mode,
                addressOrHost = device.addressOrHost,
                port = device.port,
                isFavorite = false,
                lastConnectedEpochMs = System.currentTimeMillis(),
                isPaired = true
            )
            prefsRepo.upsertProfile(profile)
            prefsRepo.appendConnectionHistory(
                ConnectionHistoryEntry(
                    id = UUID.randomUUID().toString(),
                    deviceName = device.name,
                    mode = device.mode,
                    target = device.addressOrHost,
                    timestampMs = System.currentTimeMillis(),
                    succeeded = true,
                    message = "Connected"
                )
            )
        }
    }

    fun updateTvProfile(profile: TvProfile) {
        viewModelScope.launch { prefsRepo.upsertProfile(profile) }
    }

    fun toggleProfileFavorite(profileId: String) {
        viewModelScope.launch { prefsRepo.toggleProfileFavorite(profileId) }
    }

    fun deleteTvProfile(profileId: String) {
        viewModelScope.launch { prefsRepo.deleteProfile(profileId) }
    }

    fun completeOnboarding() {
        viewModelScope.launch { prefsRepo.setOnboardingCompleted() }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setDarkTheme(enabled) }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { prefsRepo.setLanguage(language) }
    }

    fun setHapticEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setHapticEnabled(enabled) }
    }

    fun setSoundEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setSoundEnabled(enabled) }
    }

    fun setAutoReconnect(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setAutoReconnect(enabled) }
    }

    fun updateBatterySaver(settings: BatterySaverSettings) {
        viewModelScope.launch {
            prefsRepo.updateBatterySaver(settings)
            if (settings.lowPowerMode) {
                stopScanning()
            }
        }
    }

    fun dismissError() {
        _explicitError.value = null
    }

    fun dismissNotice() {
        _statusNotice.value = null
    }

    private fun showNotice(msg: String) {
        _statusNotice.value = msg
    }

    override fun onCleared() {
        super.onCleared()
        airMouseController.stop()
        voiceController.stopListening()
        bluetoothService.release()
        nsdManager.stopDiscovery()
        wifiClient.disconnect()
        mediaCastManager.release()
        feedbackManager.release()
    }
}
