package com.example.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.PowerManager
import com.example.model.BatteryStatus
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class DeviceStatusMonitor(private val context: Context) {

    fun observeBatteryStatus(): Flow<BatteryStatus> = callbackFlow {
        fun readCurrent(): BatteryStatus {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            val charging = bm?.isCharging ?: false
            val powerSave = pm?.isPowerSaveMode ?: false
            return BatteryStatus(
                percentage = pct.coerceIn(-1, 100),
                isCharging = charging,
                batterySaverActiveOnSystem = powerSave
            )
        }

        trySend(readCurrent())

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                val pct = if (level >= 0 && scale > 0) (level * 100) / scale else readCurrent().percentage
                trySend(
                    BatteryStatus(
                        percentage = pct.coerceIn(-1, 100),
                        isCharging = isCharging,
                        batterySaverActiveOnSystem = pm?.isPowerSaveMode ?: false
                    )
                )
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
        }
        context.registerReceiver(receiver, filter)

        awaitClose {
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    fun isWifiConnected(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }
}
