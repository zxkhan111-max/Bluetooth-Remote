package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.AppPreferences
import com.example.model.BatterySaverSettings
import com.example.model.ConnectionHistoryEntry
import com.example.model.ConnectionMode
import com.example.model.ConnectionTimeoutOption
import com.example.model.CustomRemoteButton
import com.example.model.CustomRemoteLayout
import com.example.model.RemoteButtonSize
import com.example.model.RemoteCommand
import com.example.model.SensorSamplingTier
import com.example.model.TransferHistoryRecord
import com.example.model.TvAppShortcut
import com.example.model.TvDeviceIcon
import com.example.model.TvProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.remoteDataStore: DataStore<Preferences> by preferencesDataStore(name = "bluetooth_remote_prefs")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val LANGUAGE = stringPreferencesKey("language")
        val HAPTIC = booleanPreferencesKey("haptic")
        val SOUND = booleanPreferencesKey("sound")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
        val PREFERRED_MODE = stringPreferencesKey("preferred_mode")
        val AIR_MOUSE_SENSITIVITY = floatPreferencesKey("air_mouse_sens")
        val AIR_MOUSE_SPEED = floatPreferencesKey("air_mouse_speed")
        val TOUCHPAD_SENSITIVITY = floatPreferencesKey("touchpad_sens")
        val BATTERY_LOW_POWER = booleanPreferencesKey("bat_low_power")
        val BATTERY_REDUCE_SCAN = booleanPreferencesKey("bat_reduce_scan")
        val BATTERY_REDUCE_POLL = booleanPreferencesKey("bat_reduce_poll")
        val BATTERY_DISABLE_ANIM = booleanPreferencesKey("bat_disable_anim")
        val BATTERY_SENSOR_TIER = stringPreferencesKey("bat_sensor_tier")
        val BATTERY_TIMEOUT_MIN = intPreferencesKey("bat_timeout_min")
        val PROFILES_JSON = stringPreferencesKey("profiles_json")
        val HISTORY_JSON = stringPreferencesKey("history_json")
        val CUSTOM_LAYOUTS_JSON = stringPreferencesKey("custom_layouts_json")
        val ACTIVE_LAYOUT_ID = stringPreferencesKey("active_layout_id")
        val QUICK_APPS_JSON = stringPreferencesKey("quick_apps_json")
        val TRANSFER_HISTORY_JSON = stringPreferencesKey("transfer_history_json")
    }

    val preferencesFlow: Flow<AppPreferences> = context.remoteDataStore.data.map { prefs ->
        val lang = AppLanguage.entries.firstOrNull { it.code == prefs[Keys.LANGUAGE] } ?: AppLanguage.ENGLISH
        val mode = runCatching {
            ConnectionMode.valueOf(prefs[Keys.PREFERRED_MODE] ?: ConnectionMode.BLUETOOTH_HID.name)
        }.getOrDefault(ConnectionMode.BLUETOOTH_HID)

        val sensorTier = runCatching {
            SensorSamplingTier.valueOf(prefs[Keys.BATTERY_SENSOR_TIER] ?: SensorSamplingTier.BALANCED.name)
        }.getOrDefault(SensorSamplingTier.BALANCED)

        val timeoutMinutes = prefs[Keys.BATTERY_TIMEOUT_MIN] ?: 15
        val timeoutOpt = ConnectionTimeoutOption.entries.firstOrNull { it.minutes == timeoutMinutes }
            ?: ConnectionTimeoutOption.FIFTEEN_MIN

        val layouts = decodeLayouts(prefs[Keys.CUSTOM_LAYOUTS_JSON]).ifEmpty { listOf(defaultRemoteLayout()) }
        val quickApps = decodeQuickApps(prefs[Keys.QUICK_APPS_JSON]).ifEmpty { defaultQuickApps() }

        AppPreferences(
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            darkTheme = prefs[Keys.DARK_THEME] ?: true,
            language = lang,
            hapticEnabled = prefs[Keys.HAPTIC] ?: true,
            soundEnabled = prefs[Keys.SOUND] ?: false,
            autoReconnect = prefs[Keys.AUTO_RECONNECT] ?: true,
            preferredMode = mode,
            airMouseSensitivity = prefs[Keys.AIR_MOUSE_SENSITIVITY] ?: 1.0f,
            airMousePointerSpeed = prefs[Keys.AIR_MOUSE_SPEED] ?: 1.0f,
            touchpadSensitivity = prefs[Keys.TOUCHPAD_SENSITIVITY] ?: 1.0f,
            batterySaver = BatterySaverSettings(
                lowPowerMode = prefs[Keys.BATTERY_LOW_POWER] ?: false,
                reduceScanning = prefs[Keys.BATTERY_REDUCE_SCAN] ?: false,
                reduceKeepalivePolling = prefs[Keys.BATTERY_REDUCE_POLL] ?: false,
                sensorSamplingTier = sensorTier,
                disableAnimations = prefs[Keys.BATTERY_DISABLE_ANIM] ?: false,
                connectionTimeout = timeoutOpt
            ),
            profiles = decodeProfiles(prefs[Keys.PROFILES_JSON]),
            connectionHistory = decodeHistory(prefs[Keys.HISTORY_JSON]),
            customLayouts = layouts,
            activeLayoutId = prefs[Keys.ACTIVE_LAYOUT_ID] ?: "default",
            pinnedQuickApps = quickApps,
            transferHistory = decodeTransferHistory(prefs[Keys.TRANSFER_HISTORY_JSON])
        )
    }

    suspend fun setOnboardingCompleted() {
        context.remoteDataStore.edit { it[Keys.ONBOARDING_DONE] = true }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.remoteDataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.remoteDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.remoteDataStore.edit { it[Keys.HAPTIC] = enabled }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.remoteDataStore.edit { it[Keys.SOUND] = enabled }
    }

    suspend fun setAutoReconnect(enabled: Boolean) {
        context.remoteDataStore.edit { it[Keys.AUTO_RECONNECT] = enabled }
    }

    suspend fun setPreferredMode(mode: ConnectionMode) {
        context.remoteDataStore.edit { it[Keys.PREFERRED_MODE] = mode.name }
    }

    suspend fun updateMouseSettings(airSens: Float, airSpeed: Float, touchpadSens: Float) {
        context.remoteDataStore.edit {
            it[Keys.AIR_MOUSE_SENSITIVITY] = airSens.coerceIn(0.3f, 3.0f)
            it[Keys.AIR_MOUSE_SPEED] = airSpeed.coerceIn(0.3f, 3.0f)
            it[Keys.TOUCHPAD_SENSITIVITY] = touchpadSens.coerceIn(0.3f, 3.0f)
        }
    }

    suspend fun updateBatterySaver(settings: BatterySaverSettings) {
        context.remoteDataStore.edit {
            it[Keys.BATTERY_LOW_POWER] = settings.lowPowerMode
            it[Keys.BATTERY_REDUCE_SCAN] = settings.reduceScanning
            it[Keys.BATTERY_REDUCE_POLL] = settings.reduceKeepalivePolling
            it[Keys.BATTERY_DISABLE_ANIM] = settings.disableAnimations
            it[Keys.BATTERY_SENSOR_TIER] = settings.sensorSamplingTier.name
            it[Keys.BATTERY_TIMEOUT_MIN] = settings.connectionTimeout.minutes
        }
    }

    suspend fun upsertProfile(profile: TvProfile) {
        context.remoteDataStore.edit { prefs ->
            val current = decodeProfiles(prefs[Keys.PROFILES_JSON]).toMutableList()
            val idx = current.indexOfFirst { it.id == profile.id }
            if (idx >= 0) current[idx] = profile else current.add(0, profile)
            prefs[Keys.PROFILES_JSON] = encodeProfiles(current)
        }
    }

    suspend fun deleteProfile(profileId: String) {
        context.remoteDataStore.edit { prefs ->
            val current = decodeProfiles(prefs[Keys.PROFILES_JSON]).filterNot { it.id == profileId }
            prefs[Keys.PROFILES_JSON] = encodeProfiles(current)
        }
    }

    suspend fun toggleProfileFavorite(profileId: String) {
        context.remoteDataStore.edit { prefs ->
            val current = decodeProfiles(prefs[Keys.PROFILES_JSON]).map {
                if (it.id == profileId) it.copy(isFavorite = !it.isFavorite) else it
            }
            prefs[Keys.PROFILES_JSON] = encodeProfiles(current)
        }
    }

    suspend fun appendConnectionHistory(entry: ConnectionHistoryEntry) {
        context.remoteDataStore.edit { prefs ->
            val updated = (listOf(entry) + decodeHistory(prefs[Keys.HISTORY_JSON])).take(40)
            prefs[Keys.HISTORY_JSON] = encodeHistory(updated)
        }
    }

    suspend fun saveCustomLayouts(layouts: List<CustomRemoteLayout>, activeId: String) {
        context.remoteDataStore.edit { prefs ->
            prefs[Keys.CUSTOM_LAYOUTS_JSON] = encodeLayouts(layouts)
            prefs[Keys.ACTIVE_LAYOUT_ID] = activeId
        }
    }

    suspend fun setActiveLayoutId(layoutId: String) {
        context.remoteDataStore.edit { it[Keys.ACTIVE_LAYOUT_ID] = layoutId }
    }

    suspend fun saveQuickApps(apps: List<TvAppShortcut>) {
        context.remoteDataStore.edit { prefs ->
            prefs[Keys.QUICK_APPS_JSON] = encodeQuickApps(apps)
        }
    }

    suspend fun appendTransferHistory(record: TransferHistoryRecord) {
        context.remoteDataStore.edit { prefs ->
            val updated = (listOf(record) + decodeTransferHistory(prefs[Keys.TRANSFER_HISTORY_JSON])).take(40)
            prefs[Keys.TRANSFER_HISTORY_JSON] = encodeTransferHistory(updated)
        }
    }

    companion object {
        fun defaultRemoteLayout(): CustomRemoteLayout = CustomRemoteLayout(
            id = "default",
            name = "Smart TV Essentials",
            buttons = listOf(
                CustomRemoteButton("b_power", "Power", RemoteCommand.POWER, "power", RemoteButtonSize.MEDIUM, 0),
                CustomRemoteButton("b_home", "Home", RemoteCommand.HOME, "home", RemoteButtonSize.MEDIUM, 1),
                CustomRemoteButton("b_back", "Back", RemoteCommand.BACK, "back", RemoteButtonSize.MEDIUM, 2),
                CustomRemoteButton("b_mute", "Mute", RemoteCommand.MUTE, "mute", RemoteButtonSize.SMALL, 3),
                CustomRemoteButton("b_vol_up", "Vol +", RemoteCommand.VOLUME_UP, "vol_up", RemoteButtonSize.LARGE, 4),
                CustomRemoteButton("b_vol_dn", "Vol -", RemoteCommand.VOLUME_DOWN, "vol_down", RemoteButtonSize.LARGE, 5),
                CustomRemoteButton("b_play", "Play/Pause", RemoteCommand.PLAY_PAUSE, "play", RemoteButtonSize.LARGE, 6),
                CustomRemoteButton("b_settings", "Settings", RemoteCommand.SETTINGS, "settings", RemoteButtonSize.SMALL, 7)
            )
        )

        fun defaultQuickApps(): List<TvAppShortcut> = listOf(
            TvAppShortcut(
                id = "yt",
                name = "YouTube",
                packageName = "com.google.android.youtube.tv",
                deepLinkUri = "https://www.youtube.com",
                iconKey = "youtube",
                isFavorite = true,
                isPinnedQuickApp = true
            ),
            TvAppShortcut(
                id = "nf",
                name = "Netflix",
                packageName = "com.netflix.ninja",
                deepLinkUri = "https://www.netflix.com",
                iconKey = "netflix",
                isFavorite = true,
                isPinnedQuickApp = true
            ),
            TvAppShortcut(
                id = "ps",
                name = "Play Store",
                packageName = "com.android.vending",
                deepLinkUri = "https://play.google.com/store",
                iconKey = "store",
                isFavorite = true,
                isPinnedQuickApp = true
            ),
            TvAppShortcut(
                id = "pv",
                name = "Prime Video",
                packageName = "com.amazon.amazonvideo.livingroom",
                deepLinkUri = "https://app.primevideo.com",
                iconKey = "video",
                isFavorite = false,
                isPinnedQuickApp = false
            ),
            TvAppShortcut(
                id = "sp",
                name = "Spotify",
                packageName = "com.spotify.tv.android",
                deepLinkUri = "https://open.spotify.com",
                iconKey = "music",
                isFavorite = false,
                isPinnedQuickApp = false
            ),
            TvAppShortcut(
                id = "tv_settings",
                name = "TV Settings",
                packageName = "com.android.tv.settings",
                deepLinkUri = "",
                iconKey = "settings",
                isFavorite = false,
                isPinnedQuickApp = false
            )
        )

        private fun encodeProfiles(list: List<TvProfile>): String {
            val arr = JSONArray()
            list.forEach { p ->
                arr.put(JSONObject().apply {
                    put("id", p.id)
                    put("name", p.name)
                    put("icon", p.icon.key)
                    put("mode", p.mode.name)
                    put("host", p.addressOrHost)
                    put("port", p.port)
                    put("fav", p.isFavorite)
                    put("last", p.lastConnectedEpochMs)
                    put("paired", p.isPaired)
                    put("layout", p.customLayoutId)
                })
            }
            return arr.toString()
        }

        private fun decodeProfiles(json: String?): List<TvProfile> {
            if (json.isNullOrBlank()) return emptyList()
            return runCatching {
                val arr = JSONArray(json)
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(
                            TvProfile(
                                id = o.getString("id"),
                                name = o.getString("name"),
                                icon = TvDeviceIcon.entries.firstOrNull { it.key == o.optString("icon") }
                                    ?: TvDeviceIcon.LIVING_ROOM_TV,
                                mode = ConnectionMode.valueOf(o.getString("mode")),
                                addressOrHost = o.getString("host"),
                                port = o.optInt("port", 6466),
                                isFavorite = o.optBoolean("fav", false),
                                lastConnectedEpochMs = o.optLong("last", 0L),
                                isPaired = o.optBoolean("paired", false),
                                customLayoutId = o.optString("layout", "default")
                            )
                        )
                    }
                }
            }.getOrDefault(emptyList())
        }

        private fun encodeHistory(list: List<ConnectionHistoryEntry>): String {
            val arr = JSONArray()
            list.forEach { h ->
                arr.put(JSONObject().apply {
                    put("id", h.id)
                    put("name", h.deviceName)
                    put("mode", h.mode.name)
                    put("target", h.target)
                    put("ts", h.timestampMs)
                    put("ok", h.succeeded)
                    put("msg", h.message)
                })
            }
            return arr.toString()
        }

        private fun decodeHistory(json: String?): List<ConnectionHistoryEntry> {
            if (json.isNullOrBlank()) return emptyList()
            return runCatching {
                val arr = JSONArray(json)
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(
                            ConnectionHistoryEntry(
                                id = o.getString("id"),
                                deviceName = o.getString("name"),
                                mode = ConnectionMode.valueOf(o.getString("mode")),
                                target = o.getString("target"),
                                timestampMs = o.getLong("ts"),
                                succeeded = o.getBoolean("ok"),
                                message = o.optString("msg", "")
                            )
                        )
                    }
                }
            }.getOrDefault(emptyList())
        }

        private fun encodeLayouts(list: List<CustomRemoteLayout>): String {
            val arr = JSONArray()
            list.forEach { layout ->
                val btns = JSONArray()
                layout.buttons.forEach { b ->
                    btns.put(JSONObject().apply {
                        put("id", b.id)
                        put("label", b.label)
                        put("cmd", b.command.name)
                        put("icon", b.iconKey)
                        put("size", b.size.name)
                        put("order", b.orderIndex)
                    })
                }
                arr.put(JSONObject().apply {
                    put("id", layout.id)
                    put("name", layout.name)
                    put("buttons", btns)
                })
            }
            return arr.toString()
        }

        private fun decodeLayouts(json: String?): List<CustomRemoteLayout> {
            if (json.isNullOrBlank()) return emptyList()
            return runCatching {
                val arr = JSONArray(json)
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val btnsArr = o.getJSONArray("buttons")
                        val buttons = buildList {
                            for (j in 0 until btnsArr.length()) {
                                val b = btnsArr.getJSONObject(j)
                                add(
                                    CustomRemoteButton(
                                        id = b.getString("id"),
                                        label = b.getString("label"),
                                        command = RemoteCommand.valueOf(b.getString("cmd")),
                                        iconKey = b.optString("icon", "power"),
                                        size = RemoteButtonSize.valueOf(b.optString("size", "MEDIUM")),
                                        orderIndex = b.optInt("order", j)
                                    )
                                )
                            }
                        }
                        add(CustomRemoteLayout(o.getString("id"), o.getString("name"), buttons))
                    }
                }
            }.getOrDefault(emptyList())
        }

        private fun encodeQuickApps(list: List<TvAppShortcut>): String {
            val arr = JSONArray()
            list.forEach { a ->
                arr.put(JSONObject().apply {
                    put("id", a.id)
                    put("name", a.name)
                    put("pkg", a.packageName)
                    put("uri", a.deepLinkUri)
                    put("icon", a.iconKey)
                    put("fav", a.isFavorite)
                    put("pin", a.isPinnedQuickApp)
                    put("last", a.lastLaunchedMs)
                })
            }
            return arr.toString()
        }

        private fun decodeQuickApps(json: String?): List<TvAppShortcut> {
            if (json.isNullOrBlank()) return emptyList()
            return runCatching {
                val arr = JSONArray(json)
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(
                            TvAppShortcut(
                                id = o.getString("id"),
                                name = o.getString("name"),
                                packageName = o.optString("pkg", ""),
                                deepLinkUri = o.optString("uri", ""),
                                iconKey = o.optString("icon", "apps"),
                                isFavorite = o.optBoolean("fav", false),
                                isPinnedQuickApp = o.optBoolean("pin", false),
                                lastLaunchedMs = o.optLong("last", 0L)
                            )
                        )
                    }
                }
            }.getOrDefault(emptyList())
        }

        private fun encodeTransferHistory(list: List<TransferHistoryRecord>): String {
            val arr = JSONArray()
            list.forEach { t ->
                arr.put(JSONObject().apply {
                    put("id", t.id)
                    put("file", t.fileName)
                    put("size", t.sizeBytes)
                    put("target", t.targetName)
                    put("ts", t.timestampMs)
                    put("ok", t.succeeded)
                    put("note", t.note)
                })
            }
            return arr.toString()
        }

        private fun decodeTransferHistory(json: String?): List<TransferHistoryRecord> {
            if (json.isNullOrBlank()) return emptyList()
            return runCatching {
                val arr = JSONArray(json)
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(
                            TransferHistoryRecord(
                                id = o.getString("id"),
                                fileName = o.getString("file"),
                                sizeBytes = o.getLong("size"),
                                targetName = o.getString("target"),
                                timestampMs = o.getLong("ts"),
                                succeeded = o.getBoolean("ok"),
                                note = o.optString("note", "")
                            )
                        )
                    }
                }
            }.getOrDefault(emptyList())
        }
    }
}
