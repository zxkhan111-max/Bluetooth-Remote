package com.example.connectivity

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.example.model.BluetoothHidSupportStatus
import com.example.model.ConnectedDeviceInfo
import com.example.model.ConnectionState
import com.example.model.DiscoveredBluetoothDevice
import com.example.model.HidProfileAvailability
import com.example.model.HidProfileStatus
import com.example.model.RemoteCommand
import com.example.model.RemoteError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Bound client connector bridging [BluetoothHidDeviceService] to the ViewModel layer
 * via the [BluetoothHidService] contract.
 */
class BluetoothRemoteManager(private val context: Context) : BluetoothHidService {

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var bridgeJob: Job? = null

    private var boundService: BluetoothHidDeviceService? = null
    private var isBound = false
    private val pendingActions = mutableListOf<(BluetoothHidDeviceService) -> Unit>()

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _connectedDevice = MutableStateFlow<ConnectedDeviceInfo?>(null)
    override val connectedDevice: StateFlow<ConnectedDeviceInfo?> = _connectedDevice.asStateFlow()

    private val _bondedDevices = MutableStateFlow<List<DiscoveredBluetoothDevice>>(emptyList())
    override val bondedDevices: StateFlow<List<DiscoveredBluetoothDevice>> = _bondedDevices.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredBluetoothDevice>>(emptyList())
    override val discoveredDevices: StateFlow<List<DiscoveredBluetoothDevice>> = _discoveredDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    override val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _hidSupportStatus = MutableStateFlow(evaluateSupportStatus())
    override val hidSupportStatus: StateFlow<BluetoothHidSupportStatus> = _hidSupportStatus.asStateFlow()

    private val _hidProfileStatus = MutableStateFlow(initialProfileStatus())
    override val hidProfileStatus: StateFlow<HidProfileStatus> = _hidProfileStatus.asStateFlow()

    private val _lastError = MutableStateFlow<RemoteError?>(null)
    override val lastError: StateFlow<RemoteError?> = _lastError.asStateFlow()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val localBinder = service as? BluetoothHidDeviceService.LocalBinder ?: return
            val hidService = localBinder.getService()
            boundService = hidService
            observeBoundService(hidService)

            val queued = synchronized(pendingActions) {
                val copy = pendingActions.toList()
                pendingActions.clear()
                copy
            }
            queued.forEach { action -> action(hidService) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bridgeJob?.cancel()
            bridgeJob = null
            boundService = null
            _connectedDevice.value = null
            _connectionState.value = ConnectionState.DISCONNECTED
            _hidProfileStatus.value = initialProfileStatus()
        }
    }

    init {
        bindToHidService()
    }

    private fun bindToHidService() {
        if (isBound) return
        val intent = Intent(context, BluetoothHidDeviceService::class.java)
        isBound = runCatching {
            context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }.getOrDefault(false)
    }

    private fun observeBoundService(service: BluetoothHidDeviceService) {
        bridgeJob?.cancel()
        bridgeJob = scope.launch {
            launch { service.connectionState.collect { _connectionState.value = it } }
            launch { service.connectedDevice.collect { _connectedDevice.value = it } }
            launch { service.bondedDevices.collect { _bondedDevices.value = it } }
            launch { service.discoveredDevices.collect { _discoveredDevices.value = it } }
            launch { service.isScanning.collect { _isScanning.value = it } }
            launch { service.hidSupportStatus.collect { _hidSupportStatus.value = it } }
            launch { service.hidProfileStatus.collect { _hidProfileStatus.value = it } }
            launch { service.lastError.collect { _lastError.value = it } }
        }
    }

    private inline fun withBoundOrEnqueue(crossinline block: (BluetoothHidDeviceService) -> Unit) {
        val current = boundService
        if (current != null) {
            block(current)
        } else {
            bindToHidService()
            synchronized(pendingActions) {
                pendingActions.add { svc -> block(svc) }
            }
        }
    }

    override fun requiredPermissionsForCurrentSdk(): List<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            listOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
    }

    override fun missingPermissions(): List<String> {
        return requiredPermissionsForCurrentSdk().filter { perm ->
            ContextCompat.checkSelfPermission(context, perm) != PackageManager.PERMISSION_GRANTED
        }
    }

    private fun evaluateSupportStatus(): BluetoothHidSupportStatus {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION
        }
        val btAdapter = adapter ?: return BluetoothHidSupportStatus.ADAPTER_UNAVAILABLE
        if (!btAdapter.isEnabled) {
            return BluetoothHidSupportStatus.BLUETOOTH_DISABLED
        }
        return BluetoothHidSupportStatus.SUPPORTED
    }

    private fun initialProfileStatus(): HidProfileStatus {
        val avail = when (evaluateSupportStatus()) {
            BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION -> HidProfileAvailability.UNSUPPORTED_ANDROID_VERSION
            BluetoothHidSupportStatus.ADAPTER_UNAVAILABLE -> HidProfileAvailability.ADAPTER_UNAVAILABLE
            BluetoothHidSupportStatus.BLUETOOTH_DISABLED -> HidProfileAvailability.BLUETOOTH_DISABLED
            BluetoothHidSupportStatus.PROFILE_PROXY_UNAVAILABLE -> HidProfileAvailability.DISCONNECTED_PROXY
            BluetoothHidSupportStatus.SUPPORTED -> HidProfileAvailability.DISCONNECTED_PROXY
        }
        return HidProfileStatus(availability = avail)
    }

    override fun refreshBondedDevices() {
        withBoundOrEnqueue { it.refreshBondedDevices() }
    }

    override fun initializeHidProfile(): RemoteError? {
        val current = boundService
        if (current != null) {
            return current.initializeHidProfile()
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return RemoteError.BluetoothHidUnsupportedAndroid8
        }
        val missing = missingPermissions()
        if (missing.isNotEmpty()) {
            return RemoteError.PermissionRequired(missing)
        }
        val btAdapter = adapter ?: return RemoteError.BluetoothUnavailable
        if (!btAdapter.isEnabled) return RemoteError.BluetoothDisabled

        withBoundOrEnqueue { it.initializeHidProfile() }
        return null
    }

    override fun unregisterHidProfile() {
        synchronized(pendingActions) { pendingActions.clear() }
        boundService?.unregisterHidProfile()
    }

    override fun startDiscovery(): RemoteError? {
        val current = boundService
        if (current != null) {
            return current.startDiscovery()
        }
        val missing = missingPermissions()
        if (missing.isNotEmpty()) return RemoteError.PermissionRequired(missing)
        val btAdapter = adapter ?: return RemoteError.BluetoothUnavailable
        if (!btAdapter.isEnabled) return RemoteError.BluetoothDisabled
        withBoundOrEnqueue { it.startDiscovery() }
        return null
    }

    override fun stopDiscovery() {
        boundService?.stopDiscovery()
    }

    override fun connectOrPair(address: String) {
        val current = boundService
        if (current != null) {
            current.connectOrPair(address)
            return
        }
        val missing = missingPermissions()
        if (missing.isNotEmpty()) {
            _lastError.value = RemoteError.PermissionRequired(missing)
            _connectionState.value = ConnectionState.ERROR
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            _lastError.value = RemoteError.BluetoothHidUnsupportedAndroid8
            _connectionState.value = ConnectionState.ERROR
            return
        }
        _connectionState.value = ConnectionState.CONNECTING
        withBoundOrEnqueue { it.connectOrPair(address) }
    }

    override fun disconnect() {
        boundService?.disconnect()
    }

    override fun sendCommand(command: RemoteCommand): RemoteError? =
        boundService?.sendCommand(command) ?: RemoteError.NotConnected

    override fun sendText(text: String): RemoteError? =
        boundService?.sendText(text) ?: RemoteError.NotConnected

    override fun sendKeyboardStroke(modifier: Byte, keyCode: Byte): RemoteError? =
        boundService?.sendKeyboardStroke(modifier, keyCode) ?: RemoteError.NotConnected

    override fun sendKeyboardKeyDown(modifier: Byte, keyCode: Byte): RemoteError? =
        boundService?.sendKeyboardKeyDown(modifier, keyCode) ?: RemoteError.NotConnected

    override fun sendKeyboardRelease(): RemoteError? =
        boundService?.sendKeyboardRelease() ?: RemoteError.NotConnected

    override fun sendMouseReport(
        buttonsBitmask: Int,
        deltaX: Int,
        deltaY: Int,
        scrollWheel: Int
    ): RemoteError? =
        boundService?.sendMouseReport(buttonsBitmask, deltaX, deltaY, scrollWheel) ?: RemoteError.NotConnected

    override fun sendMouseMove(deltaX: Int, deltaY: Int, buttonsBitmask: Int): RemoteError? =
        boundService?.sendMouseMove(deltaX, deltaY, buttonsBitmask) ?: RemoteError.NotConnected

    override fun sendMouseClick(buttonsBitmask: Int, releaseAfter: Boolean): RemoteError? =
        boundService?.sendMouseClick(buttonsBitmask, releaseAfter) ?: RemoteError.NotConnected

    override fun sendMouseScroll(wheelDelta: Int, buttonsBitmask: Int): RemoteError? =
        boundService?.sendMouseScroll(wheelDelta, buttonsBitmask) ?: RemoteError.NotConnected

    override fun release() {
        synchronized(pendingActions) { pendingActions.clear() }
        boundService?.unregisterHidProfile()
        bridgeJob?.cancel()
        bridgeJob = null
        if (isBound) {
            runCatching { context.unbindService(serviceConnection) }
            isBound = false
        }
        boundService = null
        scope.cancel()
    }
}
