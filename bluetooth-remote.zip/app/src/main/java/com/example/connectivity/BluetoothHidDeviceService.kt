package com.example.connectivity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.annotation.RequiresApi
import androidx.annotation.VisibleForTesting
import androidx.core.content.ContextCompat
import com.example.model.BluetoothHidSupportStatus
import com.example.model.ConnectedDeviceInfo
import com.example.model.ConnectionMode
import com.example.model.ConnectionState
import com.example.model.DeviceCapabilities
import com.example.model.DiscoveredBluetoothDevice
import com.example.model.HidProfileAvailability
import com.example.model.HidProfileStatus
import com.example.model.HidProtocolMode
import com.example.model.RemoteCommand
import com.example.model.RemoteError
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Android [Service] managing [BluetoothHidDevice] host registration, SDP/QoS configuration,
 * Bluetooth state transitions, and [BluetoothHidDevice.Callback] connection callbacks for
 * HID Keyboard (Report ID 1), Consumer Control (Report ID 2), and Relative Mouse (Report ID 3).
 */
class BluetoothHidDeviceService : Service(), BluetoothHidService {

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothHidDeviceService = this@BluetoothHidDeviceService
    }

    private val binder = LocalBinder()

    private var bluetoothManager: BluetoothManager? = null
    private var adapter: BluetoothAdapter? = null
    private var callbackExecutor: ExecutorService? = null

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _connectedDevice = MutableStateFlow<ConnectedDeviceInfo?>(null)
    override val connectedDevice: StateFlow<ConnectedDeviceInfo?> = _connectedDevice.asStateFlow()

    private val _bondedDevices = MutableStateFlow<List<DiscoveredBluetoothDevice>>(emptyList())
    override val bondedDevices: StateFlow<List<DiscoveredBluetoothDevice>> = _bondedDevices.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredBluetoothDevice>>(emptyList())
    override val discoveredDevices: StateFlow<List<DiscoveredBluetoothDevice>> = _discoveredDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    override val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _hidSupportStatus = MutableStateFlow(BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION)
    override val hidSupportStatus: StateFlow<BluetoothHidSupportStatus> = _hidSupportStatus.asStateFlow()

    private val _hidProfileStatus = MutableStateFlow(HidProfileStatus())
    override val hidProfileStatus: StateFlow<HidProfileStatus> = _hidProfileStatus.asStateFlow()

    private val _lastError = MutableStateFlow<RemoteError?>(null)
    override val lastError: StateFlow<RemoteError?> = _lastError.asStateFlow()

    private val lock = Any()
    private val pendingReadyCallbacks = mutableListOf<(Boolean) -> Unit>()
    private var isProxyRequestInFlight = false

    private var hidDeviceProxy: BluetoothHidDevice? = null
    private var activeBtDevice: BluetoothDevice? = null
    private var isHidRegistered = false
    private var pendingTargetDevice: BluetoothDevice? = null
    private var receiverRegistered = false

    private val discoveryReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE)
                        .takeIf { it != Short.MIN_VALUE }?.toInt()
                    device?.let { dev ->
                        if (!hasConnectPermission()) return
                        val entry = dev.toDiscoveredModel(rssi)
                        val updated = _discoveredDevices.value.filterNot { it.address == entry.address } + entry
                        _discoveredDevices.value = updated.sortedByDescending { it.isLikelyTvOrMedia }
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    _isScanning.value = true
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _isScanning.value = false
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    refreshBondedDevices()
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val bondState = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE)
                    if (bondState == BluetoothDevice.BOND_BONDED && device != null &&
                        pendingTargetDevice?.address == device.address
                    ) {
                        connectToBondedDevice(device)
                    }
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    _hidSupportStatus.value = evaluateSupportStatus()
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    if (state == BluetoothAdapter.STATE_OFF) {
                        isHidRegistered = false
                        hidDeviceProxy = null
                        clearConnectedSession(RemoteError.BluetoothDisabled)
                        _hidProfileStatus.value = HidProfileStatus(
                            availability = HidProfileAvailability.BLUETOOTH_DISABLED,
                            lastStatusDetail = "Bluetooth adapter turned off"
                        )
                    } else if (state == BluetoothAdapter.STATE_ON) {
                        _hidProfileStatus.value = initialProfileStatus()
                    }
                }
            }
        }
    }

    private val profileListener = object : BluetoothProfile.ServiceListener {
        @SuppressLint("MissingPermission")
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
            val hid = proxy as? BluetoothHidDevice
            if (hid == null) {
                _hidProfileStatus.value = HidProfileStatus(
                    availability = HidProfileAvailability.DISCONNECTED_PROXY,
                    lastStatusDetail = "HID proxy cast failed"
                )
                dispatchReadyCallbacks(false)
                return
            }
            registerHostWithProxy(hid)
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            isHidRegistered = false
            hidDeviceProxy = null
            clearConnectedSession(null)
            _hidProfileStatus.value = initialProfileStatus().copy(
                lastStatusDetail = "HID profile proxy disconnected"
            )
            dispatchReadyCallbacks(false)
        }
    }

    @VisibleForTesting
    internal val hidCallback: BluetoothHidDevice.Callback =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            createHidCallback()
        } else {
            throw UnsupportedOperationException("BluetoothHidDevice requires Android 9 (API 28)+")
        }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun createHidCallback(): BluetoothHidDevice.Callback = object : BluetoothHidDevice.Callback() {
        @SuppressLint("MissingPermission")
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            handleAppStatusChanged(pluggedDevice, registered)
        }

        @SuppressLint("MissingPermission")
        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            handleConnectionStateChanged(device, state)
        }

        @SuppressLint("MissingPermission")
        override fun onGetReport(
            device: BluetoothDevice?,
            type: Byte,
            id: Byte,
            bufferSize: Int
        ) {
            handleGetReport(device, type, id, bufferSize)
        }

        override fun onSetProtocol(device: BluetoothDevice?, protocol: Byte) {
            handleSetProtocol(protocol)
        }

        override fun onSetReport(
            device: BluetoothDevice?,
            type: Byte,
            id: Byte,
            data: ByteArray?
        ) {
            handleSetReport(type, id, data)
        }

        override fun onInterruptData(device: BluetoothDevice?, reportId: Byte, data: ByteArray?) {
            handleInterruptData(reportId, data)
        }

        override fun onVirtualCableUnplug(device: BluetoothDevice?) {
            handleVirtualCableUnplug()
        }
    }

    override fun onCreate() {
        super.onCreate()
        bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        adapter = bluetoothManager?.adapter
        callbackExecutor = Executors.newSingleThreadExecutor()
        _hidSupportStatus.value = evaluateSupportStatus()
        _hidProfileStatus.value = initialProfileStatus()
        registerReceivers()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        release()
        super.onDestroy()
    }

    override fun requiredPermissionsForCurrentSdk(): List<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            listOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
    }

    override fun missingPermissions(): List<String> {
        return requiredPermissionsForCurrentSdk().filter { perm ->
            ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasScanPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasConnectPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun evaluateSupportStatus(): BluetoothHidSupportStatus {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION
        }
        val btAdapter = adapter ?: return BluetoothHidSupportStatus.ADAPTER_UNAVAILABLE
        if (!btAdapter.isEnabled) {
            return BluetoothHidSupportStatus.BLUETOOTH_DISABLED
        }
        return BluetoothHidSupportStatus.SUPPORTED
    }

    private fun initialProfileStatus(): HidProfileStatus {
        val avail = when (evaluateSupportStatus()) {
            BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION -> HidProfileAvailability.UNSUPPORTED_ANDROID_VERSION
            BluetoothHidSupportStatus.ADAPTER_UNAVAILABLE -> HidProfileAvailability.ADAPTER_UNAVAILABLE
            BluetoothHidSupportStatus.BLUETOOTH_DISABLED -> HidProfileAvailability.BLUETOOTH_DISABLED
            BluetoothHidSupportStatus.PROFILE_PROXY_UNAVAILABLE -> HidProfileAvailability.DISCONNECTED_PROXY
            BluetoothHidSupportStatus.SUPPORTED -> HidProfileAvailability.DISCONNECTED_PROXY
        }
        return HidProfileStatus(availability = avail)
    }

    @SuppressLint("MissingPermission")
    override fun refreshBondedDevices() {
        _hidSupportStatus.value = evaluateSupportStatus()
        if (adapter == null || !hasConnectPermission()) return
        val bonded = adapter?.bondedDevices.orEmpty()
            .map { it.toDiscoveredModel() }
            .sortedByDescending { it.isLikelyTvOrMedia }
        _bondedDevices.value = bonded
    }

    override fun initializeHidProfile(): RemoteError? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            _hidSupportStatus.value = BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION
            _hidProfileStatus.value = HidProfileStatus(
                availability = HidProfileAvailability.UNSUPPORTED_ANDROID_VERSION,
                lastStatusDetail = "Requires Android 9 (API 28+)"
            )
            return RemoteError.BluetoothHidUnsupportedAndroid8
        }
        val missing = missingPermissions()
        if (missing.isNotEmpty()) {
            return RemoteError.PermissionRequired(missing)
        }
        val btAdapter = adapter ?: run {
            _hidSupportStatus.value = BluetoothHidSupportStatus.ADAPTER_UNAVAILABLE
            _hidProfileStatus.value = HidProfileStatus(
                availability = HidProfileAvailability.ADAPTER_UNAVAILABLE,
                lastStatusDetail = "Bluetooth adapter unavailable"
            )
            return RemoteError.BluetoothUnavailable
        }
        if (!btAdapter.isEnabled) {
            _hidSupportStatus.value = BluetoothHidSupportStatus.BLUETOOTH_DISABLED
            _hidProfileStatus.value = HidProfileStatus(
                availability = HidProfileAvailability.BLUETOOTH_DISABLED,
                lastStatusDetail = "Bluetooth is turned off"
            )
            return RemoteError.BluetoothDisabled
        }

        ensureHidProfileRegistered { registered ->
            _hidSupportStatus.value = if (registered) {
                BluetoothHidSupportStatus.SUPPORTED
            } else {
                BluetoothHidSupportStatus.PROFILE_PROXY_UNAVAILABLE
            }
        }
        return null
    }

    @SuppressLint("MissingPermission")
    override fun unregisterHidProfile() {
        disconnect()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && hasConnectPermission()) {
            runCatching {
                if (isHidRegistered) hidDeviceProxy?.unregisterApp()
                hidDeviceProxy?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) }
            }
        }
        isHidRegistered = false
        hidDeviceProxy = null
        synchronized(lock) {
            isProxyRequestInFlight = false
            pendingReadyCallbacks.clear()
        }
        _hidProfileStatus.value = initialProfileStatus().copy(
            lastStatusDetail = "HID profile unregistered"
        )
    }

    @SuppressLint("MissingPermission")
    override fun startDiscovery(): RemoteError? {
        val missing = missingPermissions()
        if (missing.isNotEmpty()) {
            val err = RemoteError.PermissionRequired(missing)
            _lastError.value = err
            return err
        }
        val btAdapter = adapter ?: run {
            _lastError.value = RemoteError.BluetoothUnavailable
            return RemoteError.BluetoothUnavailable
        }
        if (!btAdapter.isEnabled) {
            _lastError.value = RemoteError.BluetoothDisabled
            return RemoteError.BluetoothDisabled
        }

        _lastError.value = null
        refreshBondedDevices()
        if (btAdapter.isDiscovering) {
            btAdapter.cancelDiscovery()
        }
        val started = btAdapter.startDiscovery()
        if (!started) {
            val err = RemoteError.BluetoothConnectionFailed("System rejected Bluetooth discovery start")
            _lastError.value = err
            return err
        }
        _isScanning.value = true
        return null
    }

    @SuppressLint("MissingPermission")
    override fun stopDiscovery() {
        if (hasScanPermission() && adapter?.isDiscovering == true) {
            adapter?.cancelDiscovery()
        }
        _isScanning.value = false
    }

    @SuppressLint("MissingPermission")
    override fun connectOrPair(address: String) {
        val missing = missingPermissions()
        if (missing.isNotEmpty()) {
            _lastError.value = RemoteError.PermissionRequired(missing)
            _connectionState.value = ConnectionState.ERROR
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            _hidSupportStatus.value = BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION
            _hidProfileStatus.value = HidProfileStatus(
                availability = HidProfileAvailability.UNSUPPORTED_ANDROID_VERSION,
                lastStatusDetail = "Requires Android 9 (API 28+)"
            )
            _lastError.value = RemoteError.BluetoothHidUnsupportedAndroid8
            _connectionState.value = ConnectionState.ERROR
            return
        }
        val btAdapter = adapter ?: run {
            _lastError.value = RemoteError.BluetoothUnavailable
            _connectionState.value = ConnectionState.ERROR
            return
        }
        if (!btAdapter.isEnabled) {
            _lastError.value = RemoteError.BluetoothDisabled
            _connectionState.value = ConnectionState.ERROR
            return
        }

        stopDiscovery()
        val device = runCatching { btAdapter.getRemoteDevice(address) }.getOrNull()
        if (device == null) {
            _lastError.value = RemoteError.BluetoothConnectionFailed("Invalid Bluetooth MAC: $address")
            _connectionState.value = ConnectionState.ERROR
            return
        }

        _lastError.value = null
        if (device.bondState != BluetoothDevice.BOND_BONDED) {
            pendingTargetDevice = device
            _connectionState.value = ConnectionState.PAIRING_REQUIRED
            val bondInitiated = device.createBond()
            if (!bondInitiated) {
                _lastError.value = RemoteError.BluetoothPairingRequired
                _connectionState.value = ConnectionState.ERROR
            }
            return
        }

        connectToBondedDevice(device)
    }

    @SuppressLint("MissingPermission")
    private fun connectToBondedDevice(device: BluetoothDevice) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            _lastError.value = RemoteError.BluetoothHidUnsupportedAndroid8
            _connectionState.value = ConnectionState.ERROR
            return
        }
        pendingTargetDevice = device
        _connectionState.value = ConnectionState.CONNECTING
        ensureHidProfileRegistered { success ->
            if (!success) {
                _hidSupportStatus.value = BluetoothHidSupportStatus.PROFILE_PROXY_UNAVAILABLE
                _lastError.value = RemoteError.BluetoothHidProfileRejected
                _connectionState.value = ConnectionState.ERROR
                return@ensureHidProfileRegistered
            }
            val proxy = hidDeviceProxy
            if (proxy == null) {
                _lastError.value = RemoteError.BluetoothHidProfileRejected
                _connectionState.value = ConnectionState.ERROR
                return@ensureHidProfileRegistered
            }
            val initiated = runCatching { proxy.connect(device) }.getOrDefault(false)
            if (!initiated) {
                _lastError.value = RemoteError.BluetoothConnectionFailed(
                    "HID host refused or does not support Bluetooth HID Device connections."
                )
                _connectionState.value = ConnectionState.ERROR
            }
        }
    }

    private fun dispatchReadyCallbacks(success: Boolean) {
        val callbacks = synchronized(lock) {
            isProxyRequestInFlight = false
            val copy = pendingReadyCallbacks.toList()
            pendingReadyCallbacks.clear()
            copy
        }
        callbacks.forEach { it(success) }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    @SuppressLint("MissingPermission")
    private fun ensureHidProfileRegistered(onReady: (Boolean) -> Unit) {
        val btAdapter = adapter ?: return onReady(false)
        val existingProxy = hidDeviceProxy
        if (existingProxy != null && isHidRegistered) {
            onReady(true)
            return
        }

        synchronized(lock) {
            pendingReadyCallbacks.add(onReady)
            if (isProxyRequestInFlight) return
            isProxyRequestInFlight = true
        }

        val proxyRequested = btAdapter.getProfileProxy(this, profileListener, BluetoothProfile.HID_DEVICE)
        if (!proxyRequested) {
            dispatchReadyCallbacks(false)
        }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    @SuppressLint("MissingPermission")
    private fun registerHostWithProxy(hid: BluetoothHidDevice) {
        hidDeviceProxy = hid
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            availability = HidProfileAvailability.PROXY_BOUND,
            isProxyConnected = true,
            lastStatusDetail = "HID service proxy bound"
        )

        val sdp = BluetoothHidDeviceAppSdpSettings(
            "Bluetooth Remote",
            "Smart TV HID Keyboard & Mouse",
            "Bluetooth Remote",
            BluetoothHidDevice.SUBCLASS1_COMBO,
            HidReportDescriptor.DESCRIPTOR
        )

        val qos = BluetoothHidDeviceAppQosSettings(
            BluetoothHidDeviceAppQosSettings.SERVICE_BEST_EFFORT,
            800,
            9,
            0,
            11250,
            BluetoothHidDeviceAppQosSettings.MAX
        )

        val executor = callbackExecutor ?: Executors.newSingleThreadExecutor().also { callbackExecutor = it }
        val regOk = runCatching {
            hid.registerApp(sdp, qos, qos, executor, hidCallback)
        }.getOrDefault(false)

        if (!regOk) {
            _hidProfileStatus.value = _hidProfileStatus.value.copy(
                isAppRegistered = false,
                keyboardProfileActive = false,
                mouseProfileActive = false,
                consumerProfileActive = false,
                lastStatusDetail = "registerApp() rejected by Bluetooth stack"
            )
            dispatchReadyCallbacks(false)
        }
    }

    @VisibleForTesting
    @SuppressLint("MissingPermission")
    internal fun handleAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
        isHidRegistered = registered
        val devName = pluggedDevice?.let {
            runCatching { it.name }.getOrNull()?.takeIf { n -> n.isNotBlank() } ?: it.address
        }
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            availability = when {
                registered && pluggedDevice != null -> HidProfileAvailability.HOST_CONNECTED
                registered -> HidProfileAvailability.APP_REGISTERED
                else -> HidProfileAvailability.PROXY_BOUND
            },
            isProxyConnected = hidDeviceProxy != null,
            isAppRegistered = registered,
            keyboardProfileActive = registered,
            mouseProfileActive = registered,
            consumerProfileActive = registered,
            hostDeviceName = if (registered) devName else null,
            hostDeviceAddress = if (registered) pluggedDevice?.address else null,
            lastStatusDetail = if (registered) {
                "SDP Keyboard + Mouse + Consumer profiles active"
            } else {
                "HID SDP registration cleared"
            }
        )
        if (registered && pluggedDevice != null) {
            promoteDeviceToConnected(pluggedDevice)
        } else if (!registered) {
            clearConnectedSession(null)
        }
        dispatchReadyCallbacks(registered)
    }

    @VisibleForTesting
    @SuppressLint("MissingPermission")
    internal fun handleConnectionStateChanged(device: BluetoothDevice?, state: Int) {
        when (state) {
            BluetoothProfile.STATE_CONNECTED -> {
                if (device != null) {
                    promoteDeviceToConnected(device)
                }
            }
            BluetoothProfile.STATE_CONNECTING -> {
                _connectionState.value = ConnectionState.CONNECTING
                _hidProfileStatus.value = _hidProfileStatus.value.copy(
                    lastStatusDetail = "Connecting to ${device?.address ?: "HID host"}..."
                )
            }
            BluetoothProfile.STATE_DISCONNECTING -> {
                _hidProfileStatus.value = _hidProfileStatus.value.copy(
                    lastStatusDetail = "Disconnecting HID host..."
                )
            }
            BluetoothProfile.STATE_DISCONNECTED -> {
                if (_connectionState.value == ConnectionState.CONNECTING) {
                    _lastError.value = RemoteError.BluetoothConnectionFailed(
                        "Target device did not establish HID connection."
                    )
                    _connectionState.value = ConnectionState.ERROR
                    _hidProfileStatus.value = _hidProfileStatus.value.copy(
                        availability = if (isHidRegistered) HidProfileAvailability.APP_REGISTERED else HidProfileAvailability.PROXY_BOUND,
                        hostDeviceName = null,
                        hostDeviceAddress = null,
                        lastStatusDetail = "HID connection attempt failed"
                    )
                } else {
                    clearConnectedSession(null)
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    @SuppressLint("MissingPermission")
    internal fun handleGetReport(device: BluetoothDevice?, type: Byte, id: Byte, bufferSize: Int) {
        val proxyRef = hidDeviceProxy ?: return
        if (device == null) return
        when (id.toInt()) {
            HidReportDescriptor.REPORT_ID_KEYBOARD -> {
                proxyRef.replyReport(device, type, id, ByteArray(8))
            }
            HidReportDescriptor.REPORT_ID_CONSUMER -> {
                proxyRef.replyReport(device, type, id, ByteArray(2))
            }
            HidReportDescriptor.REPORT_ID_MOUSE -> {
                proxyRef.replyReport(device, type, id, ByteArray(4))
            }
            else -> {
                proxyRef.reportError(device, BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ)
            }
        }
    }

    @VisibleForTesting
    internal fun handleSetProtocol(protocol: Byte) {
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            protocol == BluetoothHidDevice.PROTOCOL_BOOT_MODE
        ) {
            HidProtocolMode.BOOT_PROTOCOL
        } else {
            HidProtocolMode.REPORT_PROTOCOL
        }
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            protocolMode = mode,
            lastStatusDetail = "Host selected ${mode.name}"
        )
    }

    @VisibleForTesting
    internal fun handleSetReport(type: Byte, id: Byte, data: ByteArray?) {
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            lastSetReportType = type.toInt(),
            lastStatusDetail = "Received host output/feature report ID=$id (${data?.size ?: 0}B)"
        )
    }

    @VisibleForTesting
    internal fun handleInterruptData(reportId: Byte, data: ByteArray?) {
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            lastStatusDetail = "Received interrupt report ID=$reportId (${data?.size ?: 0}B)"
        )
    }

    @VisibleForTesting
    internal fun handleVirtualCableUnplug() {
        clearConnectedSession(null)
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            lastStatusDetail = "Host unplugged virtual HID cable"
        )
    }

    @SuppressLint("MissingPermission")
    private fun promoteDeviceToConnected(device: BluetoothDevice) {
        activeBtDevice = device
        val devName = runCatching { device.name }.getOrNull()?.takeIf { it.isNotBlank() } ?: device.address ?: "Bluetooth TV"
        _connectedDevice.value = ConnectedDeviceInfo(
            id = device.address ?: "bt_hid",
            name = devName,
            mode = ConnectionMode.BLUETOOTH_HID,
            addressOrHost = device.address.orEmpty(),
            capabilities = DeviceCapabilities(
                supportsNavigation = true,
                supportsMediaKeys = true,
                supportsVolumeMute = true,
                supportsKeyboardText = true,
                supportsHidMouseAndAirMouse = true,
                supportsSwipeDpadFallback = true,
                supportsDeepLinkAppLaunch = false,
                supportsInstalledAppEnumeration = false,
                supportsDiscreteBrightnessKeys = true,
                supportsAbsoluteBrightnessSync = false,
                supportsTvScreenshotTrigger = true,
                supportsTvReceiverFileTransfer = false,
                supportsTvReceiverScreenRecording = false
            )
        )
        _connectionState.value = ConnectionState.CONNECTED
        _lastError.value = null
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            availability = HidProfileAvailability.HOST_CONNECTED,
            isProxyConnected = true,
            isAppRegistered = isHidRegistered,
            keyboardProfileActive = isHidRegistered,
            mouseProfileActive = isHidRegistered,
            consumerProfileActive = isHidRegistered,
            hostDeviceName = devName,
            hostDeviceAddress = device.address,
            lastStatusDetail = "Connected to $devName"
        )
    }

    @SuppressLint("MissingPermission")
    override fun sendCommand(command: RemoteCommand): RemoteError? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return RemoteError.BluetoothHidUnsupportedAndroid8
        if (!isHidRegistered) return RemoteError.BluetoothHidProfileRejected
        val proxy = hidDeviceProxy ?: return RemoteError.NotConnected
        val device = activeBtDevice ?: return RemoteError.NotConnected
        if (!hasConnectPermission()) return RemoteError.PermissionRequired(requiredPermissionsForCurrentSdk())

        val consumerUsage = command.hidConsumerUsage
        if (consumerUsage != null) {
            val low = (consumerUsage and 0xFF).toByte()
            val high = ((consumerUsage ushr 8) and 0xFF).toByte()
            val pressOk = proxy.sendReport(device, HidReportDescriptor.REPORT_ID_CONSUMER, byteArrayOf(low, high))
            val releaseOk = proxy.sendReport(device, HidReportDescriptor.REPORT_ID_CONSUMER, byteArrayOf(0x00, 0x00))
            if (!pressOk || !releaseOk) {
                return RemoteError.CommandFailed("Failed sending Bluetooth HID consumer key")
            }
            return null
        }

        val kbUsage = command.hidKeyboardUsage
        if (kbUsage != null) {
            val pressOk = sendKeyboardReport(proxy, device, 0x00, kbUsage)
            val releaseOk = sendKeyboardReport(proxy, device, 0x00, 0x00)
            if (!pressOk || !releaseOk) {
                return RemoteError.CommandFailed("Failed sending Bluetooth HID keyboard key")
            }
            return null
        }

        return RemoteError.UnsupportedFeature(command.name, "no_hid_mapping")
    }

    @SuppressLint("MissingPermission")
    override fun sendText(text: String): RemoteError? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return RemoteError.BluetoothHidUnsupportedAndroid8
        if (!isHidRegistered) return RemoteError.BluetoothHidProfileRejected
        val proxy = hidDeviceProxy ?: return RemoteError.NotConnected
        val device = activeBtDevice ?: return RemoteError.NotConnected
        if (!hasConnectPermission()) return RemoteError.PermissionRequired(requiredPermissionsForCurrentSdk())

        for (ch in text) {
            val stroke = HidReportDescriptor.charToHid(ch) ?: continue
            val downOk = sendKeyboardReport(proxy, device, stroke.modifier, stroke.usage)
            val upOk = sendKeyboardReport(proxy, device, 0x00, 0x00)
            if (!downOk || !upOk) {
                return RemoteError.CommandFailed("HID keyboard text transmission interrupted")
            }
        }
        return null
    }

    override fun sendKeyboardStroke(modifier: Byte, keyCode: Byte): RemoteError? {
        val downErr = sendKeyboardKeyDown(modifier, keyCode)
        if (downErr != null) return downErr
        return sendKeyboardRelease()
    }

    @SuppressLint("MissingPermission")
    override fun sendKeyboardKeyDown(modifier: Byte, keyCode: Byte): RemoteError? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return RemoteError.BluetoothHidUnsupportedAndroid8
        if (!isHidRegistered) return RemoteError.BluetoothHidProfileRejected
        val proxy = hidDeviceProxy ?: return RemoteError.NotConnected
        val device = activeBtDevice ?: return RemoteError.NotConnected
        if (!hasConnectPermission()) return RemoteError.PermissionRequired(requiredPermissionsForCurrentSdk())

        val ok = sendKeyboardReport(proxy, device, modifier, keyCode)
        return if (ok) null else RemoteError.CommandFailed("HID keyboard key-down failed")
    }

    @SuppressLint("MissingPermission")
    override fun sendKeyboardRelease(): RemoteError? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return RemoteError.BluetoothHidUnsupportedAndroid8
        if (!isHidRegistered) return RemoteError.BluetoothHidProfileRejected
        val proxy = hidDeviceProxy ?: return RemoteError.NotConnected
        val device = activeBtDevice ?: return RemoteError.NotConnected
        if (!hasConnectPermission()) return RemoteError.PermissionRequired(requiredPermissionsForCurrentSdk())

        val ok = sendKeyboardReport(proxy, device, 0x00, 0x00)
        return if (ok) null else RemoteError.CommandFailed("HID keyboard key-release failed")
    }

    @SuppressLint("MissingPermission")
    override fun sendMouseReport(buttonsBitmask: Int, deltaX: Int, deltaY: Int, scrollWheel: Int): RemoteError? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return RemoteError.BluetoothHidUnsupportedAndroid8
        if (!isHidRegistered) return RemoteError.BluetoothHidProfileRejected
        val proxy = hidDeviceProxy ?: return RemoteError.NotConnected
        val device = activeBtDevice ?: return RemoteError.NotConnected
        if (!hasConnectPermission()) return RemoteError.PermissionRequired(requiredPermissionsForCurrentSdk())

        val report = byteArrayOf(
            (buttonsBitmask and 0x07).toByte(),
            deltaX.coerceIn(-127, 127).toByte(),
            deltaY.coerceIn(-127, 127).toByte(),
            scrollWheel.coerceIn(-127, 127).toByte()
        )
        val sent = proxy.sendReport(device, HidReportDescriptor.REPORT_ID_MOUSE, report)
        return if (sent) null else RemoteError.CommandFailed("HID mouse report failed")
    }

    override fun sendMouseMove(deltaX: Int, deltaY: Int, buttonsBitmask: Int): RemoteError? {
        return sendMouseReport(buttonsBitmask = buttonsBitmask, deltaX = deltaX, deltaY = deltaY, scrollWheel = 0)
    }

    override fun sendMouseClick(buttonsBitmask: Int, releaseAfter: Boolean): RemoteError? {
        val pressErr = sendMouseReport(buttonsBitmask = buttonsBitmask, deltaX = 0, deltaY = 0, scrollWheel = 0)
        if (pressErr != null) return pressErr
        if (releaseAfter) {
            return sendMouseReport(buttonsBitmask = 0x00, deltaX = 0, deltaY = 0, scrollWheel = 0)
        }
        return null
    }

    override fun sendMouseScroll(wheelDelta: Int, buttonsBitmask: Int): RemoteError? {
        return sendMouseReport(buttonsBitmask = buttonsBitmask, deltaX = 0, deltaY = 0, scrollWheel = wheelDelta)
    }

    @RequiresApi(Build.VERSION_CODES.P)
    @SuppressLint("MissingPermission")
    private fun sendKeyboardReport(
        proxy: BluetoothHidDevice,
        device: BluetoothDevice,
        modifier: Byte,
        keyCode: Byte
    ): Boolean {
        val report = byteArrayOf(modifier, 0x00, keyCode, 0x00, 0x00, 0x00, 0x00, 0x00)
        return proxy.sendReport(device, HidReportDescriptor.REPORT_ID_KEYBOARD, report)
    }

    @SuppressLint("MissingPermission")
    override fun disconnect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && hasConnectPermission()) {
            val device = activeBtDevice
            if (device != null) {
                runCatching { hidDeviceProxy?.disconnect(device) }
            }
        }
        clearConnectedSession(null)
    }

    private fun clearConnectedSession(error: RemoteError?) {
        activeBtDevice = null
        _connectedDevice.value = null
        _lastError.value = error
        _connectionState.value = if (error != null) ConnectionState.ERROR else ConnectionState.DISCONNECTED
        _hidProfileStatus.value = _hidProfileStatus.value.copy(
            availability = when {
                error is RemoteError.BluetoothDisabled -> HidProfileAvailability.BLUETOOTH_DISABLED
                isHidRegistered -> HidProfileAvailability.APP_REGISTERED
                hidDeviceProxy != null -> HidProfileAvailability.PROXY_BOUND
                else -> initialProfileStatus().availability
            },
            hostDeviceName = null,
            hostDeviceAddress = null
        )
    }

    private fun registerReceivers() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(discoveryReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(discoveryReceiver, filter)
        }
        receiverRegistered = true
    }

    override fun release() {
        stopDiscovery()
        unregisterHidProfile()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(discoveryReceiver) }
            receiverRegistered = false
        }
        callbackExecutor?.shutdownNow()
        callbackExecutor = null
    }

    @SuppressLint("MissingPermission")
    private fun BluetoothDevice.toDiscoveredModel(rssi: Int? = null): DiscoveredBluetoothDevice {
        val majorClass = bluetoothClass?.majorDeviceClass ?: BluetoothClass.Device.Major.UNCATEGORIZED
        val isTvOrMedia = majorClass == BluetoothClass.Device.Major.AUDIO_VIDEO ||
            majorClass == BluetoothClass.Device.Major.COMPUTER ||
            majorClass == BluetoothClass.Device.Major.PERIPHERAL
        val safeName = runCatching { name }.getOrNull()?.takeIf { it.isNotBlank() } ?: "Device ($address)"
        return DiscoveredBluetoothDevice(
            address = address,
            name = safeName,
            bondState = bondState,
            majorDeviceClass = majorClass,
            isLikelyTvOrMedia = isTvOrMedia,
            rssi = rssi
        )
    }
}
