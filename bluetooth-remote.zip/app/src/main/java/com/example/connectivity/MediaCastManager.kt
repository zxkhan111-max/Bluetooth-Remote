package com.example.connectivity

import android.content.Context
import android.net.Uri
import android.net.wifi.WifiManager
import androidx.mediarouter.media.MediaControlIntent
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.example.model.CastDeviceSummary
import com.example.model.CastMediaSelection
import com.example.model.CastPlaybackState
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaStatus
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.Executors

class MediaCastManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _castDevices = MutableStateFlow<List<CastDeviceSummary>>(emptyList())
    val castDevices: StateFlow<List<CastDeviceSummary>> = _castDevices.asStateFlow()

    private val _connectedCastName = MutableStateFlow<String?>(null)
    val connectedCastName: StateFlow<String?> = _connectedCastName.asStateFlow()

    private val _playbackState = MutableStateFlow(CastPlaybackState.IDLE)
    val playbackState: StateFlow<CastPlaybackState> = _playbackState.asStateFlow()

    private val _castError = MutableStateFlow<String?>(null)
    val castError: StateFlow<String?> = _castError.asStateFlow()

    private val _castSdkAvailable = MutableStateFlow(false)
    val castSdkAvailable: StateFlow<Boolean> = _castSdkAvailable.asStateFlow()

    private var castContext: CastContext? = null
    private var mediaRouter: MediaRouter? = null
    private var routeSelector: MediaRouteSelector? = null

    // Local LAN HTTP media server for casting local ContentResolver URIs to Cast TVs
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var currentServedUri: Uri? = null
    private var currentServedMime: String = "image/jpeg"
    private var currentAuthToken: String = UUID.randomUUID().toString()

    private val routerCallback = object : MediaRouter.Callback() {
        override fun onRouteAdded(router: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes(router)
        override fun onRouteRemoved(router: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes(router)
        override fun onRouteChanged(router: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes(router)
    }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(session: CastSession) {
            _playbackState.value = CastPlaybackState.CONNECTING
        }

        override fun onSessionStarted(session: CastSession, sessionId: String) {
            _connectedCastName.value = session.castDevice?.friendlyName ?: "Cast TV"
            _castError.value = null
            _playbackState.value = CastPlaybackState.IDLE
            attachMediaCallback(session.remoteMediaClient)
        }

        override fun onSessionStartFailed(session: CastSession, error: Int) {
            _connectedCastName.value = null
            _playbackState.value = CastPlaybackState.ERROR
            _castError.value = "Cast session start failed (error $error)."
        }

        override fun onSessionEnding(session: CastSession) = Unit

        override fun onSessionEnded(session: CastSession, error: Int) {
            _connectedCastName.value = null
            _playbackState.value = CastPlaybackState.IDLE
            stopLocalMediaServer()
        }

        override fun onSessionResuming(session: CastSession, sessionId: String) {
            _playbackState.value = CastPlaybackState.CONNECTING
        }

        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            _connectedCastName.value = session.castDevice?.friendlyName ?: "Cast TV"
            attachMediaCallback(session.remoteMediaClient)
        }

        override fun onSessionResumeFailed(session: CastSession, error: Int) {
            _connectedCastName.value = null
            _playbackState.value = CastPlaybackState.IDLE
        }

        override fun onSessionSuspended(session: CastSession, reason: Int) = Unit
    }

    fun initialize() {
        runCatching {
            CastContext.getSharedInstance(context, Executors.newSingleThreadExecutor())
                .addOnSuccessListener { ctx ->
                    castContext = ctx
                    _castSdkAvailable.value = true
                    ctx.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
                    val active = ctx.sessionManager.currentCastSession
                    if (active?.isConnected == true) {
                        _connectedCastName.value = active.castDevice?.friendlyName ?: "Cast TV"
                        attachMediaCallback(active.remoteMediaClient)
                    }
                }
                .addOnFailureListener {
                    _castSdkAvailable.value = false
                }
        }.onFailure {
            _castSdkAvailable.value = false
        }
    }

    private fun ensureMediaRouterInitialized() {
        if (mediaRouter != null) return
        if (android.os.Build.FINGERPRINT.equals("robolectric", ignoreCase = true)) return
        val sysRouter = context.getSystemService(Context.MEDIA_ROUTER_SERVICE) ?: return
        runCatching {
            val router = MediaRouter.getInstance(context)
            mediaRouter = router
            val selector = MediaRouteSelector.Builder()
                .addControlCategory(CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
                .addControlCategory(MediaControlIntent.CATEGORY_REMOTE_PLAYBACK)
                .build()
            routeSelector = selector
            router.addCallback(selector, routerCallback, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
            refreshRoutes(router)
        }
    }

    fun refreshRoutes() {
        ensureMediaRouterInitialized()
        mediaRouter?.let { refreshRoutes(it) }
    }

    private fun refreshRoutes(router: MediaRouter) {
        val list = router.routes
            .filter { !it.isDefault && it.isEnabled }
            .map { route ->
                CastDeviceSummary(
                    id = route.id,
                    name = route.name,
                    description = route.description ?: "Media Route",
                    isCastProtocol = route.supportsControlCategory(
                        CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID)
                    )
                )
            }
        _castDevices.value = list
    }

    fun selectRoute(routeId: String) {
        val router = mediaRouter ?: return
        val route = router.routes.firstOrNull { it.id == routeId }
        if (route != null) {
            _playbackState.value = CastPlaybackState.CONNECTING
            _castError.value = null
            router.selectRoute(route)
        } else {
            _castError.value = "Selected Cast device is no longer available on this network."
        }
    }

    fun castMedia(selection: CastMediaSelection) {
        val session = castContext?.sessionManager?.currentCastSession
        val client = session?.remoteMediaClient
        if (session == null || !session.isConnected || client == null) {
            _castError.value = "Select and connect to a Google Cast receiver first."
            return
        }

        val localIp = getLocalIpv4Address()
        if (localIp == null) {
            _castError.value = "Local Wi-Fi IP unavailable. Connect to Wi-Fi to cast local files."
            return
        }

        val uri = Uri.parse(selection.uriString)
        val port = startLocalMediaServer(uri, selection.mimeType)
        if (port <= 0) {
            _castError.value = "Could not open local LAN stream port for casting."
            return
        }

        val streamUrl = "http://$localIp:$port/media/$currentAuthToken"
        val metadata = MediaMetadata(
            if (selection.isVideo) MediaMetadata.MEDIA_TYPE_MOVIE else MediaMetadata.MEDIA_TYPE_PHOTO
        ).apply {
            putString(MediaMetadata.KEY_TITLE, selection.displayName)
        }

        val mediaInfo = MediaInfo.Builder(streamUrl)
            .setStreamType(
                if (selection.isVideo) MediaInfo.STREAM_TYPE_BUFFERED else MediaInfo.STREAM_TYPE_NONE
            )
            .setContentType(selection.mimeType)
            .setMetadata(metadata)
            .build()

        _playbackState.value = CastPlaybackState.BUFFERING
        _castError.value = null
        client.load(MediaLoadRequestData.Builder().setMediaInfo(mediaInfo).setAutoplay(true).build())
    }

    fun togglePlayPause() {
        val client = castContext?.sessionManager?.currentCastSession?.remoteMediaClient ?: return
        if (client.isPlaying) client.pause() else client.play()
    }

    fun seekBy(deltaMs: Long) {
        val client = castContext?.sessionManager?.currentCastSession?.remoteMediaClient ?: return
        val target = (client.approximateStreamPosition + deltaMs).coerceAtLeast(0L)
        client.seek(target)
    }

    fun setCastVolume(volume: Double) {
        val session = castContext?.sessionManager?.currentCastSession ?: return
        runCatching { session.volume = volume.coerceIn(0.0, 1.0) }
    }

    fun stopCasting() {
        runCatching {
            castContext?.sessionManager?.endCurrentSession(true)
            mediaRouter?.unselect(MediaRouter.UNSELECT_REASON_STOPPED)
        }
        stopLocalMediaServer()
        _connectedCastName.value = null
        _playbackState.value = CastPlaybackState.IDLE
    }

    private fun attachMediaCallback(client: RemoteMediaClient?) {
        client ?: return
        client.registerCallback(object : RemoteMediaClient.Callback() {
            override fun onStatusUpdated() {
                val playerState = client.mediaStatus?.playerState
                _playbackState.value = when (playerState) {
                    MediaStatus.PLAYER_STATE_PLAYING -> CastPlaybackState.PLAYING
                    MediaStatus.PLAYER_STATE_PAUSED -> CastPlaybackState.PAUSED
                    MediaStatus.PLAYER_STATE_BUFFERING -> CastPlaybackState.BUFFERING
                    else -> CastPlaybackState.IDLE
                }
            }
        })
    }

    private fun startLocalMediaServer(uri: Uri, mimeType: String): Int {
        currentServedUri = uri
        currentServedMime = mimeType
        currentAuthToken = UUID.randomUUID().toString()
        val existing = serverSocket
        if (existing != null && !existing.isClosed) {
            return existing.localPort
        }

        return runCatching {
            val srv = ServerSocket(0)
            serverSocket = srv
            serverJob = scope.launch {
                while (isActive && !srv.isClosed) {
                    val client = runCatching { srv.accept() }.getOrNull() ?: break
                    launch { handleHttpClient(client) }
                }
            }
            srv.localPort
        }.getOrDefault(-1)
    }

    private fun handleHttpClient(socket: Socket) {
        socket.use { sock ->
            runCatching {
                val reader = BufferedReader(InputStreamReader(sock.getInputStream()))
                val requestLine = reader.readLine() ?: return
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                }
                val out = sock.getOutputStream()
                if (!requestLine.contains("/media/$currentAuthToken")) {
                    out.write("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n".toByteArray())
                    out.flush()
                    return
                }
                val uri = currentServedUri ?: return
                val bytesStream = context.contentResolver.openInputStream(uri) ?: return
                val size = runCatching {
                    context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                }.getOrDefault(-1L)

                val header = buildString {
                    append("HTTP/1.1 200 OK\r\n")
                    append("Content-Type: $currentServedMime\r\n")
                    if (size > 0) append("Content-Length: $size\r\n")
                    append("Connection: close\r\n\r\n")
                }
                out.write(header.toByteArray())
                BufferedInputStream(bytesStream).use { bis ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val read = bis.read(buf)
                        if (read <= 0) break
                        out.write(buf, 0, read)
                    }
                }
                out.flush()
            }
        }
    }

    private fun stopLocalMediaServer() {
        serverJob?.cancel()
        serverJob = null
        runCatching { serverSocket?.close() }
        serverSocket = null
    }

    private fun getLocalIpv4Address(): String? {
        runCatching {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            val ipInt = wm?.connectionInfo?.ipAddress ?: 0
            if (ipInt != 0) {
                return "%d.%d.%d.%d".format(
                    ipInt and 0xff,
                    ipInt shr 8 and 0xff,
                    ipInt shr 16 and 0xff,
                    ipInt shr 24 and 0xff
                )
            }
        }
        return runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList()?.flatMap { it.inetAddresses.toList() }
                ?.firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress
        }.getOrNull()
    }

    fun release() {
        stopLocalMediaServer()
        runCatching {
            mediaRouter?.removeCallback(routerCallback)
            castContext?.sessionManager?.removeSessionManagerListener(sessionListener, CastSession::class.java)
        }
    }
}
