package com.example.connectivity

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class FeedbackManager(private val context: Context) {

    private var toneGenerator: ToneGenerator? = null

    private fun getVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun triggerClickFeedback(hapticEnabled: Boolean, soundEnabled: Boolean, strong: Boolean = false) {
        if (hapticEnabled) {
            runCatching {
                val vibrator = getVibrator()
                if (vibrator?.hasVibrator() == true) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val effectId = if (strong) {
                            VibrationEffect.EFFECT_HEAVY_CLICK
                        } else {
                            VibrationEffect.EFFECT_CLICK
                        }
                        vibrator.vibrate(VibrationEffect.createPredefined(effectId))
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(
                            VibrationEffect.createOneShot(if (strong) 28L else 14L, VibrationEffect.DEFAULT_AMPLITUDE)
                        )
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(if (strong) 28L else 14L)
                    }
                }
            }
        }
        if (soundEnabled) {
            runCatching {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                am?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.5f)
            }.onFailure {
                runCatching {
                    if (toneGenerator == null) {
                        toneGenerator = ToneGenerator(AudioManager.STREAM_SYSTEM, 25)
                    }
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 18)
                }
            }
        }
    }

    fun release() {
        runCatching { toneGenerator?.release() }
        toneGenerator = null
    }
}
