package com.example.connectivity

/**
 * Standard USB/Bluetooth HID composite descriptor:
 * - Report ID 1: Keyboard (Modifier + Reserved + 6 keycodes)
 * - Report ID 2: Consumer Control (16-bit media/TV usage)
 * - Report ID 3: Relative Mouse (Buttons + X + Y + Wheel)
 */
object HidReportDescriptor {
    const val REPORT_ID_KEYBOARD = 1
    const val REPORT_ID_CONSUMER = 2
    const val REPORT_ID_MOUSE = 3

    val DESCRIPTOR: ByteArray = byteArrayOf(
        // Keyboard (Report ID 1)
        0x05.toByte(), 0x01.toByte(),       // Usage Page (Generic Desktop)
        0x09.toByte(), 0x06.toByte(),       // Usage (Keyboard)
        0xA1.toByte(), 0x01.toByte(),       // Collection (Application)
        0x85.toByte(), 0x01.toByte(),       //   Report ID (1)
        0x05.toByte(), 0x07.toByte(),       //   Usage Page (Key Codes)
        0x19.toByte(), 0xE0.toByte(),       //   Usage Minimum (224)
        0x29.toByte(), 0xE7.toByte(),       //   Usage Maximum (231)
        0x15.toByte(), 0x00.toByte(),       //   Logical Minimum (0)
        0x25.toByte(), 0x01.toByte(),       //   Logical Maximum (1)
        0x75.toByte(), 0x01.toByte(),       //   Report Size (1)
        0x95.toByte(), 0x08.toByte(),       //   Report Count (8)
        0x81.toByte(), 0x02.toByte(),       //   Input (Data, Variable, Absolute) - Modifier byte
        0x95.toByte(), 0x01.toByte(),       //   Report Count (1)
        0x75.toByte(), 0x08.toByte(),       //   Report Size (8)
        0x81.toByte(), 0x01.toByte(),       //   Input (Constant) - Reserved byte
        0x95.toByte(), 0x06.toByte(),       //   Report Count (6)
        0x75.toByte(), 0x08.toByte(),       //   Report Size (8)
        0x15.toByte(), 0x00.toByte(),       //   Logical Minimum (0)
        0x25.toByte(), 0x73.toByte(),       //   Logical Maximum (115)
        0x05.toByte(), 0x07.toByte(),       //   Usage Page (Key Codes)
        0x19.toByte(), 0x00.toByte(),       //   Usage Minimum (0)
        0x29.toByte(), 0x73.toByte(),       //   Usage Maximum (115)
        0x81.toByte(), 0x00.toByte(),       //   Input (Data, Array)
        0xC0.toByte(),                      // End Collection

        // Consumer Control (Report ID 2)
        0x05.toByte(), 0x0C.toByte(),       // Usage Page (Consumer)
        0x09.toByte(), 0x01.toByte(),       // Usage (Consumer Control)
        0xA1.toByte(), 0x01.toByte(),       // Collection (Application)
        0x85.toByte(), 0x02.toByte(),       //   Report ID (2)
        0x15.toByte(), 0x00.toByte(),       //   Logical Minimum (0)
        0x26.toByte(), 0xFF.toByte(), 0x03.toByte(), // Logical Maximum (0x03FF)
        0x19.toByte(), 0x00.toByte(),       //   Usage Minimum (0)
        0x2A.toByte(), 0xFF.toByte(), 0x03.toByte(), // Usage Maximum (0x03FF)
        0x75.toByte(), 0x10.toByte(),       //   Report Size (16)
        0x95.toByte(), 0x01.toByte(),       //   Report Count (1)
        0x81.toByte(), 0x00.toByte(),       //   Input (Data, Array)
        0xC0.toByte(),                      // End Collection

        // Relative Mouse (Report ID 3)
        0x05.toByte(), 0x01.toByte(),       // Usage Page (Generic Desktop)
        0x09.toByte(), 0x02.toByte(),       // Usage (Mouse)
        0xA1.toByte(), 0x01.toByte(),       // Collection (Application)
        0x85.toByte(), 0x03.toByte(),       //   Report ID (3)
        0x09.toByte(), 0x01.toByte(),       //   Usage (Pointer)
        0xA1.toByte(), 0x00.toByte(),       //   Collection (Physical)
        0x05.toByte(), 0x09.toByte(),       //     Usage Page (Buttons)
        0x19.toByte(), 0x01.toByte(),       //     Usage Minimum (1)
        0x29.toByte(), 0x03.toByte(),       //     Usage Maximum (3)
        0x15.toByte(), 0x00.toByte(),       //     Logical Minimum (0)
        0x25.toByte(), 0x01.toByte(),       //     Logical Maximum (1)
        0x95.toByte(), 0x03.toByte(),       //     Report Count (3)
        0x75.toByte(), 0x01.toByte(),       //     Report Size (1)
        0x81.toByte(), 0x02.toByte(),       //     Input (Data, Variable, Absolute)
        0x95.toByte(), 0x01.toByte(),       //     Report Count (1)
        0x75.toByte(), 0x05.toByte(),       //     Report Size (5)
        0x81.toByte(), 0x01.toByte(),       //     Input (Constant) - padding
        0x05.toByte(), 0x01.toByte(),       //     Usage Page (Generic Desktop)
        0x09.toByte(), 0x30.toByte(),       //     Usage (X)
        0x09.toByte(), 0x31.toByte(),       //     Usage (Y)
        0x09.toByte(), 0x38.toByte(),       //     Usage (Wheel)
        0x15.toByte(), 0x81.toByte(),       //     Logical Minimum (-127)
        0x25.toByte(), 0x7F.toByte(),       //     Logical Maximum (127)
        0x75.toByte(), 0x08.toByte(),       //     Report Size (8)
        0x95.toByte(), 0x03.toByte(),       //     Report Count (3)
        0x81.toByte(), 0x06.toByte(),       //     Input (Data, Variable, Relative)
        0xC0.toByte(),                      //   End Collection
        0xC0.toByte()                       // End Collection
    )

    private const val MOD_SHIFT: Byte = 0x02

    data class HidKeyStroke(val modifier: Byte, val usage: Byte)

    fun charToHid(ch: Char): HidKeyStroke? {
        return when (ch) {
            in 'a'..'z' -> HidKeyStroke(0, (0x04 + (ch - 'a')).toByte())
            in 'A'..'Z' -> HidKeyStroke(MOD_SHIFT, (0x04 + (ch - 'A')).toByte())
            '1' -> HidKeyStroke(0, 0x1E)
            '2' -> HidKeyStroke(0, 0x1F)
            '3' -> HidKeyStroke(0, 0x20)
            '4' -> HidKeyStroke(0, 0x21)
            '5' -> HidKeyStroke(0, 0x22)
            '6' -> HidKeyStroke(0, 0x23)
            '7' -> HidKeyStroke(0, 0x24)
            '8' -> HidKeyStroke(0, 0x25)
            '9' -> HidKeyStroke(0, 0x26)
            '0' -> HidKeyStroke(0, 0x27)
            '!' -> HidKeyStroke(MOD_SHIFT, 0x1E)
            '@' -> HidKeyStroke(MOD_SHIFT, 0x1F)
            '#' -> HidKeyStroke(MOD_SHIFT, 0x20)
            '$' -> HidKeyStroke(MOD_SHIFT, 0x21)
            '%' -> HidKeyStroke(MOD_SHIFT, 0x22)
            '^' -> HidKeyStroke(MOD_SHIFT, 0x23)
            '&' -> HidKeyStroke(MOD_SHIFT, 0x24)
            '*' -> HidKeyStroke(MOD_SHIFT, 0x25)
            '(' -> HidKeyStroke(MOD_SHIFT, 0x26)
            ')' -> HidKeyStroke(MOD_SHIFT, 0x27)
            '\n' -> HidKeyStroke(0, 0x28)
            '\b' -> HidKeyStroke(0, 0x2A)
            '\t' -> HidKeyStroke(0, 0x2B)
            ' ' -> HidKeyStroke(0, 0x2C)
            '-' -> HidKeyStroke(0, 0x2D)
            '_' -> HidKeyStroke(MOD_SHIFT, 0x2D)
            '=' -> HidKeyStroke(0, 0x2E)
            '+' -> HidKeyStroke(MOD_SHIFT, 0x2E)
            '[' -> HidKeyStroke(0, 0x2F)
            '{' -> HidKeyStroke(MOD_SHIFT, 0x2F)
            ']' -> HidKeyStroke(0, 0x30)
            '}' -> HidKeyStroke(MOD_SHIFT, 0x30)
            '\\' -> HidKeyStroke(0, 0x31)
            '|' -> HidKeyStroke(MOD_SHIFT, 0x31)
            ';' -> HidKeyStroke(0, 0x33)
            ':' -> HidKeyStroke(MOD_SHIFT, 0x33)
            '\'' -> HidKeyStroke(0, 0x34)
            '"' -> HidKeyStroke(MOD_SHIFT, 0x34)
            '`' -> HidKeyStroke(0, 0x35)
            '~' -> HidKeyStroke(MOD_SHIFT, 0x35)
            ',' -> HidKeyStroke(0, 0x36)
            '<' -> HidKeyStroke(MOD_SHIFT, 0x36)
            '.' -> HidKeyStroke(0, 0x37)
            '>' -> HidKeyStroke(MOD_SHIFT, 0x37)
            '/' -> HidKeyStroke(0, 0x38)
            '?' -> HidKeyStroke(MOD_SHIFT, 0x38)
            else -> null
        }
    }
}
