package com.example.connectivity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.example.model.SensorSamplingTier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.roundToInt

class AirMouseSensorController(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val gyroSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accelSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    val hasGyroscope: Boolean = gyroSensor != null
    val hasHardwareSensor: Boolean = gyroSensor != null || accelSensor != null

    private val _isEnabled = MutableStateFlow(false)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private var sensitivity: Float = 1.0f
    private var pointerSpeed: Float = 1.0f
    private var samplingTier: SensorSamplingTier = SensorSamplingTier.BALANCED

    private var biasX = 0f
    private var biasY = 0f
    private var biasZ = 0f
    private var calibrateNextSample = false

    private var onDeltaCallback: ((Int, Int) -> Unit)? = null

    fun start(
        sensitivity: Float,
        pointerSpeed: Float,
        samplingTier: SensorSamplingTier,
        onDelta: (dx: Int, dy: Int) -> Unit
    ): Boolean {
        val manager = sensorManager ?: return false
        val activeSensor = gyroSensor ?: accelSensor ?: return false

        this.sensitivity = sensitivity
        this.pointerSpeed = pointerSpeed
        this.samplingTier = samplingTier
        this.onDeltaCallback = onDelta

        val delay = when (samplingTier) {
            SensorSamplingTier.RESPONSIVE -> SensorManager.SENSOR_DELAY_GAME
            SensorSamplingTier.BALANCED -> SensorManager.SENSOR_DELAY_UI
            SensorSamplingTier.ECO_LOW_POWER -> SensorManager.SENSOR_DELAY_NORMAL
        }

        manager.unregisterListener(this)
        val ok = manager.registerListener(this, activeSensor, delay)
        _isEnabled.value = ok
        return ok
    }

    fun updateTuning(sensitivity: Float, pointerSpeed: Float, samplingTier: SensorSamplingTier) {
        val tierChanged = this.samplingTier != samplingTier
        this.sensitivity = sensitivity
        this.pointerSpeed = pointerSpeed
        this.samplingTier = samplingTier
        if (tierChanged && _isEnabled.value) {
            val cb = onDeltaCallback
            if (cb != null) {
                start(sensitivity, pointerSpeed, samplingTier, cb)
            }
        }
    }

    fun calibrateZero() {
        calibrateNextSample = true
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
        _isEnabled.value = false
        onDeltaCallback = null
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        if (!_isEnabled.value) return

        val rawX = event.values[0]
        val rawY = event.values[1]
        val rawZ = event.values[2]

        if (calibrateNextSample) {
            biasX = rawX
            biasY = rawY
            biasZ = rawZ
            calibrateNextSample = false
            return
        }

        val scale = sensitivity * pointerSpeed
        val (dxFloat, dyFloat) = if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            // Yaw (Z) drives horizontal pointer, Pitch (X) drives vertical pointer
            val yaw = -(rawZ - biasZ)
            val pitch = -(rawX - biasX)
            val deadzone = 0.03f
            val x = if (abs(yaw) > deadzone) yaw * 24f * scale else 0f
            val y = if (abs(pitch) > deadzone) pitch * 24f * scale else 0f
            x to y
        } else {
            // Accelerometer tilt fallback
            val tiltX = -(rawX - biasX)
            val tiltY = (rawY - biasY)
            val deadzone = 0.45f
            val x = if (abs(tiltX) > deadzone) tiltX * 3.5f * scale else 0f
            val y = if (abs(tiltY) > deadzone) tiltY * 3.5f * scale else 0f
            x to y
        }

        val dx = dxFloat.roundToInt().coerceIn(-127, 127)
        val dy = dyFloat.roundToInt().coerceIn(-127, 127)
        if (dx != 0 || dy != 0) {
            onDeltaCallback?.invoke(dx, dy)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
