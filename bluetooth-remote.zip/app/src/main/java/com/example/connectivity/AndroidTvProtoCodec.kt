package com.example.connectivity

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets

/**
 * Lightweight, dependency-free Protobuf wire-format encoder & parser
 * for Android TV Remote Protocol v2 (Pairing on 6467, Remote on 6466).
 */
object AndroidTvProtoCodec {

    private const val WIRE_VARINT = 0
    private const val WIRE_LENGTH_DELIMITED = 2

    private fun writeVarint(out: ByteArrayOutputStream, value: Int) {
        var v = value
        while ((v and 0x7F.inv()) != 0) {
            out.write((v and 0x7F) or 0x80)
            v = v ushr 7
        }
        out.write(v and 0x7F)
    }

    private fun writeVarintField(out: ByteArrayOutputStream, fieldNumber: Int, value: Int) {
        writeVarint(out, (fieldNumber shl 3) or WIRE_VARINT)
        writeVarint(out, value)
    }

    private fun writeBytesField(out: ByteArrayOutputStream, fieldNumber: Int, data: ByteArray) {
        writeVarint(out, (fieldNumber shl 3) or WIRE_LENGTH_DELIMITED)
        writeVarint(out, data.size)
        out.write(data)
    }

    private fun writeStringField(out: ByteArrayOutputStream, fieldNumber: Int, text: String) {
        writeBytesField(out, fieldNumber, text.toByteArray(StandardCharsets.UTF_8))
    }

    fun frameMessage(payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(payload.size + 4)
        writeVarint(out, payload.size)
        out.write(payload)
        return out.toByteArray()
    }

    fun readFramedMessage(input: InputStream): ByteArray? {
        var length = 0
        var shift = 0
        while (true) {
            val b = input.read()
            if (b == -1) return null
            length = length or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
            if (shift > 28) return null
        }
        if (length <= 0 || length > 1024 * 1024) return ByteArray(0)
        val buffer = ByteArray(length)
        var read = 0
        while (read < length) {
            val count = input.read(buffer, read, length - read)
            if (count == -1) return null
            read += count
        }
        return buffer
    }

    data class ProtoField(val number: Int, val wireType: Int, val varint: Long = 0L, val bytes: ByteArray = ByteArray(0))

    fun parseFields(data: ByteArray): List<ProtoField> {
        val fields = mutableListOf<ProtoField>()
        var idx = 0
        fun readVarint(): Long {
            var res = 0L
            var shift = 0
            while (idx < data.size) {
                val b = data[idx++].toInt() and 0xFF
                res = res or ((b.toLong() and 0x7FL) shl shift)
                if ((b and 0x80) == 0) break
                shift += 7
            }
            return res
        }

        while (idx < data.size) {
            val tag = readVarint().toInt()
            val number = tag ushr 3
            val wireType = tag and 0x07
            when (wireType) {
                WIRE_VARINT -> {
                    val v = readVarint()
                    fields.add(ProtoField(number, wireType, varint = v))
                }
                WIRE_LENGTH_DELIMITED -> {
                    val len = readVarint().toInt().coerceAtLeast(0)
                    val end = (idx + len).coerceAtMost(data.size)
                    val slice = data.copyOfRange(idx, end)
                    idx = end
                    fields.add(ProtoField(number, wireType, bytes = slice))
                }
                5 -> idx = (idx + 4).coerceAtMost(data.size)
                1 -> idx = (idx + 8).coerceAtMost(data.size)
                else -> break
            }
        }
        return fields
    }

    // --- Pairing Protocol Messages (Port 6467) ---

    fun buildPairingRequest(serviceName: String, clientName: String): ByteArray {
        val inner = ByteArrayOutputStream().apply {
            writeStringField(this, 1, serviceName)
            writeStringField(this, 2, clientName)
        }.toByteArray()

        return ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 2) // protocol_version = 2
            writeVarintField(this, 2, 200) // status = STATUS_OK
            writeBytesField(this, 10, inner) // pairing_request = field 10
        }.toByteArray()
    }

    fun buildPairingOption(): ByteArray {
        val encoding = ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 3) // ENCODING_TYPE_HEXADECIMAL = 3
            writeVarintField(this, 2, 6) // symbol_length = 6
        }.toByteArray()

        val inner = ByteArrayOutputStream().apply {
            writeBytesField(this, 1, encoding) // input_encodings
            writeVarintField(this, 3, 1) // preferred_role = ROLE_TYPE_INPUT (1)
        }.toByteArray()

        return ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 2)
            writeVarintField(this, 2, 200)
            writeBytesField(this, 20, inner) // pairing_option = field 20
        }.toByteArray()
    }

    fun buildPairingConfiguration(): ByteArray {
        val encoding = ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 3) // HEXADECIMAL
            writeVarintField(this, 2, 6) // 6 chars
        }.toByteArray()

        val inner = ByteArrayOutputStream().apply {
            writeBytesField(this, 1, encoding)
            writeVarintField(this, 2, 1) // ROLE_TYPE_INPUT
        }.toByteArray()

        return ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 2)
            writeVarintField(this, 2, 200)
            writeBytesField(this, 30, inner) // pairing_configuration = field 30
        }.toByteArray()
    }

    fun buildPairingSecret(secret: ByteArray): ByteArray {
        val inner = ByteArrayOutputStream().apply {
            writeBytesField(this, 1, secret)
        }.toByteArray()

        return ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 2)
            writeVarintField(this, 2, 200)
            writeBytesField(this, 40, inner) // pairing_secret = field 40
        }.toByteArray()
    }

    // --- Remote Control Protocol Messages (Port 6466) ---

    fun buildRemoteConfigure(model: String, vendor: String, appPackage: String): ByteArray {
        val deviceInfo = ByteArrayOutputStream().apply {
            writeStringField(this, 1, model)
            writeStringField(this, 2, vendor)
            writeVarintField(this, 3, 1)
            writeStringField(this, 4, "1")
            writeStringField(this, 5, appPackage)
            writeStringField(this, 6, "1.0")
        }.toByteArray()

        val configure = ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 622) // code1
            writeBytesField(this, 2, deviceInfo)
        }.toByteArray()

        return ByteArrayOutputStream().apply {
            writeBytesField(this, 1, configure) // remote_configure = field 1
        }.toByteArray()
    }

    fun buildRemoteSetActive(activeFeatures: Int = 622): ByteArray {
        val active = ByteArrayOutputStream().apply {
            writeVarintField(this, 1, activeFeatures)
        }.toByteArray()
        return ByteArrayOutputStream().apply {
            writeBytesField(this, 2, active) // remote_set_active = field 2
        }.toByteArray()
    }

    fun buildRemotePingResponse(val1: Int): ByteArray {
        val pingResp = ByteArrayOutputStream().apply {
            writeVarintField(this, 1, val1)
        }.toByteArray()
        return ByteArrayOutputStream().apply {
            writeBytesField(this, 9, pingResp) // remote_ping_response = field 9
        }.toByteArray()
    }

    fun buildRemoteKeyInject(keyCode: Int, direction: Int = 3): ByteArray {
        // direction: 1 = START_LONG, 2 = END_LONG, 3 = SHORT
        val keyInject = ByteArrayOutputStream().apply {
            writeVarintField(this, 1, keyCode)
            writeVarintField(this, 2, direction)
        }.toByteArray()
        return ByteArrayOutputStream().apply {
            writeBytesField(this, 10, keyInject) // remote_key_inject = field 10
        }.toByteArray()
    }

    fun buildRemoteImeText(text: String): ByteArray {
        val keyInject = ByteArrayOutputStream().apply {
            writeStringField(this, 4, text) // text_field_status / ime_batch_edit text
        }.toByteArray()
        val imeBatch = ByteArrayOutputStream().apply {
            writeVarintField(this, 1, 0)
            writeVarintField(this, 2, 0)
            writeBytesField(this, 3, keyInject)
        }.toByteArray()
        return ByteArrayOutputStream().apply {
            writeBytesField(this, 20, imeBatch) // remote_ime_batch_edit = field 20
        }.toByteArray()
    }

    fun buildRemoteStartApp(appLinkUri: String): ByteArray {
        val appLink = ByteArrayOutputStream().apply {
            writeStringField(this, 1, appLinkUri)
        }.toByteArray()
        return ByteArrayOutputStream().apply {
            writeBytesField(this, 90, appLink) // remote_app_link_launch_request = field 90
        }.toByteArray()
    }
}
