package com.example.connectivity

import com.example.model.BluetoothHidSupportStatus
import com.example.model.ConnectedDeviceInfo
import com.example.model.ConnectionState
import com.example.model.DiscoveredBluetoothDevice
import com.example.model.HidProfileStatus
import com.example.model.RemoteCommand
import com.example.model.RemoteError
import kotlinx.coroutines.flow.StateFlow

/**
 * Service abstraction over Android's [android.bluetooth.BluetoothHidDevice] profile,
 * managing composite Keyboard (Report ID 1), Consumer Control (Report ID 2),
 * and Relative Mouse (Report ID 3) profiles for the ViewModel.
 */
interface BluetoothHidService {
    val connectionState: StateFlow<ConnectionState>
    val connectedDevice: StateFlow<ConnectedDeviceInfo?>
    val bondedDevices: StateFlow<List<DiscoveredBluetoothDevice>>
    val discoveredDevices: StateFlow<List<DiscoveredBluetoothDevice>>
    val isScanning: StateFlow<Boolean>
    val hidSupportStatus: StateFlow<BluetoothHidSupportStatus>
    val hidProfileStatus: StateFlow<HidProfileStatus>
    val lastError: StateFlow<RemoteError?>

    fun requiredPermissionsForCurrentSdk(): List<String>
    fun missingPermissions(): List<String>
    fun refreshBondedDevices()

    /**
     * Binds [android.bluetooth.BluetoothProfile.HID_DEVICE] and registers the composite
     * Keyboard + Mouse + Consumer SDP descriptor when Bluetooth and permissions are ready.
     */
    fun initializeHidProfile(): RemoteError?
    fun unregisterHidProfile()

    fun startDiscovery(): RemoteError?
    fun stopDiscovery()
    fun connectOrPair(address: String)
    fun disconnect()
    fun release()

    fun sendCommand(command: RemoteCommand): RemoteError?
    fun sendText(text: String): RemoteError?
    fun sendKeyboardStroke(modifier: Byte, keyCode: Byte): RemoteError?
    fun sendKeyboardKeyDown(modifier: Byte, keyCode: Byte): RemoteError?
    fun sendKeyboardRelease(): RemoteError?

    fun sendMouseReport(
        buttonsBitmask: Int,
        deltaX: Int,
        deltaY: Int,
        scrollWheel: Int = 0
    ): RemoteError?

    fun sendMouseMove(deltaX: Int, deltaY: Int, buttonsBitmask: Int = 0): RemoteError?
    fun sendMouseClick(buttonsBitmask: Int, releaseAfter: Boolean = true): RemoteError?
    fun sendMouseScroll(wheelDelta: Int, buttonsBitmask: Int = 0): RemoteError?
}
