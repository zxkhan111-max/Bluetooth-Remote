package com.example.connectivity

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.model.ConnectedDeviceInfo
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenshotHelper(private val context: Context) {

    fun saveRemoteSessionSnapshot(connectedDevice: ConnectedDeviceInfo?): Uri? {
        val bitmap = Bitmap.createBitmap(1080, 640, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.parseColor("#0A1120"))

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00E5FF")
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRoundRect(24f, 24f, 1056f, 616f, 36f, 36f, borderPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 48f
            isFakeBoldText = true
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#67EEFF")
            textSize = 30f
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A6C4")
            textSize = 26f
        }

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        canvas.drawText("Bluetooth Remote — Session Snapshot", 64f, 120f, titlePaint)
        canvas.drawText(
            "Target: ${connectedDevice?.name ?: "No active TV"} (${connectedDevice?.mode?.name ?: "Offline"})",
            64f,
            200f,
            subPaint
        )
        canvas.drawText("Endpoint: ${connectedDevice?.addressOrHost ?: "N/A"}", 64f, 260f, bodyPaint)
        canvas.drawText("Captured: $timestamp", 64f, 320f, bodyPaint)
        canvas.drawText(
            "Note: Standard Bluetooth HID & Android TV Remote v2 do not return TV pixels.",
            64f,
            430f,
            bodyPaint
        )

        val fileName = "bt_remote_snapshot_${System.currentTimeMillis()}.png"
        val cacheDir = File(context.cacheDir, "screenshots").apply { mkdirs() }
        val cacheFile = File(cacheDir, fileName)
        FileOutputStream(cacheFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }

        // Also persist to MediaStore Pictures on Android 10+ (zero permissions required)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/BluetoothRemote")
                }
                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                }
            }
        }

        return runCatching {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cacheFile)
        }.getOrNull()
    }

    fun shareImageUri(uri: Uri) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(shareIntent, "Share Snapshot")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
