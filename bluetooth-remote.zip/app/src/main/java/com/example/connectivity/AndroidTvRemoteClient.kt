package com.example.connectivity

import android.content.Context
import android.os.Build
import com.example.model.ConnectedDeviceInfo
import com.example.model.ConnectionMode
import com.example.model.ConnectionState
import com.example.model.DeviceCapabilities
import com.example.model.RemoteCommand
import com.example.model.RemoteError
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class AndroidTvRemoteClient(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _connectedDevice = MutableStateFlow<ConnectedDeviceInfo?>(null)
    val connectedDevice: StateFlow<ConnectedDeviceInfo?> = _connectedDevice.asStateFlow()

    private val _pairingTargetName = MutableStateFlow<String?>(null)
    val pairingTargetName: StateFlow<String?> = _pairingTargetName.asStateFlow()

    private val _lastError = MutableStateFlow<RemoteError?>(null)
    val lastError: StateFlow<RemoteError?> = _lastError.asStateFlow()

    private var remoteSocket: SSLSocket? = null
    private var remoteOutput: OutputStream? = null
    private var readerJob: Job? = null

    private var pairingSocket: SSLSocket? = null
    private var pairingOutput: OutputStream? = null
    private var pairingInput: InputStream? = null
    private var pairingHost: String? = null
    private var pairingPort: Int = 6466
    private var pairingDeviceName: String = "Android TV"
    private var serverCert: X509Certificate? = null

    private val clientCredentials: Pair<PrivateKey, X509Certificate> by lazy {
        loadOrCreateClientIdentity()
    }

    fun connectOrPair(host: String, port: Int = 6466, deviceName: String = host) {
        if (!isValidIpv4OrHost(host)) {
            _lastError.value = RemoteError.InvalidIpAddress
            _connectionState.value = ConnectionState.ERROR
            return
        }
        disconnect()
        _lastError.value = null
        _connectionState.value = ConnectionState.CONNECTING

        scope.launch {
            val remoteOk = tryConnectRemoteSession(host, port, deviceName)
            if (!remoteOk) {
                // If direct remote connection fails (e.g. untrusted client cert), initiate pairing on port 6467
                startPairingSession(host, port, deviceName)
            }
        }
    }

    private fun tryConnectRemoteSession(host: String, port: Int, deviceName: String): Boolean {
        return runCatching {
            val sslFactory = buildSslContext().socketFactory
            val sock = sslFactory.createSocket() as SSLSocket
            sock.connect(InetSocketAddress(host, port), 4500)
            sock.soTimeout = 15000
            sock.startHandshake()

            val out = sock.outputStream
            val input = sock.inputStream

            val configurePayload = AndroidTvProtoCodec.buildRemoteConfigure(
                model = Build.MODEL,
                vendor = Build.MANUFACTURER,
                appPackage = context.packageName
            )
            out.write(AndroidTvProtoCodec.frameMessage(configurePayload))
            out.flush()

            // Expect RemoteConfigure response from TV
            val firstMsg = AndroidTvProtoCodec.readFramedMessage(input)
                ?: error("Remote TV closed TLS connection (pairing required)")
            val fields = AndroidTvProtoCodec.parseFields(firstMsg)
            if (fields.none { it.number == 1 }) {
                error("Unexpected handshake response from TV")
            }

            out.write(AndroidTvProtoCodec.frameMessage(AndroidTvProtoCodec.buildRemoteSetActive()))
            out.flush()

            sock.soTimeout = 0
            remoteSocket = sock
            remoteOutput = out

            _connectedDevice.value = ConnectedDeviceInfo(
                id = "$host:$port",
                name = deviceName,
                mode = ConnectionMode.WIFI_ANDROID_TV,
                addressOrHost = host,
                port = port,
                receiverCompanionConnected = false,
                capabilities = DeviceCapabilities(
                    supportsNavigation = true,
                    supportsMediaKeys = true,
                    supportsVolumeMute = true,
                    supportsKeyboardText = true,
                    supportsHidMouseAndAirMouse = false,
                    supportsSwipeDpadFallback = true,
                    supportsDeepLinkAppLaunch = true,
                    supportsInstalledAppEnumeration = false,
                    supportsDiscreteBrightnessKeys = true,
                    supportsAbsoluteBrightnessSync = false,
                    supportsTvScreenshotTrigger = true,
                    supportsTvReceiverFileTransfer = false,
                    supportsTvReceiverScreenRecording = false
                )
            )
            _connectionState.value = ConnectionState.CONNECTED
            _lastError.value = null
            startRemoteReaderLoop(input, out)
            true
        }.getOrElse {
            false
        }
    }

    private fun startPairingSession(host: String, remotePort: Int, deviceName: String) {
        runCatching {
            val pairingPortNum = 6467
            val sslFactory = buildSslContext().socketFactory
            val sock = sslFactory.createSocket() as SSLSocket
            sock.connect(InetSocketAddress(host, pairingPortNum), 5000)
            sock.soTimeout = 10000
            sock.startHandshake()

            val peerCert = sock.session.peerCertificates.firstOrNull() as? X509Certificate
                ?: error("TV did not present TLS certificate")
            serverCert = peerCert

            val out = sock.outputStream
            val input = sock.inputStream

            out.write(
                AndroidTvProtoCodec.frameMessage(
                    AndroidTvProtoCodec.buildPairingRequest("Bluetooth Remote", Build.MODEL)
                )
            )
            out.flush()
            val ack1 = AndroidTvProtoCodec.readFramedMessage(input)
                ?: error("No PairingRequestAck from TV")
            val ack1Fields = AndroidTvProtoCodec.parseFields(ack1)
            val status1 = ack1Fields.firstOrNull { it.number == 2 }?.varint?.toInt() ?: 0
            if (status1 != 200) error("TV rejected pairing request (status $status1)")

            out.write(AndroidTvProtoCodec.frameMessage(AndroidTvProtoCodec.buildPairingOption()))
            out.flush()
            val optionAck = AndroidTvProtoCodec.readFramedMessage(input)
                ?: error("No PairingOption response from TV")
            val optFields = AndroidTvProtoCodec.parseFields(optionAck)
            val statusOpt = optFields.firstOrNull { it.number == 2 }?.varint?.toInt() ?: 0
            if (statusOpt != 200) error("TV rejected pairing options (status $statusOpt)")

            out.write(AndroidTvProtoCodec.frameMessage(AndroidTvProtoCodec.buildPairingConfiguration()))
            out.flush()
            val cfgAck = AndroidTvProtoCodec.readFramedMessage(input)
                ?: error("No PairingConfigurationAck from TV")
            val cfgFields = AndroidTvProtoCodec.parseFields(cfgAck)
            val statusCfg = cfgFields.firstOrNull { it.number == 2 }?.varint?.toInt() ?: 0
            if (statusCfg != 200) error("TV rejected pairing configuration (status $statusCfg)")

            pairingSocket = sock
            pairingOutput = out
            pairingInput = input
            pairingHost = host
            pairingPort = remotePort
            pairingDeviceName = deviceName
            _pairingTargetName.value = deviceName
            _connectionState.value = ConnectionState.PAIRING_REQUIRED
        }.onFailure { err ->
            closePairingSocket()
            _lastError.value = RemoteError.WifiConnectionFailed(
                host = host,
                detail = err.message ?: "Port 6466/6467 unreachable"
            )
            _connectionState.value = ConnectionState.ERROR
        }
    }

    fun submitPairingCode(hexCode: String) {
        val cleaned = hexCode.trim().uppercase(Locale.US)
        if (cleaned.length < 4 || cleaned.length > 8) {
            _lastError.value = RemoteError.PairingFailed("Enter the hex pairing code shown on your TV")
            return
        }
        val out = pairingOutput
        val input = pairingInput
        val srvCert = serverCert
        val host = pairingHost
        if (out == null || input == null || srvCert == null || host == null) {
            _lastError.value = RemoteError.PairingFailed("Pairing session expired. Try connecting again.")
            _connectionState.value = ConnectionState.ERROR
            return
        }

        _connectionState.value = ConnectionState.CONNECTING
        scope.launch {
            runCatching {
                val secret = computePairingSecret(
                    clientCert = clientCredentials.second,
                    serverCert = srvCert,
                    hexCode = cleaned
                )
                out.write(AndroidTvProtoCodec.frameMessage(AndroidTvProtoCodec.buildPairingSecret(secret)))
                out.flush()

                val secretAck = AndroidTvProtoCodec.readFramedMessage(input)
                    ?: error("No PairingSecretAck from TV")
                val fields = AndroidTvProtoCodec.parseFields(secretAck)
                val status = fields.firstOrNull { it.number == 2 }?.varint?.toInt() ?: 0
                if (status != 200) error("Incorrect pairing code (TV status $status)")

                closePairingSocket()
                _pairingTargetName.value = null

                val remoteConnected = tryConnectRemoteSession(host, pairingPort, pairingDeviceName)
                if (!remoteConnected) {
                    error("Paired successfully, but remote control port $pairingPort did not open")
                }
            }.onFailure { err ->
                closePairingSocket()
                _pairingTargetName.value = null
                _lastError.value = RemoteError.PairingFailed(err.message ?: "Verification failed")
                _connectionState.value = ConnectionState.ERROR
            }
        }
    }

    fun cancelPairing() {
        closePairingSocket()
        _pairingTargetName.value = null
        if (_connectionState.value == ConnectionState.PAIRING_REQUIRED) {
            _connectionState.value = ConnectionState.DISCONNECTED
        }
    }

    private fun startRemoteReaderLoop(input: InputStream, output: OutputStream) {
        readerJob?.cancel()
        readerJob = scope.launch {
            runCatching {
                while (isActive) {
                    val msg = AndroidTvProtoCodec.readFramedMessage(input) ?: break
                    val fields = AndroidTvProtoCodec.parseFields(msg)
                    val pingField = fields.firstOrNull { it.number == 8 }
                    if (pingField != null) {
                        val pingPayload = AndroidTvProtoCodec.parseFields(pingField.bytes)
                        val val1 = pingPayload.firstOrNull { it.number == 1 }?.varint?.toInt() ?: 0
                        synchronized(output) {
                            output.write(
                                AndroidTvProtoCodec.frameMessage(
                                    AndroidTvProtoCodec.buildRemotePingResponse(val1)
                                )
                            )
                            output.flush()
                        }
                    }
                }
            }
            if (_connectionState.value == ConnectionState.CONNECTED) {
                disconnect()
            }
        }
    }

    fun sendCommand(command: RemoteCommand, onResult: (RemoteError?) -> Unit = {}) {
        val out = remoteOutput ?: run {
            onResult(RemoteError.NotConnected)
            return
        }
        scope.launch {
            val result = runCatching {
                val payload = AndroidTvProtoCodec.buildRemoteKeyInject(command.androidKeyCode, direction = 3)
                synchronized(out) {
                    out.write(AndroidTvProtoCodec.frameMessage(payload))
                    out.flush()
                }
                null
            }.getOrElse { err ->
                RemoteError.CommandFailed(err.message ?: "Failed to send Wi-Fi remote key")
            }
            onResult(result)
        }
    }

    fun sendText(text: String, onResult: (RemoteError?) -> Unit = {}) {
        val out = remoteOutput ?: run {
            onResult(RemoteError.NotConnected)
            return
        }
        scope.launch {
            val result = runCatching {
                val payload = AndroidTvProtoCodec.buildRemoteImeText(text)
                synchronized(out) {
                    out.write(AndroidTvProtoCodec.frameMessage(payload))
                    out.flush()
                }
                null
            }.getOrElse { err ->
                RemoteError.CommandFailed(err.message ?: "Failed to send Wi-Fi keyboard text")
            }
            onResult(result)
        }
    }

    fun launchAppLink(deepLinkUri: String, onResult: (RemoteError?) -> Unit = {}) {
        if (deepLinkUri.isBlank()) {
            onResult(RemoteError.UnsupportedFeature("App deep link", "missing_uri"))
            return
        }
        val out = remoteOutput ?: run {
            onResult(RemoteError.NotConnected)
            return
        }
        scope.launch {
            val result = runCatching {
                val payload = AndroidTvProtoCodec.buildRemoteStartApp(deepLinkUri)
                synchronized(out) {
                    out.write(AndroidTvProtoCodec.frameMessage(payload))
                    out.flush()
                }
                null
            }.getOrElse { err ->
                RemoteError.CommandFailed(err.message ?: "Failed launching TV app link")
            }
            onResult(result)
        }
    }

    fun disconnect() {
        readerJob?.cancel()
        readerJob = null
        closePairingSocket()
        runCatching { remoteSocket?.close() }
        remoteSocket = null
        remoteOutput = null
        _pairingTargetName.value = null
        _connectedDevice.value = null
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    private fun closePairingSocket() {
        runCatching { pairingSocket?.close() }
        pairingSocket = null
        pairingOutput = null
        pairingInput = null
    }

    private fun computePairingSecret(
        clientCert: X509Certificate,
        serverCert: X509Certificate,
        hexCode: String
    ): ByteArray {
        val clientKey = clientCert.publicKey as RSAPublicKey
        val serverKey = serverCert.publicKey as RSAPublicKey
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(stripLeadingZero(clientKey.modulus.toByteArray()))
        digest.update(stripLeadingZero(clientKey.publicExponent.toByteArray()))
        digest.update(stripLeadingZero(serverKey.modulus.toByteArray()))
        digest.update(stripLeadingZero(serverKey.publicExponent.toByteArray()))
        val codeSuffixBytes = hexStringToBytes(hexCode.drop(2).ifEmpty { hexCode })
        digest.update(codeSuffixBytes)
        return digest.digest()
    }

    private fun stripLeadingZero(bytes: ByteArray): ByteArray {
        return if (bytes.size > 1 && bytes[0] == 0.toByte()) bytes.copyOfRange(1, bytes.size) else bytes
    }

    private fun hexStringToBytes(s: String): ByteArray {
        val clean = if (s.length % 2 == 0) s else "0$s"
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    private fun buildSslContext(): SSLContext {
        val (privateKey, cert) = clientCredentials
        val keyStore = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
            load(null, null)
            setKeyEntry("client", privateKey, charArrayOf(), arrayOf(cert))
        }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply {
            init(keyStore, charArrayOf())
        }
        val trustAll = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        })
        return SSLContext.getInstance("TLS").apply {
            init(kmf.keyManagers, trustAll, null)
        }
    }

    private fun loadOrCreateClientIdentity(): Pair<PrivateKey, X509Certificate> {
        val keyFile = File(context.filesDir, "tv_client_key.der")
        val certFile = File(context.filesDir, "tv_client_cert.der")
        if (keyFile.exists() && certFile.exists()) {
            val loaded = runCatching {
                val kf = KeyFactory.getInstance("RSA")
                val priv = kf.generatePrivate(PKCS8EncodedKeySpec(keyFile.readBytes()))
                val cf = CertificateFactory.getInstance("X.509")
                val cert = cf.generateCertificate(certFile.inputStream()) as X509Certificate
                priv to cert
            }.getOrNull()
            if (loaded != null) return loaded
        }

        val kpg = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val keyPair = kpg.generateKeyPair()
        val certBytes = generateSelfSignedX509Der(keyPair)
        val cf = CertificateFactory.getInstance("X.509")
        val cert = cf.generateCertificate(certBytes.inputStream()) as X509Certificate

        runCatching {
            keyFile.writeBytes(keyPair.private.encoded)
            certFile.writeBytes(certBytes)
        }
        return keyPair.private to cert
    }

    /**
     * Pure-JVM ASN.1 DER X.509 v3 self-signed certificate builder (no external crypto dependency).
     */
    private fun generateSelfSignedX509Der(keyPair: KeyPair): ByteArray {
        val serial = derInteger(BigInteger.valueOf(System.currentTimeMillis()).toByteArray())
        val sigAlg = derSequence(
            derOid(byteArrayOf(0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x01, 0x0B)) + // sha256WithRSAEncryption
                byteArrayOf(0x05, 0x00) // NULL
        )
        val cnAttr = derSet(
            derSequence(
                derOid(byteArrayOf(0x55, 0x04, 0x03)) + derUtf8String("BluetoothRemoteClient")
            )
        )
        val name = derSequence(cnAttr)
        val fmt = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val notBefore = derUtcTime(fmt.format(Date(System.currentTimeMillis() - 86_400_000L)))
        val notAfter = derUtcTime(fmt.format(Date(System.currentTimeMillis() + 3_153_600_000_000L)))
        val validity = derSequence(notBefore + notAfter)
        val version = derTagged(0, derInteger(byteArrayOf(2))) // v3 = 2
        val spki = keyPair.public.encoded

        val tbsCert = derSequence(version + serial + sigAlg + name + validity + name + spki)
        val sigBytes = Signature.getInstance("SHA256withRSA").run {
            initSign(keyPair.private)
            update(tbsCert)
            sign()
        }
        val sigBitString = derBitString(sigBytes)
        return derSequence(tbsCert + sigAlg + sigBitString)
    }

    private fun derLength(len: Int): ByteArray = when {
        len < 128 -> byteArrayOf(len.toByte())
        len <= 0xFF -> byteArrayOf(0x81.toByte(), len.toByte())
        else -> byteArrayOf(0x82.toByte(), (len ushr 8).toByte(), len.toByte())
    }

    private fun derTag(tag: Int, content: ByteArray): ByteArray =
        byteArrayOf(tag.toByte()) + derLength(content.size) + content

    private fun derSequence(content: ByteArray) = derTag(0x30, content)
    private fun derSet(content: ByteArray) = derTag(0x31, content)
    private fun derInteger(content: ByteArray) = derTag(0x02, content)
    private fun derBitString(content: ByteArray) = derTag(0x03, byteArrayOf(0x00) + content)
    private fun derOid(content: ByteArray) = derTag(0x06, content)
    private fun derUtf8String(text: String) = derTag(0x0C, text.toByteArray(Charsets.UTF_8))
    private fun derUtcTime(text: String) = derTag(0x17, text.toByteArray(Charsets.US_ASCII))
    private fun derTagged(num: Int, content: ByteArray) = derTag(0xA0 or num, content)

    private fun isValidIpv4OrHost(host: String): Boolean {
        val trimmed = host.trim()
        if (trimmed.isEmpty()) return false
        val ipv4Regex = Regex("^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$")
        return ipv4Regex.matches(trimmed) || trimmed.endsWith(".local")
    }
}
