package com.example.connectivity

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import com.example.model.DeviceCompatibility
import com.example.model.DiscoveredWifiDevice
import com.example.model.ReceiverEndpoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.Inet4Address
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

class NsdTvDiscoveryManager(private val context: Context) {

    private val nsdManager: NsdManager? =
        context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val _discoveredTvs = MutableStateFlow<List<DiscoveredWifiDevice>>(emptyList())
    val discoveredTvs: StateFlow<List<DiscoveredWifiDevice>> = _discoveredTvs.asStateFlow()

    private val _discoveredReceivers = MutableStateFlow<List<ReceiverEndpoint>>(emptyList())
    val discoveredReceivers: StateFlow<List<ReceiverEndpoint>> = _discoveredReceivers.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private var multicastLock: WifiManager.MulticastLock? = null
    private val activeListeners = mutableListOf<NsdManager.DiscoveryListener>()
    private val resolveQueue = ConcurrentLinkedQueue<NsdServiceInfo>()
    private val resolving = AtomicBoolean(false)

    companion object {
        const val SERVICE_ANDROID_TV_V2 = "_androidtvremote2._tcp."
        const val SERVICE_ANDROID_TV_V1 = "_androidtvremote._tcp."
        const val SERVICE_GOOGLE_CAST = "_googlecast._tcp."
        const val SERVICE_COMPANION_RECEIVER = "_btremote_xfer._tcp."
    }

    fun startDiscovery() {
        stopDiscovery()
        val manager = nsdManager ?: return
        acquireMulticastLock()
        _isScanning.value = true

        val serviceTypes = listOf(
            SERVICE_ANDROID_TV_V2,
            SERVICE_ANDROID_TV_V1,
            SERVICE_GOOGLE_CAST,
            SERVICE_COMPANION_RECEIVER
        )

        serviceTypes.forEach { type ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String?) = Unit

                override fun onServiceFound(serviceInfo: NsdServiceInfo?) {
                    serviceInfo ?: return
                    resolveQueue.offer(serviceInfo)
                    drainResolveQueue()
                }

                override fun onServiceLost(serviceInfo: NsdServiceInfo?) {
                    serviceInfo ?: return
                    val name = serviceInfo.serviceName ?: return
                    _discoveredTvs.value = _discoveredTvs.value.filterNot { it.name == name }
                    _discoveredReceivers.value = _discoveredReceivers.value.filterNot { it.name == name }
                }

                override fun onDiscoveryStopped(serviceType: String?) = Unit
                override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) = Unit
                override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) = Unit
            }
            activeListeners.add(listener)
            runCatching {
                manager.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener)
            }
        }
    }

    private fun drainResolveQueue() {
        if (!resolving.compareAndSet(false, true)) return
        val next = resolveQueue.poll()
        if (next == null) {
            resolving.set(false)
            return
        }
        val manager = nsdManager ?: run {
            resolving.set(false)
            return
        }

        @Suppress("DEPRECATION")
        manager.resolveService(next, object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {
                resolving.set(false)
                drainResolveQueue()
            }

            override fun onServiceResolved(serviceInfo: NsdServiceInfo?) {
                serviceInfo?.let { handleResolvedService(it) }
                resolving.set(false)
                drainResolveQueue()
            }
        })
    }

    private fun handleResolvedService(info: NsdServiceInfo) {
        val hostAddress = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            info.hostAddresses.firstOrNull { it is Inet4Address }?.hostAddress
                ?: info.hostAddresses.firstOrNull()?.hostAddress
        } else {
            @Suppress("DEPRECATION")
            info.host?.hostAddress
        } ?: return

        val serviceType = info.serviceType.orEmpty()
        val rawName = info.serviceName.orEmpty().ifBlank { hostAddress }
        val port = info.port.takeIf { it > 0 } ?: 6466

        if (serviceType.contains("btremote_xfer")) {
            val endpoint = ReceiverEndpoint(
                id = "$hostAddress:$port",
                name = rawName,
                host = hostAddress,
                port = port,
                requiresPin = true
            )
            _discoveredReceivers.value =
                (_discoveredReceivers.value.filterNot { it.id == endpoint.id } + endpoint)
            return
        }

        val (compat, noteKey) = when {
            serviceType.contains("androidtvremote2") ->
                DeviceCompatibility.COMPATIBLE to "android_tv_v2"
            serviceType.contains("androidtvremote") ->
                DeviceCompatibility.LIMITED_COMPATIBILITY to "android_tv_v1_legacy"
            serviceType.contains("googlecast") ->
                DeviceCompatibility.LIMITED_COMPATIBILITY to "google_cast_only"
            else ->
                DeviceCompatibility.INCOMPATIBLE to "unknown_service"
        }

        val hasCompanion = _discoveredReceivers.value.any { it.host == hostAddress }
        val tv = DiscoveredWifiDevice(
            id = "${hostAddress}_$serviceType",
            name = rawName,
            host = hostAddress,
            port = if (serviceType.contains("androidtvremote2")) port else 6466,
            serviceType = serviceType,
            compatibility = compat,
            compatibilityNoteKey = noteKey,
            supportsReceiverCompanion = hasCompanion
        )

        val existing = _discoveredTvs.value.filterNot {
            it.host == hostAddress && it.compatibility.ordinal > compat.ordinal
        }
        if (existing.none { it.host == hostAddress && it.compatibility.ordinal <= compat.ordinal }) {
            _discoveredTvs.value = (existing.filterNot { it.id == tv.id } + tv)
                .sortedBy { it.compatibility.ordinal }
        }
    }

    fun stopDiscovery() {
        val manager = nsdManager
        if (manager != null) {
            activeListeners.forEach { listener ->
                runCatching { manager.stopServiceDiscovery(listener) }
            }
        }
        activeListeners.clear()
        resolveQueue.clear()
        resolving.set(false)
        releaseMulticastLock()
        _isScanning.value = false
    }

    private fun acquireMulticastLock() {
        runCatching {
            if (multicastLock == null) {
                multicastLock = wifiManager?.createMulticastLock("bluetooth_remote_nsd_lock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (multicastLock?.isHeld == false) {
                multicastLock?.acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        runCatching {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        }
    }
}
