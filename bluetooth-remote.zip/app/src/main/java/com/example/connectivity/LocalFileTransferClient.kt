package com.example.connectivity

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.TransferItem
import com.example.model.TransferStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID

/**
 * Local-only authenticated LAN file transfer client for a compatible Android TV Receiver App.
 * Validates private LAN IPv4 addresses, performs SHA-256 PIN challenge auth, streams chunks
 * with real progress & throughput, and requires explicit receiver ACK before marking COMPLETED.
 */
class LocalFileTransferClient(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _queue = MutableStateFlow<List<TransferItem>>(emptyList())
    val queue: StateFlow<List<TransferItem>> = _queue.asStateFlow()

    private val _isTransferring = MutableStateFlow(false)
    val isTransferring: StateFlow<Boolean> = _isTransferring.asStateFlow()

    private var activeJob: Job? = null

    fun addFilesFromUris(uris: List<Uri>) {
        val newItems = uris.mapNotNull { uri ->
            resolveUriMetadata(uri)
        }
        if (newItems.isNotEmpty()) {
            val existingUris = _queue.value.map { it.uriString }.toSet()
            _queue.value = _queue.value + newItems.filterNot { it.uriString in existingUris }
        }
    }

    fun removeItem(itemId: String) {
        _queue.value = _queue.value.filterNot { it.id == itemId && it.status != TransferStatus.TRANSFERRING }
    }

    fun clearCompletedOrFailed() {
        _queue.value = _queue.value.filter {
            it.status == TransferStatus.QUEUED || it.status == TransferStatus.TRANSFERRING
        }
    }

    fun startTransfer(
        host: String,
        port: Int,
        sessionPin: String,
        onItemFinished: (TransferItem) -> Unit
    ) {
        if (_isTransferring.value) return
        val cleanHost = host.trim()
        if (!isLocalLanAddress(cleanHost)) {
            markAllPendingFailed("Refused: File transfer only allows local private LAN IP addresses.")
            return
        }
        if (sessionPin.trim().length < 4) {
            markAllPendingFailed("Enter the 4+ digit session PIN shown on your TV Receiver App.")
            return
        }

        activeJob = scope.launch {
            _isTransferring.value = true
            try {
                val pending = _queue.value.filter {
                    it.status == TransferStatus.QUEUED || it.status == TransferStatus.FAILED
                }
                for (item in pending) {
                    if (!isActive) break
                    val finished = transferSingleItem(item, cleanHost, port, sessionPin.trim())
                    onItemFinished(finished)
                }
            } finally {
                _isTransferring.value = false
            }
        }
    }

    fun cancelTransfer() {
        activeJob?.cancel()
        activeJob = null
        _isTransferring.value = false
        _queue.value = _queue.value.map {
            if (it.status == TransferStatus.TRANSFERRING || it.status == TransferStatus.AWAITING_RECEIVER_AUTH) {
                it.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L)
            } else {
                it
            }
        }
    }

    private fun transferSingleItem(
        item: TransferItem,
        host: String,
        port: Int,
        pin: String
    ): TransferItem {
        updateItem(item.id) {
            it.copy(status = TransferStatus.AWAITING_RECEIVER_AUTH, errorDetail = null, bytesSent = 0L)
        }

        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 5000)
                socket.soTimeout = 15000

                val out = DataOutputStream(socket.getOutputStream())
                val inp = DataInputStream(socket.getInputStream())

                // Step 1: Read challenge nonce from TV Receiver App
                val nonce = inp.readUTF()
                val authDigest = sha256Hex("$pin:$nonce:${item.fileName}:${item.sizeBytes}")
                val header = JSONObject().apply {
                    put("fileName", item.fileName)
                    put("mimeType", item.mimeType)
                    put("sizeBytes", item.sizeBytes)
                    put("auth", authDigest)
                }.toString()
                out.writeUTF(header)
                out.flush()

                val authReply = inp.readUTF()
                if (authReply != "AUTH_OK") {
                    error("TV Receiver rejected session: $authReply")
                }

                updateItem(item.id) { it.copy(status = TransferStatus.TRANSFERRING) }

                val uri = Uri.parse(item.uriString)
                val contentStream = context.contentResolver.openInputStream(uri)
                    ?: error("Cannot read selected file from phone storage")

                val buffer = ByteArray(32 * 1024)
                var totalSent = 0L
                val startTime = System.currentTimeMillis()
                var lastUiUpdate = startTime

                BufferedInputStream(contentStream).use { bis ->
                    while (true) {
                        if (activeJob?.isActive == false) throw CancellationException()
                        val read = bis.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        totalSent += read
                        val now = System.currentTimeMillis()
                        if (now - lastUiUpdate >= 120L || totalSent >= item.sizeBytes) {
                            val elapsedSec = ((now - startTime).coerceAtLeast(1L)) / 1000.0
                            val speed = (totalSent / elapsedSec).toLong()
                            updateItem(item.id) {
                                it.copy(bytesSent = totalSent, speedBytesPerSec = speed)
                            }
                            lastUiUpdate = now
                        }
                    }
                }
                out.flush()

                // Require explicit TV receiver ACK confirmation
                val ack = inp.readUTF()
                if (!ack.startsWith("ACK_OK")) {
                    error("TV Receiver did not confirm file write: $ack")
                }

                val completed = item.copy(
                    bytesSent = item.sizeBytes,
                    speedBytesPerSec = 0L,
                    status = TransferStatus.COMPLETED,
                    errorDetail = null
                )
                updateItem(item.id) { completed }
                completed
            }
        } catch (ce: CancellationException) {
            val cancelled = item.copy(status = TransferStatus.CANCELLED, speedBytesPerSec = 0L)
            updateItem(item.id) { cancelled }
            cancelled
        } catch (e: Exception) {
            val failed = item.copy(
                status = TransferStatus.FAILED,
                speedBytesPerSec = 0L,
                errorDetail = e.message ?: "TV Receiver unreachable on $host:$port"
            )
            updateItem(item.id) { failed }
            failed
        }
    }

    private fun updateItem(id: String, transform: (TransferItem) -> TransferItem) {
        _queue.value = _queue.value.map { if (it.id == id) transform(it) else it }
    }

    private fun markAllPendingFailed(reason: String) {
        _queue.value = _queue.value.map {
            if (it.status == TransferStatus.QUEUED) {
                it.copy(status = TransferStatus.FAILED, errorDetail = reason)
            } else {
                it
            }
        }
    }

    private fun resolveUriMetadata(uri: Uri): TransferItem? {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        var name = "file_${System.currentTimeMillis()}"
        var size = 0L
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = c.getString(nameIdx) ?: name
                    if (sizeIdx >= 0) size = c.getLong(sizeIdx)
                }
            }
        }
        return TransferItem(
            id = UUID.randomUUID().toString(),
            fileName = name,
            mimeType = mime,
            uriString = uri.toString(),
            sizeBytes = size
        )
    }

    private fun isLocalLanAddress(host: String): Boolean {
        return runCatching {
            val addr = InetAddress.getByName(host)
            addr is Inet4Address && (addr.isSiteLocalAddress || addr.isLoopbackAddress)
        }.getOrDefault(false)
    }

    private fun sha256Hex(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(StandardCharsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
