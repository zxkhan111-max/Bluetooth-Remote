package com.example.connectivity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import com.example.model.MirroringStatus
import com.example.model.TvRecordingStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket

class ScreenMirrorController(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val projectionManager =
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager

    private val _mirrorStatus = MutableStateFlow(MirroringStatus.IDLE)
    val mirrorStatus: StateFlow<MirroringStatus> = _mirrorStatus.asStateFlow()

    private val _mirrorInfo = MutableStateFlow<String?>(null)
    val mirrorInfo: StateFlow<String?> = _mirrorInfo.asStateFlow()

    private val _recordingStatus = MutableStateFlow(TvRecordingStatus.UNSUPPORTED_NO_RECEIVER)
    val recordingStatus: StateFlow<TvRecordingStatus> = _recordingStatus.asStateFlow()

    private val _recordingSeconds = MutableStateFlow(0L)
    val recordingSeconds: StateFlow<Long> = _recordingSeconds.asStateFlow()

    private val _recordingMessage = MutableStateFlow<String?>(null)
    val recordingMessage: StateFlow<String?> = _recordingMessage.asStateFlow()

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var recordingTimerJob: Job? = null

    fun createCapturePermissionIntent(): Intent? {
        return projectionManager?.createScreenCaptureIntent()
    }

    fun onMediaProjectionResult(resultCode: Int, data: Intent?) {
        if (resultCode != Activity.RESULT_OK || data == null) {
            _mirrorStatus.value = MirroringStatus.IDLE
            _mirrorInfo.value = "Screen capture permission was cancelled."
            return
        }
        val serviceIntent = Intent(context, ScreenMirrorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }

        runCatching {
            val proj = projectionManager?.getMediaProjection(resultCode, data)
                ?: error("MediaProjection service unavailable")
            mediaProjection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopMirroring()
                }
            }, Handler(Looper.getMainLooper()))

            val metrics = context.resources.displayMetrics
            val width = (metrics.widthPixels / 2).coerceAtLeast(360)
            val height = (metrics.heightPixels / 2).coerceAtLeast(640)
            val reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
            imageReader = reader
            virtualDisplay = proj.createVirtualDisplay(
                "BluetoothRemoteMirrorDisplay",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                null
            )
            _mirrorStatus.value = MirroringStatus.ACTIVE_VIRTUAL_DISPLAY
            _mirrorInfo.value = "VirtualDisplay active (${width}x$height). Pair with system Wireless Display or Cast receiver to output to TV."
        }.onFailure { err ->
            _mirrorStatus.value = MirroringStatus.ERROR
            _mirrorInfo.value = err.message ?: "Failed starting screen capture."
            stopForegroundService()
        }
    }

    fun stopMirroring() {
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        stopForegroundService()
        _mirrorStatus.value = MirroringStatus.IDLE
        _mirrorInfo.value = null
    }

    fun openSystemCastSettings() {
        runCatching {
            val intent = Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    private fun stopForegroundService() {
        runCatching { context.stopService(Intent(context, ScreenMirrorService::class.java)) }
    }

    // --- Module 10: Companion TV Receiver-side Screen Recording ---

    fun updateReceiverAvailability(hasReceiverEndpoint: Boolean) {
        if (!hasReceiverEndpoint && _recordingStatus.value != TvRecordingStatus.RECORDING) {
            _recordingStatus.value = TvRecordingStatus.UNSUPPORTED_NO_RECEIVER
        } else if (hasReceiverEndpoint && _recordingStatus.value == TvRecordingStatus.UNSUPPORTED_NO_RECEIVER) {
            _recordingStatus.value = TvRecordingStatus.IDLE_READY
        }
    }

    fun requestTvScreenRecording(host: String, port: Int, pin: String) {
        if (host.isBlank()) {
            _recordingStatus.value = TvRecordingStatus.UNSUPPORTED_NO_RECEIVER
            _recordingMessage.value = "Connect a compatible TV Receiver App over Wi-Fi first."
            return
        }
        _recordingStatus.value = TvRecordingStatus.AWAITING_TV_USER_CONSENT
        _recordingMessage.value = "Requesting explicit TV user recording authorization on $host..."

        scope.launch {
            runCatching {
                Socket().use { sock ->
                    sock.connect(InetSocketAddress(host, port), 5000)
                    sock.soTimeout = 15000
                    val out = DataOutputStream(sock.getOutputStream())
                    val inp = DataInputStream(sock.getInputStream())
                    out.writeUTF("RECORD_START:$pin")
                    out.flush()
                    val response = inp.readUTF()
                    if (response == "RECORD_STARTED") {
                        _recordingStatus.value = TvRecordingStatus.RECORDING
                        _recordingMessage.value = "TV Receiver recording authorized and active (DRM content excluded)."
                        startTimer()
                    } else {
                        _recordingStatus.value = TvRecordingStatus.ERROR
                        _recordingMessage.value = "TV Receiver denied or does not support recording: $response"
                    }
                }
            }.onFailure { err ->
                _recordingStatus.value = TvRecordingStatus.UNSUPPORTED_NO_RECEIVER
                _recordingMessage.value = "No TV Receiver recording service found on $host:$port (${err.message})."
            }
        }
    }

    fun stopTvScreenRecording(host: String, port: Int, pin: String) {
        recordingTimerJob?.cancel()
        recordingTimerJob = null
        if (host.isBlank()) {
            _recordingStatus.value = TvRecordingStatus.UNSUPPORTED_NO_RECEIVER
            return
        }
        scope.launch {
            runCatching {
                Socket().use { sock ->
                    sock.connect(InetSocketAddress(host, port), 4000)
                    val out = DataOutputStream(sock.getOutputStream())
                    val inp = DataInputStream(sock.getInputStream())
                    out.writeUTF("RECORD_STOP:$pin")
                    out.flush()
                    val response = inp.readUTF()
                    _recordingStatus.value = TvRecordingStatus.SAVED
                    _recordingMessage.value = response
                }
            }.onFailure {
                _recordingStatus.value = TvRecordingStatus.IDLE_READY
                _recordingMessage.value = "Stopped recording session."
            }
        }
    }

    private fun startTimer() {
        recordingTimerJob?.cancel()
        _recordingSeconds.value = 0L
        recordingTimerJob = scope.launch {
            while (isActive) {
                delay(1000L)
                _recordingSeconds.value += 1L
            }
        }
    }
}
