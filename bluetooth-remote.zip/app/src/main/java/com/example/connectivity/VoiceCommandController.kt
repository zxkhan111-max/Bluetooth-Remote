package com.example.connectivity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.example.model.AppLanguage
import com.example.model.RemoteCommand
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed interface ParsedVoiceIntent {
    data class Command(val command: RemoteCommand) : ParsedVoiceIntent
    data class LaunchApp(val appId: String, val displayName: String) : ParsedVoiceIntent
    data class SearchQuery(val query: String) : ParsedVoiceIntent
    data object Unrecognized : ParsedVoiceIntent
}

class VoiceCommandController(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _recognizedText = MutableStateFlow("")
    val recognizedText: StateFlow<String> = _recognizedText.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    fun isSpeechAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(language: AppLanguage, onRecognizedIntent: (String, ParsedVoiceIntent) -> Unit) {
        if (!hasAudioPermission()) {
            _errorMessage.value = "Microphone permission is required for Voice Control."
            return
        }
        if (!isSpeechAvailable()) {
            _errorMessage.value = "Speech recognition service is unavailable on this device."
            return
        }

        stopListening()
        _errorMessage.value = null
        _recognizedText.value = ""

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        speechRecognizer = recognizer

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit

            override fun onEndOfSpeech() {
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _errorMessage.value = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH ->
                        if (language == AppLanguage.BENGALI) "কোনো কমান্ড বোঝা যায়নি।" else "No voice command matched."
                    SpeechRecognizer.ERROR_AUDIO ->
                        if (language == AppLanguage.BENGALI) "মাইক্রোফোন অডিও সমস্যা হয়েছে।" else "Microphone audio capture error."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        if (language == AppLanguage.BENGALI) "মাইক্রোফোন অনুমতি নেই।" else "Microphone permission denied."
                    else ->
                        if (language == AppLanguage.BENGALI) "ভয়েস রিকগনিশন ব্যর্থ (কোড $error)।" else "Voice recognition error ($error)."
                }
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val spoken = matches.firstOrNull().orEmpty()
                _recognizedText.value = spoken
                if (spoken.isNotBlank()) {
                    val intent = parseSpokenCommand(spoken)
                    onRecognizedIntent(spoken, intent)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (partial.isNotBlank()) {
                    _recognizedText.value = partial
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val localeTag = if (language == AppLanguage.BENGALI) "bn-BD" else "en-US"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer.startListening(intent)
    }

    fun stopListening() {
        runCatching {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        }
        speechRecognizer = null
        _isListening.value = false
    }

    companion object {
        fun parseSpokenCommand(raw: String): ParsedVoiceIntent {
            val text = raw.trim().lowercase(Locale.ROOT)
            return when {
                text.contains("youtube") || text.contains("ইউটিউব") ->
                    ParsedVoiceIntent.LaunchApp("yt", "YouTube")
                text.contains("netflix") || text.contains("নেটফ্লিক্স") ->
                    ParsedVoiceIntent.LaunchApp("nf", "Netflix")
                text.contains("play store") || text.contains("প্লে স্টোর") ->
                    ParsedVoiceIntent.LaunchApp("ps", "Play Store")
                text.contains("go home") || text == "home" || text.contains("হোম") ->
                    ParsedVoiceIntent.Command(RemoteCommand.HOME)
                text.contains("go back") || text == "back" || text.contains("ব্যাক") || text.contains("পিছনে") ->
                    ParsedVoiceIntent.Command(RemoteCommand.BACK)
                text.contains("volume up") || text.contains("louder") || text.contains("ভলিউম বাড়া") || text.contains("শব্দ বাড়া") ->
                    ParsedVoiceIntent.Command(RemoteCommand.VOLUME_UP)
                text.contains("volume down") || text.contains("quieter") || text.contains("ভলিউম কমা") || text.contains("শব্দ কমা") ->
                    ParsedVoiceIntent.Command(RemoteCommand.VOLUME_DOWN)
                text.contains("mute") || text.contains("মিউট") || text.contains("নিঃশব্দ") ->
                    ParsedVoiceIntent.Command(RemoteCommand.MUTE)
                text == "play" || text.contains("play video") || text.contains("প্লে") || text.contains("চালাও") ->
                    ParsedVoiceIntent.Command(RemoteCommand.PLAY_PAUSE)
                text == "pause" || text.contains("পজ") || text.contains("থামাও") ->
                    ParsedVoiceIntent.Command(RemoteCommand.PLAY_PAUSE)
                text == "up" || text.contains("go up") || text.contains("উপরে") ->
                    ParsedVoiceIntent.Command(RemoteCommand.DPAD_UP)
                text == "down" || text.contains("go down") || text.contains("নিচে") ->
                    ParsedVoiceIntent.Command(RemoteCommand.DPAD_DOWN)
                text == "left" || text.contains("go left") || text.contains("বামে") ->
                    ParsedVoiceIntent.Command(RemoteCommand.DPAD_LEFT)
                text == "right" || text.contains("go right") || text.contains("ডানে") ->
                    ParsedVoiceIntent.Command(RemoteCommand.DPAD_RIGHT)
                text == "ok" || text == "okay" || text.contains("select") || text.contains("ওকে") || text.contains("নির্বাচন") ->
                    ParsedVoiceIntent.Command(RemoteCommand.DPAD_OK)
                text.startsWith("search ") || text.startsWith("সার্চ ") -> {
                    val query = text.removePrefix("search ").removePrefix("সার্চ ").trim()
                    if (query.isNotEmpty()) ParsedVoiceIntent.SearchQuery(query)
                    else ParsedVoiceIntent.Command(RemoteCommand.SEARCH)
                }
                text == "search" || text == "সার্চ" || text.contains("খুঁজুন") ->
                    ParsedVoiceIntent.Command(RemoteCommand.SEARCH)
                else -> ParsedVoiceIntent.Unrecognized
            }
        }
    }
}
