package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.model.RemoteCommand
import com.example.ui.components.PairingCodeDialog
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.AppsLauncherScreen
import com.example.ui.screens.DeviceDiscoveryScreen
import com.example.ui.screens.FileTransferScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.KeyboardScreen
import com.example.ui.screens.MediaAndToolsScreen
import com.example.ui.screens.MouseAndTouchpadScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.RemoteControlScreen
import com.example.ui.screens.SettingsAndHelpScreen
import com.example.ui.theme.BluetoothRemoteTheme
import com.example.ui.theme.CobaltBlue
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.SlateBorder
import com.example.ui.viewmodel.RemoteViewModel

object RemoteRoutes {
    const val ROUTE_HOME = "home"
    const val ROUTE_REMOTE = "remote"
    const val ROUTE_MOUSE = "mouse"
    const val ROUTE_KEYBOARD = "keyboard"
    const val ROUTE_APPS = "apps"
    const val ROUTE_MEDIA = "media"
    const val ROUTE_TRANSFER = "transfer"
    const val ROUTE_SETTINGS = "settings"
    const val ROUTE_DISCOVERY = "discovery"
}

data class NavDestinationItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val tag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BluetoothRemoteApp()
        }
    }
}

@Composable
fun BluetoothRemoteApp(viewModel: RemoteViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val strings = stringsFor(state.preferences.language)

    val btPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.onPermissionsResult()
        if (viewModel.missingBluetoothPermissions().isEmpty()) {
            viewModel.scanDevices()
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startVoiceControl()
        }
    }

    val mirrorCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        viewModel.onMirroringPermissionResult(result.resultCode, result.data)
    }

    val startVoiceWithPermissionCheck: () -> Unit = {
        if (viewModel.hasMicrophonePermission()) {
            viewModel.startVoiceControl()
        } else {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val requestBluetoothAndScan: () -> Unit = {
        val missing = viewModel.missingBluetoothPermissions()
        if (missing.isEmpty()) {
            viewModel.scanDevices()
        } else {
            btPermissionsLauncher.launch(missing.toTypedArray())
        }
    }

    BluetoothRemoteTheme(darkTheme = state.preferences.darkTheme) {
        CompositionLocalProvider(LocalAppStrings provides strings) {
            if (!state.preferences.onboardingCompleted) {
                Scaffold(contentWindowInsets = WindowInsets.safeDrawing) { innerPadding ->
                    OnboardingScreen(
                        currentLanguage = state.preferences.language,
                        onLanguageChange = viewModel::setLanguage,
                        onFinish = viewModel::completeOnboarding,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
                return@CompositionLocalProvider
            }

            state.pairingTargetName?.let { targetName ->
                PairingCodeDialog(
                    targetName = targetName,
                    onSubmitCode = viewModel::submitWifiPairingCode,
                    onCancel = viewModel::cancelWifiPairing
                )
            }

            val navController = rememberNavController()
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route ?: RemoteRoutes.ROUTE_HOME

            val navItems = listOf(
                NavDestinationItem(RemoteRoutes.ROUTE_HOME, strings.navHome, Icons.Filled.Home, "nav_home"),
                NavDestinationItem(RemoteRoutes.ROUTE_REMOTE, strings.navRemote, Icons.Filled.SettingsRemote, "nav_remote"),
                NavDestinationItem(RemoteRoutes.ROUTE_MOUSE, strings.navMouse, Icons.Filled.Mouse, "nav_mouse"),
                NavDestinationItem(RemoteRoutes.ROUTE_KEYBOARD, strings.navKeyboard, Icons.Filled.Keyboard, "nav_keyboard"),
                NavDestinationItem(RemoteRoutes.ROUTE_APPS, strings.navApps, Icons.Filled.Apps, "nav_apps"),
                NavDestinationItem(RemoteRoutes.ROUTE_MEDIA, strings.navMedia, Icons.Filled.Cast, "nav_media"),
                NavDestinationItem(RemoteRoutes.ROUTE_TRANSFER, strings.navTransfer, Icons.Filled.FolderCopy, "nav_transfer"),
                NavDestinationItem(RemoteRoutes.ROUTE_SETTINGS, strings.navSettings, Icons.Filled.Settings, "nav_settings")
            )

            val navigateTopLevel: (String) -> Unit = { route ->
                if (currentRoute != route) {
                    navController.navigate(route) {
                        popUpTo(RemoteRoutes.ROUTE_HOME) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                val useSideRail = maxWidth >= 720.dp
                val showNavChrome = currentRoute != RemoteRoutes.ROUTE_DISCOVERY

                if (useSideRail) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        if (showNavChrome) {
                            NavigationRail(
                                containerColor = MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .statusBarsPadding()
                                    .navigationBarsPadding()
                                    .verticalScroll(rememberScrollState())
                            ) {
                                navItems.forEach { item ->
                                    val selected = currentRoute == item.route
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { navigateTopLevel(item.route) },
                                        icon = { Icon(item.icon, contentDescription = item.label) },
                                        label = { Text(item.label, maxLines = 1) },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = CyanGlow,
                                            selectedTextColor = CyanGlow,
                                            indicatorColor = CobaltBlue.copy(alpha = 0.25f)
                                        ),
                                        modifier = Modifier.testTag(item.tag)
                                    )
                                }
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .statusBarsPadding()
                                .navigationBarsPadding(),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            RemoteNavHost(
                                navController = navController,
                                viewModel = viewModel,
                                state = state,
                                onRequestBluetoothScan = requestBluetoothAndScan,
                                onStartVoice = startVoiceWithPermissionCheck,
                                onStartMirroring = {
                                    viewModel.createMirroringPermissionIntent()?.let {
                                        mirrorCaptureLauncher.launch(it)
                                    }
                                }
                            )
                        }
                    }
                } else {
                    Scaffold(
                        containerColor = MaterialTheme.colorScheme.background,
                        contentWindowInsets = WindowInsets.safeDrawing,
                        bottomBar = {
                            if (showNavChrome) {
                                BottomNavDock(
                                    items = navItems,
                                    currentRoute = currentRoute,
                                    onNavigate = navigateTopLevel
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            RemoteNavHost(
                                navController = navController,
                                viewModel = viewModel,
                                state = state,
                                onRequestBluetoothScan = requestBluetoothAndScan,
                                onStartVoice = startVoiceWithPermissionCheck,
                                onStartMirroring = {
                                    viewModel.createMirroringPermissionIntent()?.let {
                                        mirrorCaptureLauncher.launch(it)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNavDock(
    items: List<NavDestinationItem>,
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        border = BorderStroke(1.dp, SlateBorder),
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("bottom_nav_dock"),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(items, key = { it.route }) { item ->
                val selected = currentRoute == item.route
                Column(
                    modifier = Modifier
                        .widthIn(min = 66.dp)
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (selected) CobaltBlue.copy(alpha = 0.24f) else Color.Transparent)
                        .clickable { onNavigate(item.route) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag(item.tag),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (selected) CyanGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(21.dp)
                    )
                    Text(
                        text = item.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) CyanGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun RemoteNavHost(
    navController: androidx.navigation.NavHostController,
    viewModel: RemoteViewModel,
    state: com.example.ui.viewmodel.RemoteUiState,
    onRequestBluetoothScan: () -> Unit,
    onStartVoice: () -> Unit,
    onStartMirroring: () -> Unit
) {
    NavHost(
        navController = navController,
        startDestination = RemoteRoutes.ROUTE_HOME
    ) {
        composable(RemoteRoutes.ROUTE_HOME) {
            HomeDashboardScreen(
                state = state,
                onSelectMode = viewModel::selectConnectionMode,
                onOpenDiscovery = { navController.navigate(RemoteRoutes.ROUTE_DISCOVERY) },
                onScanDevices = onRequestBluetoothScan,
                onDisconnect = viewModel::disconnectActiveDevice,
                onReconnectProfile = viewModel::reconnectProfile,
                onToggleFavorite = viewModel::toggleProfileFavorite,
                onLaunchQuickApp = viewModel::launchTvApp,
                onStartVoice = onStartVoice,
                onStopVoice = viewModel::stopVoiceControl,
                onDismissError = viewModel::dismissError,
                onDismissNotice = viewModel::dismissNotice
            )
        }

        composable(RemoteRoutes.ROUTE_DISCOVERY) {
            DeviceDiscoveryScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onSelectMode = viewModel::selectConnectionMode,
                onRequestBluetoothPermissions = onRequestBluetoothScan,
                onInitializeHidProfile = { viewModel.initializeBluetoothHidProfile(true) },
                onScanDevices = onRequestBluetoothScan,
                onStopScanning = viewModel::stopScanning,
                onConnectBluetooth = viewModel::connectBluetoothDevice,
                onConnectWifi = viewModel::connectWifiDevice,
                onDismissError = viewModel::dismissError
            )
        }

        composable(RemoteRoutes.ROUTE_REMOTE) {
            RemoteControlScreen(
                state = state,
                onCommand = viewModel::sendRemoteCommand,
                onTriggerTvScreenshot = viewModel::triggerTvScreenshotKey,
                onOpenVoice = onStartVoice
            )
        }

        composable(RemoteRoutes.ROUTE_MOUSE) {
            MouseAndTouchpadScreen(
                state = state,
                onToggleMouseMode = viewModel::setMousePointerMode,
                onTouchpadMove = viewModel::onTouchpadMove,
                onTouchpadSwipeCommand = viewModel::onTouchpadSwipeDirection,
                onMouseClick = viewModel::sendMouseClick,
                onToggleDragLock = viewModel::toggleDragLock,
                onMouseScroll = viewModel::sendMouseScroll,
                onSetAirMouseEnabled = viewModel::setAirMouseEnabled,
                onCalibrateAirMouse = viewModel::calibrateAirMouse,
                onUpdateTuning = viewModel::updateMouseTuning
            )
        }

        composable(RemoteRoutes.ROUTE_KEYBOARD) {
            KeyboardScreen(
                state = state,
                onSendText = viewModel::sendKeyboardText,
                onBackspace = viewModel::sendBackspaceKey,
                onEnter = viewModel::sendEnterKey,
                onSearch = { viewModel.sendRemoteCommand(RemoteCommand.SEARCH, true) }
            )
        }

        composable(RemoteRoutes.ROUTE_APPS) {
            AppsLauncherScreen(
                state = state,
                onLaunchApp = viewModel::launchTvApp,
                onToggleFavorite = viewModel::toggleAppFavorite,
                onTogglePinQuick = viewModel::toggleAppPinnedQuick,
                onAddCustomApp = viewModel::addCustomQuickApp,
                onRefreshApps = viewModel::refreshTvAppsCapability,
                onStartVoice = onStartVoice,
                onStopVoice = viewModel::stopVoiceControl
            )
        }

        composable(RemoteRoutes.ROUTE_MEDIA) {
            androidx.compose.runtime.LaunchedEffect(Unit) {
                viewModel.refreshCastDevices()
            }
            MediaAndToolsScreen(
                state = state,
                onSelectMediaForCast = viewModel::selectMediaForCast,
                onRefreshCastDevices = viewModel::refreshCastDevices,
                onSelectCastDevice = viewModel::selectCastDevice,
                onCastSelectedMedia = viewModel::castSelectedMedia,
                onToggleCastPlayPause = viewModel::toggleCastPlayPause,
                onSeekCast = viewModel::seekCast,
                onSetCastVolume = viewModel::setCastVolume,
                onStopCasting = viewModel::stopCasting,
                onRequestStartMirroring = onStartMirroring,
                onStopMirroring = viewModel::stopMirroring,
                onOpenSystemCastSettings = viewModel::openSystemCastSettings,
                onRequestTvRecording = viewModel::requestTvRecording,
                onStopTvRecording = viewModel::stopTvRecording,
                onSendCommand = { cmd -> viewModel.sendRemoteCommand(cmd, false) },
                onTriggerTvScreenshot = viewModel::triggerTvScreenshotKey,
                onSaveSnapshot = viewModel::saveRemoteSnapshot,
                onShareSnapshot = viewModel::shareLastSnapshot
            )
        }

        composable(RemoteRoutes.ROUTE_TRANSFER) {
            FileTransferScreen(
                state = state,
                onAddFiles = viewModel::addTransferFiles,
                onRemoveFile = viewModel::removeTransferItem,
                onStartTransfer = viewModel::startLocalFileTransfer,
                onCancelTransfer = viewModel::cancelFileTransfer
            )
        }

        composable(RemoteRoutes.ROUTE_SETTINGS) {
            SettingsAndHelpScreen(
                state = state,
                onSetDarkTheme = viewModel::setDarkTheme,
                onSetLanguage = viewModel::setLanguage,
                onSetHaptic = viewModel::setHapticEnabled,
                onSetSound = viewModel::setSoundEnabled,
                onSetAutoReconnect = viewModel::setAutoReconnect,
                onUpdateBatterySaver = viewModel::updateBatterySaver,
                onReconnectProfile = viewModel::reconnectProfile,
                onUpdateProfile = viewModel::updateTvProfile,
                onDeleteProfile = viewModel::deleteTvProfile,
                onSelectLayout = viewModel::selectActiveLayout,
                onCreateLayout = viewModel::createNewCustomLayout,
                onAddCustomButton = viewModel::addCustomButton,
                onRemoveCustomButton = viewModel::removeCustomButton,
                onRenameCustomButton = viewModel::renameCustomButton,
                onCycleCustomButtonSize = viewModel::cycleCustomButtonSize,
                onMoveCustomButton = viewModel::moveCustomButton,
                onRestoreDefaultLayout = viewModel::restoreDefaultCustomLayout
            )
        }
    }
}
