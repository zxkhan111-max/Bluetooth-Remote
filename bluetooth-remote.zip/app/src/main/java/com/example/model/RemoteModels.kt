package com.example.model

enum class ConnectionMode {
    BLUETOOTH_HID,
    WIFI_ANDROID_TV
}

enum class ConnectionState {
    DISCONNECTED,
    SCANNING,
    PAIRING_REQUIRED,
    CONNECTING,
    CONNECTED,
    ERROR
}

enum class DeviceCompatibility {
    COMPATIBLE,
    PAIRING_NEEDED,
    LIMITED_COMPATIBILITY,
    INCOMPATIBLE
}

enum class BluetoothHidSupportStatus {
    SUPPORTED,
    UNSUPPORTED_ANDROID_VERSION,
    ADAPTER_UNAVAILABLE,
    BLUETOOTH_DISABLED,
    PROFILE_PROXY_UNAVAILABLE
}

enum class HidProtocolMode {
    REPORT_PROTOCOL,
    BOOT_PROTOCOL
}

enum class HidProfileAvailability {
    UNSUPPORTED_ANDROID_VERSION,
    ADAPTER_UNAVAILABLE,
    BLUETOOTH_DISABLED,
    DISCONNECTED_PROXY,
    PROXY_BOUND,
    APP_REGISTERED,
    HOST_CONNECTED
}

data class HidProfileStatus(
    val availability: HidProfileAvailability = HidProfileAvailability.DISCONNECTED_PROXY,
    val isProxyConnected: Boolean = false,
    val isAppRegistered: Boolean = false,
    val keyboardProfileActive: Boolean = false,
    val mouseProfileActive: Boolean = false,
    val consumerProfileActive: Boolean = false,
    val protocolMode: HidProtocolMode = HidProtocolMode.REPORT_PROTOCOL,
    val hostDeviceName: String? = null,
    val hostDeviceAddress: String? = null,
    val lastSetReportType: Int? = null,
    val lastStatusDetail: String? = null
)

enum class TvDeviceIcon(val key: String) {
    LIVING_ROOM_TV("tv"),
    ANDROID_BOX("box"),
    PROJECTOR("projector"),
    BEDROOM_TV("bedroom"),
    MONITOR("monitor")
}

data class DiscoveredBluetoothDevice(
    val address: String,
    val name: String,
    val bondState: Int,
    val majorDeviceClass: Int,
    val isLikelyTvOrMedia: Boolean,
    val rssi: Int? = null
)

data class DiscoveredWifiDevice(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val serviceType: String,
    val compatibility: DeviceCompatibility,
    val compatibilityNoteKey: String,
    val supportsReceiverCompanion: Boolean = false
)

data class TvProfile(
    val id: String,
    val name: String,
    val icon: TvDeviceIcon = TvDeviceIcon.LIVING_ROOM_TV,
    val mode: ConnectionMode,
    val addressOrHost: String,
    val port: Int = 6466,
    val isFavorite: Boolean = false,
    val lastConnectedEpochMs: Long = 0L,
    val isPaired: Boolean = false,
    val customLayoutId: String = "default"
)

data class DeviceCapabilities(
    val supportsNavigation: Boolean,
    val supportsMediaKeys: Boolean,
    val supportsVolumeMute: Boolean,
    val supportsKeyboardText: Boolean,
    val supportsHidMouseAndAirMouse: Boolean,
    val supportsSwipeDpadFallback: Boolean,
    val supportsDeepLinkAppLaunch: Boolean,
    val supportsInstalledAppEnumeration: Boolean,
    val supportsDiscreteBrightnessKeys: Boolean,
    val supportsAbsoluteBrightnessSync: Boolean,
    val supportsTvScreenshotTrigger: Boolean,
    val supportsTvReceiverFileTransfer: Boolean,
    val supportsTvReceiverScreenRecording: Boolean
)

data class ConnectedDeviceInfo(
    val id: String,
    val name: String,
    val mode: ConnectionMode,
    val addressOrHost: String,
    val port: Int = 6466,
    val receiverCompanionConnected: Boolean = false,
    val capabilities: DeviceCapabilities
)

data class ConnectionHistoryEntry(
    val id: String,
    val deviceName: String,
    val mode: ConnectionMode,
    val target: String,
    val timestampMs: Long,
    val succeeded: Boolean,
    val message: String
)

// Module 2 & 3: Quick Apps & Smart App Launcher
data class TvAppShortcut(
    val id: String,
    val name: String,
    val packageName: String,
    val deepLinkUri: String,
    val iconKey: String,
    val isFavorite: Boolean = false,
    val isPinnedQuickApp: Boolean = false,
    val lastLaunchedMs: Long = 0L,
    val verifiedInstalled: Boolean? = null // null = cannot query via BT HID / stock remote v2
)

// Module 11: Custom Remote Builder
enum class RemoteButtonSize { SMALL, MEDIUM, LARGE }

data class CustomRemoteButton(
    val id: String,
    val label: String,
    val command: RemoteCommand,
    val iconKey: String,
    val size: RemoteButtonSize = RemoteButtonSize.MEDIUM,
    val orderIndex: Int = 0
)

data class CustomRemoteLayout(
    val id: String,
    val name: String,
    val buttons: List<CustomRemoteButton>
)

// Module 7: File Transfer Center
enum class TransferStatus {
    QUEUED,
    AWAITING_RECEIVER_AUTH,
    TRANSFERRING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class TransferItem(
    val id: String,
    val fileName: String,
    val mimeType: String,
    val uriString: String,
    val sizeBytes: Long,
    val bytesSent: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val status: TransferStatus = TransferStatus.QUEUED,
    val errorDetail: String? = null
)

data class TransferHistoryRecord(
    val id: String,
    val fileName: String,
    val sizeBytes: Long,
    val targetName: String,
    val timestampMs: Long,
    val succeeded: Boolean,
    val note: String
)

data class ReceiverEndpoint(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val requiresPin: Boolean = true
)

// Module 8: Media Cast Center
enum class CastPlaybackState {
    IDLE,
    CONNECTING,
    BUFFERING,
    PLAYING,
    PAUSED,
    ERROR
}

data class CastMediaSelection(
    val uriString: String,
    val displayName: String,
    val mimeType: String,
    val isVideo: Boolean
)

data class CastDeviceSummary(
    val id: String,
    val name: String,
    val description: String,
    val isCastProtocol: Boolean
)

// Module 9: Screen Mirroring
enum class MirroringStatus {
    IDLE,
    AWAITING_PERMISSION,
    ACTIVE_VIRTUAL_DISPLAY,
    ERROR
}

// Module 10: TV Screen Recording
enum class TvRecordingStatus {
    UNSUPPORTED_NO_RECEIVER,
    IDLE_READY,
    AWAITING_TV_USER_CONSENT,
    RECORDING,
    SAVED,
    ERROR
}

// Module 13: Battery Saver
enum class SensorSamplingTier(val delayUsLabelKey: String) {
    RESPONSIVE("responsive"),
    BALANCED("balanced"),
    ECO_LOW_POWER("eco")
}

enum class ConnectionTimeoutOption(val minutes: Int) {
    FIVE_MIN(5),
    FIFTEEN_MIN(15),
    THIRTY_MIN(30),
    NEVER(0)
}

data class BatterySaverSettings(
    val lowPowerMode: Boolean = false,
    val reduceScanning: Boolean = false,
    val reduceKeepalivePolling: Boolean = false,
    val sensorSamplingTier: SensorSamplingTier = SensorSamplingTier.BALANCED,
    val disableAnimations: Boolean = false,
    val connectionTimeout: ConnectionTimeoutOption = ConnectionTimeoutOption.FIFTEEN_MIN
)

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    BENGALI("bn", "বাংলা")
}

data class AppPreferences(
    val onboardingCompleted: Boolean = false,
    val darkTheme: Boolean = true,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val hapticEnabled: Boolean = true,
    val soundEnabled: Boolean = false,
    val autoReconnect: Boolean = true,
    val preferredMode: ConnectionMode = ConnectionMode.BLUETOOTH_HID,
    val airMouseSensitivity: Float = 1.0f,
    val airMousePointerSpeed: Float = 1.0f,
    val touchpadSensitivity: Float = 1.0f,
    val batterySaver: BatterySaverSettings = BatterySaverSettings(),
    val profiles: List<TvProfile> = emptyList(),
    val connectionHistory: List<ConnectionHistoryEntry> = emptyList(),
    val customLayouts: List<CustomRemoteLayout> = emptyList(),
    val activeLayoutId: String = "default",
    val pinnedQuickApps: List<TvAppShortcut> = emptyList(),
    val transferHistory: List<TransferHistoryRecord> = emptyList()
)

data class BatteryStatus(
    val percentage: Int = -1,
    val isCharging: Boolean = false,
    val batterySaverActiveOnSystem: Boolean = false
)

sealed interface RemoteError {
    data class PermissionRequired(val missingPermissions: List<String>) : RemoteError
    data object BluetoothUnavailable : RemoteError
    data object BluetoothDisabled : RemoteError
    data object BluetoothHidUnsupportedAndroid8 : RemoteError
    data object BluetoothHidProfileRejected : RemoteError
    data object BluetoothPairingRequired : RemoteError
    data class BluetoothConnectionFailed(val detail: String) : RemoteError
    data object WifiUnavailable : RemoteError
    data object InvalidIpAddress : RemoteError
    data class WifiConnectionFailed(val host: String, val detail: String) : RemoteError
    data class PairingFailed(val detail: String) : RemoteError
    data class IncompatibleDevice(val deviceName: String) : RemoteError
    data object NotConnected : RemoteError
    data class UnsupportedFeature(val featureName: String, val reasonKey: String) : RemoteError
    data class CommandFailed(val detail: String) : RemoteError
}
