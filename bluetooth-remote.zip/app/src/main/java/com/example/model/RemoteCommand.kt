package com.example.model

/**
 * Unified remote commands mapped to both Android TV Remote Protocol (KeyEvent keycodes)
 * and Bluetooth HID (Keyboard / Consumer Control / Mouse usages).
 */
enum class RemoteCommand(
    val androidKeyCode: Int,
    val hidConsumerUsage: Int? = null,
    val hidKeyboardUsage: Byte? = null
) {
    POWER(androidKeyCode = 26, hidConsumerUsage = 0x0030),
    HOME(androidKeyCode = 3, hidConsumerUsage = 0x0223),
    BACK(androidKeyCode = 4, hidConsumerUsage = 0x0224),
    MENU(androidKeyCode = 82, hidConsumerUsage = 0x0040),
    SETTINGS(androidKeyCode = 176, hidConsumerUsage = 0x0094),
    DPAD_OK(androidKeyCode = 23, hidConsumerUsage = 0x0041, hidKeyboardUsage = 0x28),
    DPAD_UP(androidKeyCode = 19, hidConsumerUsage = 0x0042, hidKeyboardUsage = 0x52),
    DPAD_DOWN(androidKeyCode = 20, hidConsumerUsage = 0x0043, hidKeyboardUsage = 0x51),
    DPAD_LEFT(androidKeyCode = 21, hidConsumerUsage = 0x0044, hidKeyboardUsage = 0x50),
    DPAD_RIGHT(androidKeyCode = 22, hidConsumerUsage = 0x0045, hidKeyboardUsage = 0x4F),
    VOLUME_UP(androidKeyCode = 24, hidConsumerUsage = 0x00E9),
    VOLUME_DOWN(androidKeyCode = 25, hidConsumerUsage = 0x00EA),
    MUTE(androidKeyCode = 164, hidConsumerUsage = 0x00E2),
    CHANNEL_UP(androidKeyCode = 166, hidConsumerUsage = 0x009C),
    CHANNEL_DOWN(androidKeyCode = 167, hidConsumerUsage = 0x009D),
    PLAY_PAUSE(androidKeyCode = 85, hidConsumerUsage = 0x00CD),
    STOP(androidKeyCode = 86, hidConsumerUsage = 0x00B7),
    PREVIOUS(androidKeyCode = 88, hidConsumerUsage = 0x00B6),
    NEXT(androidKeyCode = 87, hidConsumerUsage = 0x00B5),
    FAST_FORWARD(androidKeyCode = 90, hidConsumerUsage = 0x00B3),
    REWIND(androidKeyCode = 89, hidConsumerUsage = 0x00B4),
    SEARCH(androidKeyCode = 84, hidConsumerUsage = 0x0221),
    BRIGHTNESS_UP(androidKeyCode = 221, hidConsumerUsage = 0x006F),
    BRIGHTNESS_DOWN(androidKeyCode = 220, hidConsumerUsage = 0x0070),
    SCREENSHOT(androidKeyCode = 120, hidConsumerUsage = null, hidKeyboardUsage = 0x46)
}
