package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `verify app name and package id`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Bluetooth Remote", context.getString(R.string.app_name))
        assertEquals("com.bluetooth.remote.control", context.packageName)
    }

    @Test
    fun `onboarding to dashboard navigation and bengali toggle work`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("onboarding_skip_btn").performClick()
        composeRule.waitUntil(timeoutMillis = 5000L) {
            composeRule.onAllNodesWithTag("connect_device_btn").fetchSemanticsNodes().isNotEmpty()
        }

        composeRule.onNodeWithTag("connect_device_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("mode_wifi_btn").performClick()
        composeRule.waitForIdle()

        fun openNavTab(tag: String) {
            composeRule.onNodeWithTag("bottom_nav_dock").performScrollToNode(hasTestTag(tag))
            composeRule.onNodeWithTag(tag).performClick()
            composeRule.waitForIdle()
        }

        openNavTab("nav_remote")
        composeRule.onNodeWithTag("dpad_ok").assertIsDisplayed()

        openNavTab("nav_mouse")
        composeRule.onNodeWithTag("touchpad_surface").assertIsDisplayed()

        openNavTab("nav_keyboard")
        composeRule.onNodeWithTag("keyboard_quick_input").assertIsDisplayed()
        composeRule.onNodeWithTag("keyboard_space_btn").performScrollTo().assertIsDisplayed()

        openNavTab("nav_apps")
        composeRule.onNodeWithTag("launcher_hero_yt").assertIsDisplayed()

        openNavTab("nav_media")
        composeRule.onNodeWithTag("cast_pick_photo_btn").assertIsDisplayed()

        openNavTab("nav_transfer")
        composeRule.onNodeWithTag("transfer_pick_media_btn").assertIsDisplayed()

        openNavTab("nav_settings")
        composeRule.onNodeWithTag("lang_bn_chip").performClick()
        composeRule.waitForIdle()
    }
}
