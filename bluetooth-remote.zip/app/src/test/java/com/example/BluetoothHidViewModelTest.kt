package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.connectivity.BluetoothHidService
import com.example.model.BluetoothHidSupportStatus
import com.example.model.ConnectedDeviceInfo
import com.example.model.ConnectionMode
import com.example.model.ConnectionState
import com.example.model.DeviceCapabilities
import com.example.model.DiscoveredBluetoothDevice
import com.example.model.HidProfileAvailability
import com.example.model.HidProfileStatus
import com.example.model.HidProtocolMode
import com.example.model.RemoteCommand
import com.example.model.RemoteError
import com.example.ui.viewmodel.RemoteViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BluetoothHidViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    private class FakeBluetoothHidService : BluetoothHidService {
        override val connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
        override val connectedDevice = MutableStateFlow<ConnectedDeviceInfo?>(null)
        override val bondedDevices = MutableStateFlow<List<DiscoveredBluetoothDevice>>(emptyList())
        override val discoveredDevices = MutableStateFlow<List<DiscoveredBluetoothDevice>>(emptyList())
        override val isScanning = MutableStateFlow(false)
        override val hidSupportStatus = MutableStateFlow(BluetoothHidSupportStatus.SUPPORTED)
        override val hidProfileStatus = MutableStateFlow(HidProfileStatus())
        override val lastError = MutableStateFlow<RemoteError?>(null)

        var initializeCalled = 0
        var unregisterCalled = 0
        var unsupportedAndroid8 = false
        val sentCommands = mutableListOf<RemoteCommand>()
        val sentTexts = mutableListOf<String>()
        val sentKeyboardStrokes = mutableListOf<Pair<Byte, Byte>>()
        val sentMouseReports = mutableListOf<List<Int>>()

        override fun requiredPermissionsForCurrentSdk(): List<String> = emptyList()
        override fun missingPermissions(): List<String> = emptyList()
        override fun refreshBondedDevices() {}

        override fun initializeHidProfile(): RemoteError? {
            initializeCalled++
            if (unsupportedAndroid8) {
                hidSupportStatus.value = BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION
                hidProfileStatus.value = HidProfileStatus(
                    availability = HidProfileAvailability.UNSUPPORTED_ANDROID_VERSION
                )
                return RemoteError.BluetoothHidUnsupportedAndroid8
            }
            hidProfileStatus.value = HidProfileStatus(
                availability = HidProfileAvailability.APP_REGISTERED,
                isProxyConnected = true,
                isAppRegistered = true,
                keyboardProfileActive = true,
                mouseProfileActive = true,
                consumerProfileActive = true,
                protocolMode = HidProtocolMode.REPORT_PROTOCOL
            )
            return null
        }

        override fun unregisterHidProfile() {
            unregisterCalled++
            disconnect()
            hidProfileStatus.value = HidProfileStatus(
                availability = HidProfileAvailability.DISCONNECTED_PROXY,
                isProxyConnected = false,
                isAppRegistered = false,
                keyboardProfileActive = false,
                mouseProfileActive = false,
                consumerProfileActive = false
            )
        }

        override fun startDiscovery(): RemoteError? = null
        override fun stopDiscovery() {}

        override fun connectOrPair(address: String) {
            val device = ConnectedDeviceInfo(
                id = address,
                name = "Living Room Google TV",
                mode = ConnectionMode.BLUETOOTH_HID,
                addressOrHost = address,
                capabilities = DeviceCapabilities(
                    supportsNavigation = true,
                    supportsMediaKeys = true,
                    supportsVolumeMute = true,
                    supportsKeyboardText = true,
                    supportsHidMouseAndAirMouse = true,
                    supportsSwipeDpadFallback = true,
                    supportsDeepLinkAppLaunch = false,
                    supportsInstalledAppEnumeration = false,
                    supportsDiscreteBrightnessKeys = true,
                    supportsAbsoluteBrightnessSync = false,
                    supportsTvScreenshotTrigger = true,
                    supportsTvReceiverFileTransfer = false,
                    supportsTvReceiverScreenRecording = false
                )
            )
            connectedDevice.value = device
            connectionState.value = ConnectionState.CONNECTED
            hidProfileStatus.value = hidProfileStatus.value.copy(
                availability = HidProfileAvailability.HOST_CONNECTED,
                isProxyConnected = true,
                isAppRegistered = true,
                keyboardProfileActive = true,
                mouseProfileActive = true,
                consumerProfileActive = true,
                hostDeviceName = device.name,
                hostDeviceAddress = address
            )
        }

        override fun disconnect() {
            connectedDevice.value = null
            connectionState.value = ConnectionState.DISCONNECTED
            hidProfileStatus.value = hidProfileStatus.value.copy(
                availability = if (hidProfileStatus.value.isAppRegistered) {
                    HidProfileAvailability.APP_REGISTERED
                } else {
                    HidProfileAvailability.DISCONNECTED_PROXY
                },
                hostDeviceName = null,
                hostDeviceAddress = null
            )
        }

        override fun release() {}

        override fun sendCommand(command: RemoteCommand): RemoteError? {
            if (connectedDevice.value == null) return RemoteError.NotConnected
            sentCommands.add(command)
            return null
        }

        override fun sendText(text: String): RemoteError? {
            if (connectedDevice.value == null) return RemoteError.NotConnected
            sentTexts.add(text)
            return null
        }

        override fun sendKeyboardStroke(modifier: Byte, keyCode: Byte): RemoteError? {
            if (connectedDevice.value == null) return RemoteError.NotConnected
            sentKeyboardStrokes.add(modifier to keyCode)
            return null
        }

        override fun sendKeyboardKeyDown(modifier: Byte, keyCode: Byte): RemoteError? =
            sendKeyboardStroke(modifier, keyCode)

        override fun sendKeyboardRelease(): RemoteError? = null

        override fun sendMouseReport(
            buttonsBitmask: Int,
            deltaX: Int,
            deltaY: Int,
            scrollWheel: Int
        ): RemoteError? {
            if (connectedDevice.value == null) return RemoteError.NotConnected
            sentMouseReports.add(listOf(buttonsBitmask, deltaX, deltaY, scrollWheel))
            return null
        }

        override fun sendMouseMove(deltaX: Int, deltaY: Int, buttonsBitmask: Int): RemoteError? =
            sendMouseReport(buttonsBitmask, deltaX, deltaY, 0)

        override fun sendMouseClick(buttonsBitmask: Int, releaseAfter: Boolean): RemoteError? {
            val err = sendMouseReport(buttonsBitmask, 0, 0, 0)
            if (err != null) return err
            if (releaseAfter) return sendMouseReport(0, 0, 0, 0)
            return null
        }

        override fun sendMouseScroll(wheelDelta: Int, buttonsBitmask: Int): RemoteError? =
            sendMouseReport(buttonsBitmask, 0, 0, wheelDelta)
    }

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `viewmodel initializes hid keyboard and mouse profiles and connects host`() = runTest {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val fakeHid = FakeBluetoothHidService()
        val vm = RemoteViewModel(app, fakeHid)

        advanceUntilIdle()
        val initial = vm.uiState.first { it.hidProfileStatus.isAppRegistered }
        assertTrue(fakeHid.initializeCalled >= 1)
        assertTrue(initial.hidProfileStatus.keyboardProfileActive)
        assertTrue(initial.hidProfileStatus.mouseProfileActive)
        assertTrue(initial.hidProfileStatus.consumerProfileActive)
        assertEquals(HidProfileAvailability.APP_REGISTERED, initial.hidProfileStatus.availability)

        vm.connectBluetoothDevice("AA:BB:CC:DD:EE:FF")
        advanceUntilIdle()

        val connectedState = vm.uiState.first { it.connectionState == ConnectionState.CONNECTED }
        assertEquals(HidProfileAvailability.HOST_CONNECTED, connectedState.hidProfileStatus.availability)
        assertEquals("Living Room Google TV", connectedState.connectedDevice?.name)
    }

    @Test
    fun `keyboard and mouse reports route through hid service and disconnect resets drag lock`() = runTest {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val fakeHid = FakeBluetoothHidService()
        val vm = RemoteViewModel(app, fakeHid)

        vm.connectBluetoothDevice("11:22:33:44:55:66")
        advanceUntilIdle()
        vm.uiState.first { it.connectionState == ConnectionState.CONNECTED }

        // Keyboard HID reports
        vm.sendKeyboardText("hello")
        vm.sendBackspaceKey()
        vm.sendEnterKey()
        vm.sendModifierKeyboardStroke(0x01, 0x06) // Ctrl+C
        assertEquals(listOf("hello"), fakeHid.sentTexts)
        assertEquals(
            listOf(
                0.toByte() to 0x2A.toByte(),
                0.toByte() to 0x28.toByte(),
                0x01.toByte() to 0x06.toByte()
            ),
            fakeHid.sentKeyboardStrokes
        )

        // Mouse HID reports
        vm.toggleDragLock()
        advanceUntilIdle()
        assertTrue(vm.uiState.first { it.isDragLocked }.isDragLocked)

        vm.onTouchpadMove(12f, -8f)
        vm.sendMouseClick(rightButton = false, doubleClick = false)
        vm.sendMouseScroll(3)

        assertTrue(fakeHid.sentMouseReports.any { it[0] == 1 && it[1] == 12 && it[2] == -8 })
        assertTrue(fakeHid.sentMouseReports.any { it[3] == 3 })

        // Disconnect resets drag lock
        vm.disconnectActiveDevice()
        advanceUntilIdle()
        val disconnectedState = vm.uiState.first { it.connectionState == ConnectionState.DISCONNECTED }
        assertNull(disconnectedState.connectedDevice)
        assertFalse(disconnectedState.isDragLocked)
    }

    @Test
    fun `android 8 unsupported hid surfaces honest error in ui state`() = runTest {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val fakeHid = FakeBluetoothHidService().apply { unsupportedAndroid8 = true }
        val vm = RemoteViewModel(app, fakeHid)

        vm.initializeBluetoothHidProfile(userInitiated = true)
        advanceUntilIdle()

        val state = vm.uiState.first {
            it.hidSupportStatus == BluetoothHidSupportStatus.UNSUPPORTED_ANDROID_VERSION
        }
        assertEquals(
            HidProfileAvailability.UNSUPPORTED_ANDROID_VERSION,
            state.hidProfileStatus.availability
        )
        assertNotNull(state.activeErrorMessage)
    }
}
