package com.example

import com.example.connectivity.AndroidTvProtoCodec
import com.example.connectivity.HidReportDescriptor
import com.example.connectivity.ParsedVoiceIntent
import com.example.connectivity.VoiceCommandController
import com.example.model.RemoteCommand
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RemoteProtocolsUnitTest {

    @Test
    fun `hid descriptor has keyboard consumer and mouse report ids`() {
        val desc = HidReportDescriptor.DESCRIPTOR
        assertTrue(desc.size > 60)
        val aKey = HidReportDescriptor.charToHid('a')
        assertNotNull(aKey)
        assertEquals(0.toByte(), aKey?.modifier)
        assertEquals(0x04.toByte(), aKey?.usage)

        val upperA = HidReportDescriptor.charToHid('A')
        assertNotNull(upperA)
        assertEquals(0x02.toByte(), upperA?.modifier)
        assertEquals(0x04.toByte(), upperA?.usage)

        val space = HidReportDescriptor.charToHid(' ')
        assertEquals(0x2C.toByte(), space?.usage)
    }

    @Test
    fun `android tv proto codec frames and parses messages`() {
        val req = AndroidTvProtoCodec.buildPairingRequest("Bluetooth Remote", "Pixel")
        val fields = AndroidTvProtoCodec.parseFields(req)
        assertEquals(2L, fields.first { it.number == 1 }.varint)
        assertEquals(200L, fields.first { it.number == 2 }.varint)

        val keyInject = AndroidTvProtoCodec.buildRemoteKeyInject(RemoteCommand.HOME.androidKeyCode)
        val keyFields = AndroidTvProtoCodec.parseFields(keyInject)
        assertTrue(keyFields.any { it.number == 10 })

        val startApp = AndroidTvProtoCodec.buildRemoteStartApp("https://www.youtube.com")
        val appFields = AndroidTvProtoCodec.parseFields(startApp)
        assertTrue(appFields.any { it.number == 90 })
    }

    @Test
    fun `voice command parser handles english and bengali commands`() {
        assertEquals(
            ParsedVoiceIntent.LaunchApp("yt", "YouTube"),
            VoiceCommandController.parseSpokenCommand("Open YouTube")
        )
        assertEquals(
            ParsedVoiceIntent.LaunchApp("nf", "Netflix"),
            VoiceCommandController.parseSpokenCommand("নেটফ্লিক্স খোলো")
        )
        assertEquals(
            ParsedVoiceIntent.Command(RemoteCommand.HOME),
            VoiceCommandController.parseSpokenCommand("হোম")
        )
        assertEquals(
            ParsedVoiceIntent.Command(RemoteCommand.VOLUME_UP),
            VoiceCommandController.parseSpokenCommand("ভলিউম বাড়াও")
        )
        assertEquals(
            ParsedVoiceIntent.Command(RemoteCommand.DPAD_OK),
            VoiceCommandController.parseSpokenCommand("ওকে")
        )
        assertEquals(
            ParsedVoiceIntent.SearchQuery("lofi music"),
            VoiceCommandController.parseSpokenCommand("search lofi music")
        )
    }
}
