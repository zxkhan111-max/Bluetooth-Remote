package com.example

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothProfile
import android.content.Intent
import com.example.connectivity.BluetoothHidDeviceService
import com.example.model.ConnectionState
import com.example.model.HidProfileAvailability
import com.example.model.HidProtocolMode
import com.example.model.RemoteError
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BluetoothHidDeviceServiceTest {

    @Test
    fun `service binds cleanly and manages hid app registration and connection callbacks`() {
        val controller = Robolectric.buildService(BluetoothHidDeviceService::class.java).create()
        val binder = controller.get().onBind(Intent()) as BluetoothHidDeviceService.LocalBinder
        val service = binder.getService()

        // 1. Host SDP registration succeeds
        service.hidCallback.onAppStatusChanged(null, true)
        val registeredStatus = service.hidProfileStatus.value
        assertTrue(registeredStatus.isAppRegistered)
        assertTrue(registeredStatus.keyboardProfileActive)
        assertTrue(registeredStatus.mouseProfileActive)
        assertTrue(registeredStatus.consumerProfileActive)
        assertEquals(HidProfileAvailability.APP_REGISTERED, registeredStatus.availability)

        // 2. Host connecting -> connected
        val remoteDevice: BluetoothDevice? =
            BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice("AA:BB:CC:DD:EE:FF")
        assertNotNull(remoteDevice)

        service.hidCallback.onConnectionStateChanged(remoteDevice, BluetoothProfile.STATE_CONNECTING)
        assertEquals(ConnectionState.CONNECTING, service.connectionState.value)

        service.hidCallback.onConnectionStateChanged(remoteDevice, BluetoothProfile.STATE_CONNECTED)
        assertEquals(ConnectionState.CONNECTED, service.connectionState.value)
        assertEquals("AA:BB:CC:DD:EE:FF", service.connectedDevice.value?.addressOrHost)
        assertEquals(HidProfileAvailability.HOST_CONNECTED, service.hidProfileStatus.value.availability)
        assertTrue(service.connectedDevice.value?.capabilities?.supportsKeyboardText == true)
        assertTrue(service.connectedDevice.value?.capabilities?.supportsHidMouseAndAirMouse == true)

        // 3. Protocol mode & output/interrupt reports
        service.hidCallback.onSetProtocol(remoteDevice, BluetoothHidDevice.PROTOCOL_BOOT_MODE)
        assertEquals(HidProtocolMode.BOOT_PROTOCOL, service.hidProfileStatus.value.protocolMode)

        service.hidCallback.onSetProtocol(remoteDevice, BluetoothHidDevice.PROTOCOL_REPORT_MODE)
        assertEquals(HidProtocolMode.REPORT_PROTOCOL, service.hidProfileStatus.value.protocolMode)

        service.hidCallback.onSetReport(remoteDevice, BluetoothHidDevice.REPORT_TYPE_OUTPUT, 1, byteArrayOf(0x02))
        assertEquals(BluetoothHidDevice.REPORT_TYPE_OUTPUT.toInt(), service.hidProfileStatus.value.lastSetReportType)

        service.hidCallback.onInterruptData(remoteDevice, 1, byteArrayOf(0x01))
        assertTrue(service.hidProfileStatus.value.lastStatusDetail?.contains("interrupt report") == true)

        // 4. Virtual cable unplug tears down active host cleanly
        service.hidCallback.onVirtualCableUnplug(remoteDevice)
        assertEquals(ConnectionState.DISCONNECTED, service.connectionState.value)
        assertNull(service.connectedDevice.value)
        assertEquals(HidProfileAvailability.APP_REGISTERED, service.hidProfileStatus.value.availability)

        // 5. Failed connection attempt sets explicit error
        service.hidCallback.onConnectionStateChanged(remoteDevice, BluetoothProfile.STATE_CONNECTING)
        service.hidCallback.onConnectionStateChanged(remoteDevice, BluetoothProfile.STATE_DISCONNECTED)
        assertEquals(ConnectionState.ERROR, service.connectionState.value)
        assertTrue(service.lastError.value is RemoteError.BluetoothConnectionFailed)

        // 6. Unregistering clears all profile active flags
        service.hidCallback.onAppStatusChanged(null, false)
        assertFalse(service.hidProfileStatus.value.isAppRegistered)
        assertFalse(service.hidProfileStatus.value.keyboardProfileActive)
        assertFalse(service.hidProfileStatus.value.mouseProfileActive)

        controller.destroy()
    }
}
